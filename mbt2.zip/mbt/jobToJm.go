package main

import (
	"fmt"
	uuid "github.com/satori/go.uuid"
	"github.com/tealeg/xlsx/v3"
	"log"
	"mbtDbUtils/config"
	"mbtDbUtils/db"
	"path"
	"strconv"
	"time"
)

//导出Excel
func ExportExcel() {
	batchMapList, err := db.DoQuery("select * from GP_BM_BMS_BATCH")
	if err != nil {
		log.Fatalf("查询数据库异常：%s", err)
	}
	ctlCfgMapList, err := db.DoQueryMapList("select * from GP_BM_BMS_CTL_CFG", "BATCH_ID")
	if err != nil {
		log.Fatalf("查询数据库异常：%s", err)
	}
	println(ctlCfgMapList)
	file := xlsx.NewFile()
	sheet, err := file.AddSheet("Sheet1")
	if err != nil {
		panic(err)
	}

	row := sheet.AddRow()
	row.SetHeightCM(1) //设置每行的高度
	cell := row.AddCell()
	cell.Value = "序号"
	cell = row.AddCell()
	cell.Value = "任务名称"
	row.AddCell().Value = "执行计划"
	row.AddCell().Value = "最后一次执行时间"
	row.AddCell().Value = "备注"
	row.AddCell().Value = "DATA_ID"

	for index, batchMap := range batchMapList {
		row := sheet.AddRow()
		row.SetHeightCM(1) //设置每行的高度
		row.AddCell().Value = strconv.Itoa(index)
		row.AddCell().Value = batchMap["BATCH_NAME"].(string)
		if batchMap["RUN_PLAN"] == nil {
			row.AddCell().Value = ""
		} else {
			row.AddCell().Value = batchMap["RUN_PLAN"].(string)
		}
		if batchMap["LAST_TIME"] == nil {
			row.AddCell().Value = ""
		} else {
			row.AddCell().Value = batchMap["LAST_TIME"].(string)
		}
		if batchMap["RSV1"] == nil {
			row.AddCell().Value = ""
		} else {
			row.AddCell().Value = batchMap["RSV1"].(string)
		}
		row.AddCell().Value = batchMap["DATA_ID"].(string)
	}

	err = file.Save(path.Join("xlsx", "批量任务.xlsx"))
	if err != nil {
		panic(err)
	}

}

func CtlCfgToJob() []string {
	batchMapList, err := db.DoQuery("select * from GP_BM_BMS_BATCH")
	if err != nil {
		log.Fatalf("查询数据库异常：%s", err)
	}
	runPlanMapList, err := db.DoQueryMap("select * from GP_BM_BMS_RUN_PLAN", "PLAN_ID")
	if err != nil {
		log.Fatalf("查询数据库异常：%s", err)
	}
	ctlCfgMapList, err := db.DoQueryMapList("select * from GP_BM_BMS_CTL_CFG", "BATCH_ID")
	if err != nil {
		log.Fatalf("查询数据库异常：%s", err)
	}
	file, err := xlsx.OpenFile(path.Join("xlsx", "批量任务.xlsx"))
	if err != nil {
		log.Fatalf("读取批量任务Excel异常：%s", err)
	}
	sheet := file.Sheet["Sheet1"]
	var i = 1
	var dataIdList []string
	for i < sheet.MaxRow {
		row, err := sheet.Row(i)
		panicError(err)
		if len(row.GetCell(5).Value) > 0 {
			dataIdList = append(dataIdList, row.GetCell(5).Value)
		}
		i++
	}
	var jmList []map[string]interface{}
	var jmBatchList []map[string]interface{}
	var jmBatchDtlList []map[string]interface{}
	for _, batchMap := range batchMapList {
		batchId := batchMap["DATA_ID"].(string)
		ctlCfgList := ctlCfgMapList[batchId]
		var jm = make(map[string]interface{})
		if !IsContain(dataIdList, batchMap["DATA_ID"].(string)) {
			//当前dataId 不在Excel中 不生成SQL语句
			continue
		}
		jm["DATA_ID"] = batchMap["DATA_ID"]
		jm["JOB_NAME"] = batchMap["BATCH_NAME"]
		jm["JOB_TYPE"] = "MULTSTEP" // 都为批量任务
		// 默认 任务状态都为关闭
		jm["JOB_ACTIVED"] = "N"
		jm["RUN_TIME_TYPE"] = "SING"
		jm["RUN_TIME"] = "00:00:00"
		//RUN_FREQ  LIST:D,日;WD,工作日;CAL,日历;W,周;T,旬;M,月;Q,季;HY,半年;Y,年;CUST,自定义;MANUAL,手工触发
		if batchMap["RUN_PLAN"] == nil {
			// 没有 执行计划 按照单次执行计算
			jm["RUN_FREQ"] = "MANUAL"
		} else {
			planId := batchMap["RUN_PLAN"].(string)
			runPlanMap := runPlanMapList[planId]
			//设置多次执行
			if runPlanMap["START_TIME"] != nil && len(runPlanMap["START_TIME"].(string)) > 0 {
				multipleExecutions(jm, runPlanMap)
			}
			if config.Cfg.RunPlanFlag {
				switch runPlanMap["BASE_DAY"] {
				case "EVD": //每个自然日
					jm["RUN_FREQ"] = "D"
					break
				case "EVW": //每个工作日
					jm["RUN_FREQ"] = "WD"
					break
				case "MFD": //每月1日
					jm["RUN_FREQ"] = "CUST"
					jm["CRON"] = "0 0 0 1 * ? *"
				case "MFW": //月的第一个工作日
					jm["RUN_FREQ"] = "CUST"
					i, ok := runPlanMap["OFFSET_D"].(int64)
					if ok {
						jm["CRON"] = fmt.Sprintf("0 0 0 %dW * ? *", 1+i)
					} else {
						jm["CRON"] = "0 0 0 1W * ? *"
					}
				case "MLD": //月的最后一个工作日
					jm["RUN_FREQ"] = "CUST"
					jm["CRON"] = "0 0 0 LW * ? *"
				case "YFD": // 1月1日
					jm["RUN_FREQ"] = "CUST"
					jm["CRON"] = "0 0 0 1 1 ? *"
				case "YFW": // 年的第一个工作日
					jm["RUN_FREQ"] = "CUST"
					jm["CRON"] = "0 0 0 1W 1 ? *"
				case "YLD": // 12月31日
					jm["RUN_FREQ"] = "CUST"
					jm["CRON"] = "0 0 0 31 12 ? *"
				case "YLW": // 年的最后一个工作日
					jm["RUN_FREQ"] = "CUST"
					jm["CRON"] = "0 0 0 LW 12 ? *"
				}
			} else {
				//RUN_FREQ  LIST:D,日;WD,工作日;CAL,日历;W,周;T,旬;M,月;Q,季;HY,半年;Y,年;CUST,自定义;MANUAL,手工触发
				switch runPlanMap["BASE_DAY"] {
				case "EVD": //每个自然日
					jm["RUN_FREQ"] = "D"
					break
				case "EVW": //每个工作日
					jm["RUN_FREQ"] = "WD"
					break
				case "MFD": //每月1日
					jm["RUN_FREQ"] = "M"
					// C 自然日 W工作日
					jm["OFFSET_WD_FLAG"] = "C"
					//偏移日期
					i, ok := runPlanMap["OFFSET_D"].(int64)
					if ok {
						jm["OFFSET_VALUE"] = 1 + i
					} else {
						jm["OFFSET_VALUE"] = 1
					}

				case "MFW": //月的第一个工作日
					jm["RUN_FREQ"] = "M"
					// C 自然日 W工作日
					jm["OFFSET_WD_FLAG"] = "W"
					//偏移日期
					i, ok := runPlanMap["OFFSET_D"].(int64)
					if ok {
						jm["OFFSET_VALUE"] = 1 + i
					} else {
						jm["OFFSET_VALUE"] = 1
					}
				case "MLD": //月的最后一个工作日
					jm["RUN_FREQ"] = "M"
					// C 自然日 W工作日
					jm["OFFSET_WD_FLAG"] = "W"
					//偏移日期
					i, ok := runPlanMap["OFFSET_D"].(int64)
					if ok {
						jm["OFFSET_VALUE"] = -1 + i
					} else {
						jm["OFFSET_VALUE"] = -1
					}
				case "YFD": // 1月1日
					jm["RUN_FREQ"] = "Y"
					// C 自然日 W工作日
					jm["OFFSET_WD_FLAG"] = "C"
					i, ok := runPlanMap["OFFSET_D"].(int64)
					if ok {
						dateTime := time.Date(2021, 1, 1, 0, 0, 0, 0, time.Now().Location())
						i2 := 24 * i
						dd, _ := time.ParseDuration(fmt.Sprintf("%dh", i2))
						dateTime = dateTime.Add(dd)
						jm["MONTH_SET"] = dateTime.Month()
						jm["OFFSET_VALUE"] = dateTime.Day()
					} else {
						jm["MONTH_SET"] = 1
						jm["OFFSET_VALUE"] = 1
					}
				case "YFW": // 年的第一个工作日
					// C 自然日 W工作日
					jm["OFFSET_WD_FLAG"] = "W"
					i, ok := runPlanMap["OFFSET_D"].(int64)
					if ok {
						dateTime := time.Date(2021, 1, 1, 0, 0, 0, 0, time.Now().Location())
						i2 := 24 * i
						dd, _ := time.ParseDuration(fmt.Sprintf("%dh", i2))
						dateTime = dateTime.Add(dd)
						jm["MONTH_SET"] = dateTime.Month()
						jm["OFFSET_VALUE"] = dateTime.Day()
					} else {
						jm["MONTH_SET"] = 1
						jm["OFFSET_VALUE"] = 1
					}
				case "YLD": // 12月31日
					jm["RUN_FREQ"] = "CUST"
					jm["CRON"] = "0 0 0 31 12 ? *"
				case "YLW": // 年的最后一个工作日
					jm["RUN_FREQ"] = "CUST"
					jm["CRON"] = "0 0 0 LW 12 ? *"
				}
			}
		}

		publicFields(jm, batchMap)
		var jmBatch = make(map[string]interface{})

		jmBatch["DATA_ID"] = batchMap["DATA_ID"]
		jmBatch["RETRY_TYPE"] = "OFF"
		jmBatch["STEP_EXPR"] = batchMap["EXPRESSION"]
		jmBatch["TRANSACTIONAL"] = "Y"
		jmBatch["PARALLEL"] = "S"
		jmBatch["RUN_ORDER"] = "S"

		publicFields(jmBatch, batchMap)
		//子任务数量大于1条为批量任务
		if len(ctlCfgList) > 1 {
			var i = 0
			for _, ctlCfg := range ctlCfgList {
				var jmBatchDtl = make(map[string]interface{})
				//存储过程的任务不处理
				if ctlCfg["JOB_TYPE"] == nil || "2" == ctlCfg["JOB_TYPE"].(string) {
					continue
				}
				i++
				jmBatchDtl["DATA_ID"] = uuid.NewV4().String()
				jmBatchDtl["STEP_ORDER"] = ctlCfg["RUN_ORDER"]
				jmBatchDtl["STEP_NAME"] = ctlCfg["JOB_ID"]
				jmBatchDtl["PDATA_ID"] = batchId
				jmBatchDtl["STEP_EXPR"] = ctlCfg["ARGS"]
				//公共字段
				publicFields(jmBatchDtl, ctlCfg)

				jmBatchDtlList = append(jmBatchDtlList, jmBatchDtl)
			}
			if i > 0 {
				jmList = append(jmList, jm)
				jmBatchList = append(jmBatchList, jmBatch)
			}
		} else {
			ctlCfg := ctlCfgList[0]
			//存储过程的任务不处理
			if ctlCfg["JOB_TYPE"] == nil || "2" == ctlCfg["JOB_TYPE"].(string) {
				continue
			}
			jm["JOB_TYPE"] = "SPEL"
			jmList = append(jmList, jm)
			jmBatch["STEP_EXPR"] = ctlCfg["ARGS"]
			jmBatchList = append(jmBatchList, jmBatch)
		}

	}
	if config.Cfg.IsExportJob {
		jobToGmList, jobToGmBatchList := JobToJm()
		jmList = append(jmList, jobToGmList...)
		jmBatchList = append(jmBatchList, jobToGmBatchList...)
	}
	var sqlList []string
	sqlList = append(sqlList, db.GenSqlList("GP_BM_JM", jmList)...)
	sqlList = append(sqlList, db.GenSqlList("GP_BM_JM_BATCH", jmBatchList)...)
	sqlList = append(sqlList, db.GenSqlList("GP_BM_JM_BATCH_DTL", jmBatchDtlList)...)
	return sqlList
}

func multipleExecutions(jm map[string]interface{}, runPlanMap map[string]interface{}) {
	jm["RUN_TIME_TYPE"] = "MULTI"

	jm["RUN_INT_BEGIN_TIME"] = getTimeNew(runPlanMap["START_TIME"].(string))
	jm["RUN_INT_END_TIME"] = getTimeNew(runPlanMap["END_TIME"].(string))
	interval := runPlanMap["INTERAL"].(int64)
	//当前只支持 分钟和 小时的时间间隔，原来的时间间隔是按照秒计算的
	if interval < 60 {
		jm["RUN_INTERVAL"] = 1
		jm["RUN_INT_UNIT"] = "M"
	} else if interval < 3600 {
		jm["RUN_INTERVAL"] = interval / 60
		jm["RUN_INT_UNIT"] = "M"
	} else {
		jm["RUN_INTERVAL"] = interval / 3600
		jm["RUN_INT_UNIT"] = "H"
	}
}

func getTimeNew(time string) string {
	var bates []byte
	for index, by := range []byte(time) {
		bates = append(bates, by)
		if index == 1 || index == 3 {
			bates = append(bates, ':')
		}
	}
	return string(bates)
}

func JobToJm() ([]map[string]interface{}, []map[string]interface{}) {
	var jobSqlStr = "SELECT B.DATA_ID,\n       A.JOB_GROUP,\n       A.JOB_ID,\n       A.TYPE,\n       A.EXPRESSION,\n       A.DATA,\n       A.DESCRIPTION,\n       A.IS_TRANSACTIONAL,\n       A.IS_CONCURRENT,\n       B.RUN_SECOND,\n       B.RUN_MINUTE,\n       B.RUN_HOUR,\n       B.RUN_DAY_IN_MONTH,\n       B.RUN_MONTH,\n       B.RUN_DAY_IN_WEEK,\n       B.RUN_YEAR,\n       B.DATA_STATUS,\n       B.STATUS,\n       B.DATA_DATE,\n       B.CORP_ID,\n       B.ORG_ID,\n       B.GROUP_ID,\n       B.NEXT_ACTION,\n       B.DATA_FLAG,\n       B.DATA_SOURCE,\n       B.CHECK_FLAG,\n       B.CHECK_DESC,\n       B.CHECK_ERR_TYPE,\n       B.DATA_VERSION,\n       B.DATA_REJ_DESC,\n       B.DATA_DEL_DESC,\n       B.DATA_CRT_USER,\n       B.DATA_CRT_DATE,\n       B.DATA_CRT_TIME,\n       B.DATA_CHG_USER,\n       B.DATA_CHG_DATE,\n       B.DATA_CHG_TIME,\n       B.DATA_APV_USER,\n       B.DATA_APV_DATE,\n       B.DATA_APV_TIME,\n       B.RSV1,\n       B.RSV2,\n       B.RSV3,\n       B.RSV4,\n       B.RSV5,\n       B.REMARKS\nFROM GP_BM_JOB A inner join GP_BM_JOB_SCHEDULE B on A.DATA_ID = B.DATA_ID"
	jobMapList, err := db.DoQuery(jobSqlStr)
	if err != nil {
		log.Printf("查询数据库异常：[%s]", err)
	}
	var gmBatchDtlList []map[string]interface{}
	var gmBatchList []map[string]interface{}
	var gmList []map[string]interface{}
	for _, jobMap := range jobMapList {
		var jmBatch = make(map[string]interface{})

		jmBatch["DATA_ID"] = jobMap["DATA_ID"]
		jmBatch["RETRY_TYPE"] = "OFF"
		jmBatch["STEP_EXPR"] = jobMap["EXPRESSION"]
		jmBatch["TRANSACTIONAL"] = jobMap["IS_TRANSACTIONAL"]
		//jmBatch["IS_CONCURRENT"] = jobMap["IS_CONCURRENT"]

		publicFields(jmBatch, jobMap)
		gmBatchList = append(gmBatchList, jmBatch)

		var jm = make(map[string]interface{})
		jm["DATA_ID"] = jobMap["DATA_ID"]
		if jobMap["DESCRIPTION"] == nil || len(jobMap["DESCRIPTION"].(string)) > 64 {
			jm["JOB_NAME"] = jobMap["JOB_GROUP"]
		} else {
			jm["JOB_NAME"] = jobMap["DESCRIPTION"]
		}
		jm["JOB_TYPE"] = "SPEL"

		jm["JOB_ACTIVED"] = jobMap["STATUS"]
		jm["RUN_FREQ"] = "CUST"
		jm["RUN_TIME_TYPE"] = "SING"
		jm["RUN_TIME"] = "00:00:00"
		var runYear = jobMap["RUN_YEAR"]
		if runYear == nil {
			runYear = "*"
		}
		var runDayInWeek = jobMap["RUN_DAY_IN_WEEK"]
		if runDayInWeek == nil {
			runDayInWeek = "?"
		}
		var runMonth = jobMap["RUN_MONTH"]
		if runMonth == nil {
			runMonth = "*"
		}
		var runDayInMonth = jobMap["RUN_DAY_IN_MONTH"]
		if runDayInMonth == nil {
			runDayInMonth = "*"
		}
		var runHour = jobMap["RUN_HOUR"]
		if runHour == nil {
			runHour = "*"
		}
		var runMinute = jobMap["RUN_MINUTE"]
		if runMinute == nil {
			runMinute = "*"
		}
		var runSecond = jobMap["RUN_SECOND"]
		if runSecond == nil {
			runSecond = "*"
		}

		jm["CRON"] = runSecond.(string) + " " + runMinute.(string) + " " + runHour.(string) + " " + runDayInMonth.(string) + " " + runMonth.(string) + " " + runDayInWeek.(string) + " " + runYear.(string)

		publicFields(jm, jobMap)
		gmList = append(gmList, jm)

		var jmBatchDtl = make(map[string]interface{})
		jmBatchDtl["DATA_ID"] = uuid.NewV4().String()

		jmBatchDtl["STEP_ORDER"] = 1
		if jobMap["DESCRIPTION"] != nil && jobMap["DESCRIPTION"].(string) == "usage.doSomethingWith(\\\"C:\\\\\\\\gpms2\\\\\\\\tmp\\\")   autoImportFileJob.execute(\"C:\\\\gpms2\\\\tmp\",\"Y\",2)" {

		}

		if jobMap["DESCRIPTION"] == nil || len(jobMap["DESCRIPTION"].(string)) > 64 {
			jmBatchDtl["STEP_NAME"] = jobMap["JOB_GROUP"]
		} else {
			jmBatchDtl["STEP_NAME"] = jobMap["DESCRIPTION"]
		}
		jmBatchDtl["STEP_EXPR"] = jobMap["EXPRESSION"]

		jmBatchDtl["PDATA_ID"] = jobMap["EXPRESSION"] //TODO 等于 GP_BM_JM 表 DATA_ID
		//公共字段
		publicFields(jmBatchDtl, jobMap)

		gmBatchDtlList = append(gmBatchDtlList, jmBatchDtl)
	}

	return gmList, gmBatchList
}

func publicFields(gmBatch map[string]interface{}, jobMap map[string]interface{}) {
	gmBatch["DATA_DATE"] = jobMap["DATA_DATE"]
	gmBatch["CORP_ID"] = jobMap["CORP_ID"]
	gmBatch["ORG_ID"] = jobMap["ORG_ID"]
	gmBatch["GROUP_ID"] = jobMap["GROUP_ID"]
	gmBatch["DATA_VERSION"] = 0
	gmBatch["DATA_CRT_USER"] = jobMap["DATA_CRT_USER"]
	gmBatch["DATA_CRT_DATE"] = jobMap["DATA_CRT_DATE"]
	gmBatch["DATA_CRT_TIME"] = jobMap["DATA_CRT_TIME"]
	gmBatch["DATA_CHG_USER"] = jobMap["DATA_CHG_USER"]
	gmBatch["DATA_CHG_DATE"] = jobMap["DATA_CHG_DATE"]
	gmBatch["DATA_CHG_TIME"] = jobMap["DATA_CHG_TIME"]
}

func IsContain(items []string, item string) bool {
	for _, eachItem := range items {
		if eachItem == item {
			return true
		}
	}
	return false
}
