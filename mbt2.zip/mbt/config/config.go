package config

import (
	"encoding/json"
	"io/ioutil"
	"log"
	"os"
)

var Cfg Config

type Config struct {
	Username               string                       `json:"Username"`
	Password               string                       `json:"Password"`
	ConnString             string                       `json:"ConnString"`
	UsernameNew            string                       `json:"UsernameNew"`
	PasswordNew            string                       `json:"PasswordNew"`
	ConnStringNew          string                       `json:"ConnStringNew"`
	TruncateTable          bool                         `json:"TruncateTable"`          //是否生成 truncate table 语句 废弃
	DeleteSqlFlag          bool                         `json:"DeleteSqlFlag"`          //是否生成 delete语句，为true是有独立删除文件和在每一行上有删除语句，为false时，只有独立的deleteSQL文件
	RunPlanFlag            bool                         `json:"RunPlanFlag"`            //生成批量任务的表达式为自定义，还是其他类型
	ImportBusinessLineFlag bool                         `json:"ImportBusinessLineFlag"` //导入 业务线来源是表还是 Excel true是表格导入
	IsExportJob            bool                         `json:"IsExportJob"`            //是否导出定时任务管理部分SQL
	SyncTableList          map[string]map[string]string `json:"SyncTableList"`          //key 表名  可以直接查询，也可以配置SQL。可以设置查询结果默认值
	//TableNameList []string                     `json:"TableNameList"` //可以直接复制的表名。
}

var cfgFileName = "./cfg.json"

func (cfg *Config) Load() {
	file, err := os.Open(cfgFileName)
	if err != nil {
		log.Printf("open config file[%s] error", err)
	}
	defer file.Close()

	fileContent, err := ioutil.ReadAll(file)
	if err != nil {
		log.Printf("read config file[%s] error", err)
	}

	err = json.Unmarshal(fileContent, &cfg)
	if err != nil {
		log.Printf("parse config file[%s] format error", err)
	}
}

func (cfg *Config) Display() {
	log.Print("-------------------------- cfg ----------------------------")
	log.Printf("    Username  [%s]", cfg.Username)
	log.Printf("    Password  [%s]", cfg.Username)
	log.Printf("    ConnString  [%s]", cfg.ConnString)
	log.Print("-----------------------------------------------------------")
}
