package main

import (
	"github.com/tealeg/xlsx/v3"
	"log"
	"mbtDbUtils/config"
	"mbtDbUtils/db"
	"path"
	"strings"
)

type tlrRoleRel struct {
	tlrNo        string
	roleId       string
	businessLine string
}

var tlrRoleRelList []tlrRoleRel

var roleMap map[string]string

var businessLineList []string

func exportRdmsExcel() {
	file := xlsx.NewFile()
	baseData(file)
	gpBmBranch(file)
	gpBmRoleInfo(file)
	gpBmBusinessLine(file)
	gpBmTlrInfo(file)
	gpBmRoleFuncRel(file)
	rdmsTplRptBusinessLine(file)
	rdmsTplRptCfg(file)
	dataDic(file)
	gpBmSysParam(file)
	err := file.Save(path.Join("out", "RDMS系统初始化.xlsx"))
	if err != nil {
		log.Panicf("保存文件 init.xlsx 失败，错误原因为：%s", err)
	}
}

//dataDic 字典
func dataDic(file *xlsx.File) {
	sheet, err := file.AddSheet("字典")
	if err != nil {
		log.Panicf("新增 sheet 失败，错误原因为：%s", err)
	}
	openFile, err := xlsx.OpenFile("./template/RDMS系统初始化_明细模式.xlsx")
	if err != nil {
		log.Panicf("读取 RDMS系统初始化_明细模式.xlsx 失败，错误原因为：%s", err)
	}
	sheetTpl := openFile.Sheet["字典"]
	var i = 0
	for i < sheetTpl.MaxRow {
		addRow := sheet.AddRow()
		row, err := sheetTpl.Row(i)
		if err != nil {
			log.Panicf("读取 RDMS系统初始化_明细模式.xlsx 基本信息 失败，错误原因为：%s", err)
		}
		addRow.SetHeightCM(1)
		addRow.AddCell().Value = row.GetCell(0).Value
		addRow.AddCell().Value = row.GetCell(1).Value
		addRow.AddCell().Value = row.GetCell(2).Value
		i++
	}
}

//gpBmSysParam 系统初始化参数配置
func gpBmSysParam(file *xlsx.File) {
	sheet, err := file.AddSheet("系统初始化参数配置")
	if err != nil {
		log.Panicf("新增 sheet 失败，错误原因为：%s", err)
	}
	openFile, err := xlsx.OpenFile("./template/RDMS系统初始化_明细模式.xlsx")
	if err != nil {
		log.Panicf("读取 RDMS系统初始化_明细模式.xlsx 失败，错误原因为：%s", err)
	}
	sheetTpl := openFile.Sheet["系统初始化参数配置"]
	var i = 0
	for i < sheetTpl.MaxRow {
		addRow := sheet.AddRow()
		row, err := sheetTpl.Row(i)
		if err != nil {
			log.Panicf("读取 RDMS系统初始化_明细模式.xlsx 基本信息 失败，错误原因为：%s", err)
		}
		addRow.SetHeightCM(1)
		addRow.AddCell().Value = row.GetCell(0).Value
		addRow.AddCell().Value = row.GetCell(1).Value
		addRow.AddCell().Value = row.GetCell(2).Value
		addRow.AddCell().Value = row.GetCell(3).Value
		addRow.AddCell().Value = row.GetCell(4).Value
		i++
	}
}

//baseData 基本信息
func baseData(file *xlsx.File) {
	sheet, err := file.AddSheet("基本信息")
	if err != nil {
		log.Panicf("新增 sheet 失败，错误原因为：%s", err)
	}
	openFile, err := xlsx.OpenFile("./template/RDMS系统初始化_明细模式.xlsx")
	if err != nil {
		log.Panicf("读取 RDMS系统初始化_明细模式.xlsx 失败，错误原因为：%s", err)
	}
	sheetTpl := openFile.Sheet["基本信息"]
	var i = 0
	for i < sheetTpl.MaxRow {
		addRow := sheet.AddRow()
		row, err := sheetTpl.Row(i)
		if err != nil {
			log.Panicf("读取 RDMS系统初始化_明细模式.xlsx 基本信息 失败，错误原因为：%s", err)
		}
		addRow.SetHeightCM(1)
		addRow.AddCell().Value = row.GetCell(0).Value
		addRow.AddCell().Value = row.GetCell(1).Value
		i++
	}
}

func gpBmRoleFuncRel(file *xlsx.File) {
	sheet, err := file.AddSheet("角色功能权限")
	if err != nil {
		log.Panicf("新增 sheet 失败，错误原因为：%s", err)
	}
	addRow := sheet.AddRow()
	addRow.SetHeightCM(1)
	addRow.AddCell().Value = "模块"
	addRow.AddCell().Value = "功能ID"
	addRow.AddCell().Value = "功能名称"
	addRow.AddCell().Value = "类型"
	addRow.AddCell().Value = "上级"
	addRow.AddCell().Value = "地址"
	var roleIdList []string
	for roleId, roleName := range roleMap {
		roleIdList = append(roleIdList, roleId)
		addRow.AddCell().Value = roleName
	}
	roleFuncMap := getRoleFuncMap()
	var funcRoleMap = make(map[string][]string)
	for roleId, funcIdList := range roleFuncMap {
		for funcId := range funcIdList {
			funcRoleMap[funcId] = append(funcRoleMap[funcId], roleId)
		}
	}

	openFile, err := xlsx.OpenFile("./template/RDMS系统初始化_明细模式.xlsx")
	if err != nil {
		log.Panicf("读取 RDMS系统初始化_明细模式.xlsx 失败，错误原因为：%s", err)
	}
	sheetTpl := openFile.Sheet["角色功能权限"]
	var i = 1
	for i < sheetTpl.MaxRow {
		row, err := sheetTpl.Row(i)
		if err != nil {
			log.Panicf("读取 RDMS系统初始化_明细模式.xlsx 失败，错误原因为：%s", err)
		}
		addRow := sheet.AddRow()
		addRow.SetHeightCM(1)
		addRow.AddCell().Value = row.GetCell(0).Value
		addRow.AddCell().Value = row.GetCell(1).Value
		addRow.AddCell().Value = row.GetCell(2).Value
		addRow.AddCell().Value = row.GetCell(3).Value
		addRow.AddCell().Value = row.GetCell(4).Value
		addRow.AddCell().Value = row.GetCell(5).Value
		roleList := funcRoleMap[row.GetCell(1).Value]
		for _, roleId := range roleIdList {
			if indexOfRange(roleList, roleId) {
				addRow.AddCell().Value = "Y"
			} else {
				addRow.AddCell().Value = ""
			}
		}
		i++
	}
}

//indexOfRange 判断 stringList 中是否包含 str
func indexOfRange(stringList []string, str string) bool {
	var i = 0
	for i < len(stringList) {
		if str == stringList[i] {
			return true
		}
		i++
	}
	return false
}

func rdmsTplRptBusinessLine(file *xlsx.File) {
	sheet, err := file.AddSheet("业务线对象权限")
	if err != nil {
		log.Panicf("新增 sheet 失败，错误原因为：%s", err)
	}
	addRow := sheet.AddRow()
	addRow.SetHeightCM(1)
	addRow.AddCell().Value = "报表编码"
	addRow.AddCell().Value = "报表名称"
	for _, businessLine := range businessLineList {
		addRow.AddCell().Value = businessLine
	}
	//查询新数据库
	query, err := db.DoQueryNewString("select REPORT_CODE,REPORT_NAME from RDMS_TPL_RPT_CFG order by REPORT_CODE")
	if err != nil {
		log.Println("查询报表信息错误！")
	}
	for _, rpt := range query {
		addRow := sheet.AddRow()
		addRow.SetHeightCM(1)
		addRow.AddCell().Value = rpt["REPORT_CODE"]
		addRow.AddCell().Value = rpt["REPORT_NAME"]
	}
}

func rdmsTplRptCfg(file *xlsx.File) {
	sheet, err := file.AddSheet("报表信息")
	if err != nil {
		log.Panicf("新增 sheet 失败，错误原因为：%s", err)
	}
	addRow := sheet.AddRow()
	addRow.SetHeightCM(1)
	addRow.AddCell().Value = "报表编码"
	addRow.AddCell().Value = "报表名称"
	//查询新数据库
	query, err := db.DoQueryNewString("select REPORT_CODE,REPORT_NAME from RDMS_TPL_RPT_CFG order by REPORT_CODE")
	if err != nil {
		log.Println("查询报表信息错误！")
	}
	for _, rpt := range query {
		addRow := sheet.AddRow()
		addRow.SetHeightCM(1)
		addRow.AddCell().Value = rpt["REPORT_CODE"]
		addRow.AddCell().Value = rpt["REPORT_NAME"]
	}
}

func gpBmTlrInfo(file *xlsx.File) {
	sheet, err := file.AddSheet("用户")
	if err != nil {
		log.Panicf("新增 sheet 失败，错误原因为：%s", err)
	}
	query, err := db.DoQueryString("select TLRNO,TLR_NAME,BRNO,EMAIL from GP_BM_TLR_INFO")
	if err != nil {
		log.Println("查询用户信息错误！")
	}
	sql := `
select a.TLRNO                                               as TLRNO,
       LISTAGG(a.BRNO, ',') WITHIN GROUP ( ORDER BY a.TLRNO) as BRNO
from (
         select distinct gbti.TLRNO       as TLRNO,
                         gbror.CHG_ORG_ID as BRNO
         from GP_BM_TLR_INFO gbti
                  inner join GP_BM_TLR_ROLE_REL gbtrr
                             on gbti.TLRNO = gbtrr.TLRNO
                  inner join GP_BM_ROLE_ORG_REL gbror on gbtrr.ROLE_ID = gbror.ROLE_ID
                  inner join GP_BM_ROLE_INFO gbri on gbtrr.ROLE_ID = gbri.ROLE_ID
     ) a
group by a.TLRNO`

	orgMap, err := db.QueryMap(sql, "TLRNO", "BRNO", false)

	addRow := sheet.AddRow()
	addRow.SetHeightCM(1)
	addRow.AddCell().Value = "柜员号"
	addRow.AddCell().Value = "柜员名"
	addRow.AddCell().Value = "所属机构"
	addRow.AddCell().Value = "邮箱"
	addRow.AddCell().Value = "用户角色或业务线角色"
	addRow.AddCell().Value = "可操作机构"

	var roleRelMap = make(map[string][]tlrRoleRel)
	for _, roleRel := range tlrRoleRelList {
		roleRelMap[roleRel.tlrNo] = append(roleRelMap[roleRel.tlrNo], roleRel)
	}
	for _, tlrInfo := range query {
		row := sheet.AddRow()
		row.SetHeightCM(1)
		tlrNo := tlrInfo["TLRNO"]
		row.AddCell().Value = tlrNo
		row.AddCell().Value = tlrInfo["TLR_NAME"]
		row.AddCell().Value = tlrInfo["BRNO"]
		row.AddCell().Value = tlrInfo["EMAIL"]
		tlrRoleList := roleRelMap[tlrNo]
		tlrRoleStr := ""
		var i = 0
		for _, tlrRole := range tlrRoleList {
			if i > 0 {
				tlrRoleStr = tlrRoleStr + ";"
			}
			tlrRoleStr = tlrRoleStr + roleMap[tlrRole.roleId]
			if len(roleMap[tlrRole.roleId]) > 0 && len(tlrRole.businessLine) > 0 {
				tlrRoleStr = tlrRoleStr + ","
			}
			tlrRoleStr = tlrRoleStr + tlrRole.businessLine
			i++
		}
		row.AddCell().Value = tlrRoleStr
		row.AddCell().Value = orgMap[tlrInfo["TLRNO"]]
	}

}

func gpBmBusinessLine(file *xlsx.File) {
	sheet, err := file.AddSheet("业务线")
	if err != nil {
		log.Panicf("新增 sheet 失败，错误原因为：%s", err)
	}
	addRow := sheet.AddRow()
	addRow.SetHeightCM(1)
	addRow.AddCell().Value = "业务线编号"
	addRow.AddCell().Value = "业务线名称"
	addRow.AddCell().Value = "角色"
	businessLineRoleMapList, mapListString, done := getBusinessLineRoleMapList()
	if done {
		log.Println("查询业务线信息错误！")
		return
	}
	roleMap, err = db.QueryMap("select ROLE_ID,ROLE_NAME from GP_BM_ROLE_INFO", "ROLE_ID", "ROLE_NAME", false)
	if err != nil {
		log.Panicf("查询角色表 失败，错误原因为：%s", err)
	}
	for businessLine, roleList := range businessLineRoleMapList {
		var i = 0
		var roleStr = ""
		for role := range roleList {
			if i > 0 {
				roleStr = roleStr + ","
			}
			roleStr = roleStr + roleMap[role]
			i++
		}

		addRow := sheet.AddRow()
		addRow.SetHeightCM(1)
		addRow.AddCell().Value = businessLine
		addRow.AddCell().Value = mapListString[businessLine]
		addRow.AddCell().Value = roleStr
	}
}

func getBusinessLineRoleMapList() (map[string]map[string]string, map[string]string, bool) {
	var mapListString = make(map[string]string)
	if config.Cfg.ImportBusinessLineFlag {
		done := importBusinessLineByExcel(mapListString)
		if done {
			return nil, nil, true
		}
	} else {
		done := importBusinessLineByEastDepart(mapListString)
		if done {
			return nil, nil, true
		}
	}

	for businessLine := range mapListString {
		businessLineList = append(businessLineList, businessLine)
	}

	//1、查询 GP_BM_TLR_ROLE_REL 表
	gpBmTlrRoleRelList, err := db.DoQuery("select TLRNO,ROLE_ID from GP_BM_TLR_ROLE_REL")
	if err != nil {
		log.Panicf("查询 GP_BM_TLR_ROLE_REL 表失败，错误原因为：%s", err)
		return nil, nil, true
	}

	tlrMap, err := db.QueryMap("select TLRNO,GROUP_ID from GP_BM_TLR_INFO", "TLRNO", "GROUP_ID", false)
	if err != nil {
		log.Panicf("查询 GP_BM_TLR_INFO 表失败，错误原因为：%s", err)
		return nil, nil, true
	}
	var businessLineRoleMapList = make(map[string]map[string]string)
	//2、处理 GP_BM_TLR_ROLE_REL 表数据
	for _, gpBmTlrRoleRel := range gpBmTlrRoleRelList {
		if gpBmTlrRoleRel["TLRNO"] == nil {
			continue
		}
		tlrNo := gpBmTlrRoleRel["TLRNO"].(string)
		groupId := tlrMap[tlrNo]
		for _, businessLine := range businessLineList {
			//业务线的名字 比部门的名字长，如果业务线名字中 出现了这个部门，业务线授权给这个人。
			//groupId 为 % 是测试用的 账号，应该是拥有所有的权限
			if strings.Index(businessLine, groupId) > -1 || groupId == "%" {
				businessLineRoleMap := businessLineRoleMapList[businessLine]
				var tlrRole tlrRoleRel
				tlrRole.tlrNo = tlrNo
				tlrRole.roleId = gpBmTlrRoleRel["ROLE_ID"].(string)
				tlrRole.businessLine = businessLine
				tlrRoleRelList = append(tlrRoleRelList, tlrRole)
				if businessLineRoleMap == nil {
					businessLineRoleMap = make(map[string]string)
					businessLineRoleMap[gpBmTlrRoleRel["ROLE_ID"].(string)] = ""
				} else {
					businessLineRoleMap[gpBmTlrRoleRel["ROLE_ID"].(string)] = ""
				}
				businessLineRoleMapList[businessLine] = businessLineRoleMap
			}
		}
	}
	return businessLineRoleMapList, mapListString, false
}

func gpBmRoleInfo(file *xlsx.File) {
	sheet, err := file.AddSheet("角色")
	if err != nil {
		log.Panicf("新增 sheet 失败，错误原因为：%s", err)
	}
	query, err := db.DoQueryString("select ROLE_ID,ROLE_NAME from GP_BM_ROLE_INFO")
	if err != nil {
		log.Println("查询角色信息错误！")
	}
	addRow := sheet.AddRow()
	addRow.SetHeightCM(1)
	addRow.AddCell().Value = "角色ID"
	addRow.AddCell().Value = "角色名"
	addRow.AddCell().Value = "角色明细页面按钮权限"
	for _, role := range query {
		row := sheet.AddRow()
		row.SetHeightCM(1)
		row.AddCell().Value = role["ROLE_ID"]
		roleName := role["ROLE_NAME"]
		row.AddCell().Value = roleName
		if strings.HasSuffix(strings.ToUpper(roleName), strings.ToUpper("Maker")) {
			row.AddCell().Value = "BTN_ADD,BTN_DEL,BTN_CHECK,BTN_CHECK_RESULT,btUpload,btExport,btProblemExport,BTN_COMMIT,btnBizIdChg,btnDel,btnReset"
		} else if strings.HasSuffix(strings.ToUpper(roleName), strings.ToUpper("Checker")) {
			row.AddCell().Value = "BTN_APPROVE,BTN_REJECT,BTN_SEND_BACK,btnApvSendBack"
		} else if strings.HasSuffix(strings.ToUpper(roleName), strings.ToUpper("Admin")) {
			row.AddCell().Value = "BTN_ADD,BTN_DEL,BTN_CHECK,BTN_CHECK_RESULT,btUpload,btExport,btProblemExport,BTN_COMMIT,btnBizIdChg,btnDel,btnReset" + "," + "BTN_APPROVE,BTN_REJECT,BTN_SEND_BACK,btnApvSendBack"
		} else {
			row.AddCell().Value = ""
		}
	}
}

func gpBmBranch(file *xlsx.File) {
	sheet, err := file.AddSheet("机构")
	if err != nil {
		log.Panicf("新增 sheet 失败，错误原因为：%s", err)
	}
	query, err := db.DoQueryString("select BRNO,BRNAME,BRATTR,BLN_UP_BRCODE from GP_BM_BRANCH")
	if err != nil {
		log.Println("查询机构信息错误！")
	}
	openFile, err := xlsx.OpenFile("./template/RDMS系统初始化_明细模式.xlsx")
	if err != nil {
		log.Panicf("读取 RDMS系统初始化_明细模式.xlsx 失败，错误原因为：%s", err)
	}
	brattrMap := make(map[string]string)
	sheetTpl := openFile.Sheet["字典"]
	var i = 1
	for i < sheetTpl.MaxRow {
		row, err := sheetTpl.Row(i)
		if err != nil {
			log.Panicf("读取 RDMS系统初始化_明细模式.xlsx 失败，读取数据字典错误，错误原因为：%s", err)
		}
		if row.GetCell(0).Value == "机构类别" {
			brattrMap[row.GetCell(1).Value] = row.GetCell(2).Value
		}
		i++
	}

	addRow := sheet.AddRow()
	addRow.SetHeightCM(1)
	addRow.AddCell().Value = "机构号"
	addRow.AddCell().Value = "行名"
	addRow.AddCell().Value = "机构类别"
	addRow.AddCell().Value = "上级机构代码"
	for _, branch := range query {
		row := sheet.AddRow()
		row.SetHeightCM(1)
		row.AddCell().Value = branch["BRNO"]
		row.AddCell().Value = branch["BRNAME"]
		row.AddCell().Value = brattrMap[branch["BRATTR"]]
		if branch["BLN_UP_BRCODE"] == "" {
			row.AddCell().Value = "0"
		} else {
			row.AddCell().Value = branch["BLN_UP_BRCODE"]
		}
	}
}
