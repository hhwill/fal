package main

import (
	"bytes"
	"flag"
	"fmt"
	uuid "github.com/satori/go.uuid"
	"github.com/tealeg/xlsx/v3"
	"golang.org/x/text/encoding/simplifiedchinese"
	"golang.org/x/text/transform"
	"io/ioutil"
	"log"
	"mbtDbUtils/config"
	"mbtDbUtils/db"
	"os"
	"path/filepath"
)

func main() {
	var exportExcel = flag.String("flag", "2", "导出批量任务Excel")
	flag.Parse()

	config.Cfg.Load()
	err := db.Connection()
	if err != nil {
		log.Fatalf("连接数据库失败，错误原因：%s\n", err)
	}
	defer db.Con.Close()
	defer db.ConNew.Close()
	createUser()
	if *exportExcel == "1" {
		log.Print("导出批量任务Excel！")
		ExportExcel()
		//initTable() 不需要生成 初始化的SQL语句
		log.Print("导出结束！")
	} else if *exportExcel == "2" {
		exportRdmsExcel()
	} else if *exportExcel == "3" {
		importFuncData()
		jmSql()
	} else {
		createSqlFile()
	}

}

func jmSql() {
	insertSql := `
INSERT INTO GP_BM_JM (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID, JOB_NAME, JOB_TYPE,
                      JOB_DESC, JOB_ACTIVED, RUN_FREQ, MONTH_SET, OFFSET_WD_FLAG, OFFSET_VALUE, OFFSET_PRE_POST_FLAG,
                      CALENDAR, WEEKDAY_SET, CRON, RUN_TIME_TYPE, RUN_TIME, RUN_INTERVAL, RUN_INT_UNIT,
                      RUN_INT_BEGIN_TIME, RUN_INT_END_TIME, LAST_RUN_RST, LAST_RUN_TIME, NEXT_RUN_TIME, CHECK_FLAG,
                      CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE,
                      DATA_VERSION, DATA_HASH, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                      DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, EXCEPTION_HANDING_EXPR)
VALUES ('%s', '20210414', 'GINGKOO', '9999', 'HZ', null, null, 'batchValidate_%s',
        'SINGLESTEP', null, 'Y', 'WD', null, null, null, null, null, null, null, 'SING ', '00:05:00      ', null, null,
        null, null, 'SUCC', '20210414164117', null, null, null, null, null, null, 'Y', null, null, 1, null, null, null,
        'admin', '20210414', '20210414163200', 'admin', '20210414', '20210414163442', null, null, null, null, null,
        null, null, null, null);
INSERT INTO GP_BM_JM_BATCH (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID, TRANSACTIONAL,
                            PARALLEL, RETRY_TYPE, RETRY_MAX, RETRY_INTERVAL, BEGIN_TIME, END_TIME, RUN_ORDER, STEP_EXPR,
                            CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_OP,
                            DATA_SOURCE, DATA_VERSION, DATA_HASH, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER,
                            DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                            DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5)
VALUES ('%s', '20210414', 'GINGKOO', '9999', 'HZ', null, null, null, null, 'OFF', null,
        null, null, null, null, 'mbtBatchValidateService,CMD:CALL,rptDate:20210410,infRecType:%s,condition:', null,
        null, null, null, null, null, null, null, 1, null, null, null, 'admin', '20210414', '20210414163200', 'admin',
        '20210414', '20210414163442', null, null, null, null, null, null, null, null);
`
	var array1 = [20]string{
		"210",
		"220",
		"230",
		"410",
		"420",
		"440",
		"110",
		"120",
		"130",
		"140",
		"215",
		"310",
		"340",
		"350",
		"510",
		"610",
		"620",
		"630",
		"640",
		"650",
	}
	for _, reportId := range array1 {
		dataId := uuid.NewV4().String()
		println(fmt.Sprintf(insertSql, dataId, reportId, dataId, reportId))
	}

}

func initTable() {
	file, err := xlsx.OpenFile("./xlsx/init_table.xlsx")
	panicError(err)
	sheet := file.Sheet["Sheet1"]
	var i = 0
	var sqlList []string
	for i < sheet.MaxRow {
		row, err := sheet.Row(i)
		panicError(err)
		if len(row.GetCell(0).Value) > 0 {
			sqlList = append(sqlList, db.NewSyncTable(row.GetCell(0).Value, "")...)
		}
		i++
	}
	f, err := os.OpenFile("./sql/initSql.sql", os.O_WRONLY|os.O_TRUNC|os.O_CREATE, 0600)
	defer f.Close()
	if err != nil {
		log.Printf(err.Error())
	} else {
		for _, sqlStr := range sqlList {
			_, err = f.Write([]byte(sqlStr))
			if err != nil {
				log.Printf("把SQL写入到文件失败[%s]", err)
			}
		}
	}
}

//导入菜单数据 生成菜单对应关系，然后人工调整
func importFuncData() {
	log.Print("开始读取菜单！")
	//读取新老菜单对应关系
	file, err := xlsx.OpenFile("./xlsx/菜单对应关系表.xlsx")
	panicError(err)
	sheet := file.Sheet["菜单对应关系表"]
	var i = 1
	var oldFuncMap = make(map[string]string)
	var newFuncMap = make(map[string]string)
	var funcIdMap = make(map[string]string)
	for i < sheet.MaxRow {
		row, err := sheet.Row(i)
		panicError(err)
		if len(row.GetCell(1).Value) > 0 && len(row.GetCell(2).Value) > 0 {
			oldFuncMap[row.GetCell(1).Value] = row.GetCell(2).Value
		}
		if len(row.GetCell(5).Value) > 0 && len(row.GetCell(4).Value) > 0 {
			funcIdMap[row.GetCell(5).Value] = row.GetCell(4).Value
		}
		if len(row.GetCell(8).Value) > 0 && len(row.GetCell(9).Value) > 0 {
			value := row.GetCell(8).Value
			newFuncMap[value] = row.GetCell(9).Value
		}
		i++
	}
	fileName := fmt.Sprintf(filepath.Join("xlsx", "view.csv"))
	csvFile, err := os.OpenFile(fileName, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0666)
	panicError(err)
	for funcNewId, funcOldId := range funcIdMap {
		s := funcNewId + "," + funcOldId + "," + newFuncMap[funcNewId] + "," + oldFuncMap[funcOldId] + "\n"
		gbk, err := Utf8ToGbk([]byte(s))
		panicError(err)
		_, err = csvFile.Write(gbk)
	}

}

func Utf8ToGbk(s []byte) ([]byte, error) {
	reader := transform.NewReader(bytes.NewReader(s), simplifiedchinese.GBK.NewEncoder())
	d, e := ioutil.ReadAll(reader)
	if e != nil {
		return nil, e
	}
	return d, nil
}
