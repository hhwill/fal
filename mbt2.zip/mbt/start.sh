export PATH=/opt/oracle/instantclient_12_2:$PATH
export LD_LIBRARY_PATH=/opt/oracle/instantclient_12_2:$LD_LIBRARY_PATH

./mbtDbUtils