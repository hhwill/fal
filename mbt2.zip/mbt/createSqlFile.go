package main

import (
	"fmt"
	"log"
	"mbtDbUtils/config"
	"mbtDbUtils/db"
	"os"
	"path"
)

func createSqlFile() {
	//判断输出目录是否存在，不存在就创建
	filePath := path.Join("sql", "delete")
	exists, err := PathExists(filePath)
	if err != nil {
		fmt.Printf("PathExists(%s),err(%v)\n", filePath, err)
	}
	if !exists {
		err = os.MkdirAll(filePath, 0766)
		if err != nil {
			fmt.Printf("creart file path error (%s),err(%v)\n", filePath, err)
		}
	}

	var sqlList []string
	sqlList = append(sqlList, importRoleFuncRel()...)
	sqlList = append(sqlList, CtlCfgToJob()...)
	sqlList = append(sqlList, importBusinessLine()...)
	sqlList = append(sqlList, importDataDic()...)
	for tableName, tableConfig := range config.Cfg.SyncTableList {
		if tableConfig["Type"] == "sql" {
			sqlList = append(sqlList, db.SyncTable(tableName, tableConfig["sql"])...)
		} else {
			sqlList = append(sqlList, db.SyncTable(tableName, "")...)
		}
	}
	sqlList = append(sqlList, "-- 特殊处理 顶级机构的上级机构为 0 原版本顶级机构为 null\n"+
		"update GP_BM_BRANCH set BLN_UP_BRCODE = '0' where BLN_UP_BRCODE is null;")

	f, err := os.OpenFile("./sql/allSql.sql", os.O_WRONLY|os.O_TRUNC|os.O_CREATE, 0600)
	defer f.Close()
	if err != nil {
		log.Printf(err.Error())
	} else {
		for _, sqlStr := range sqlList {
			_, err = f.Write([]byte(sqlStr))
			if err != nil {
				log.Printf("把SQL写入到文件失败[%s]", err)
			}
		}
	}
	log.Printf("生成成功！")
}

func PathExists(path string) (bool, error) {
	_, err := os.Stat(path)
	if err == nil {
		return true, nil
	}
	if os.IsNotExist(err) {
		return false, nil
	}
	return false, err
}
