package main

import (
	"fmt"
	uuid "github.com/satori/go.uuid"
	"github.com/tealeg/xlsx/v3"
	"log"
	"mbtDbUtils/config"
	"mbtDbUtils/db"
	"strings"
)

// 角色菜单导入维护  可以根据下级补全上级
func importRoleFuncRel() []string {
	log.Print("开始读取菜单！")
	roleFuncMap := getRoleFuncMap()

	//生成SQL语句
	var sqlList []string
	roleFuncSqlStr := `INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('%s', '%s', '%s', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);`
	var dataIdList []string
	for roleId, funcIdList := range roleFuncMap {
		for funcId := range funcIdList {
			dataId := uuid.NewV4().String()
			if config.Cfg.DeleteSqlFlag {
				sqlList = append(sqlList, db.GetDeleteSql("GP_BM_ROLE_FUNC_REL", dataId))
			}
			dataIdList = append(dataIdList, dataId)
			roleFuncSql := fmt.Sprintf(roleFuncSqlStr, dataId, roleId, funcId) + "\n"
			sqlList = append(sqlList, roleFuncSql)
		}
	}
	db.CreateDeleteSqlFile("GP_BM_ROLE_FUNC_REL", dataIdList)
	sqlFile := db.GenerateSqlFile(sqlList, "GP_BM_ROLE_FUNC_REL")
	log.Print("菜单SQL生成结束！")
	return sqlFile
}

func getRoleFuncMap() map[string]map[string]string {
	//读取新老菜单对应关系
	file, err := xlsx.OpenFile("./xlsx/菜单对应关系表.xlsx")
	panicError(err)
	sheet := file.Sheet["菜单对应关系表"]
	var i = 1
	var mapListString = make(map[string][]string)
	for i < sheet.MaxRow {
		row, err := sheet.Row(i)
		panicError(err)
		if len(row.GetCell(4).Value) > 0 && len(row.GetCell(5).Value) > 0 {
			mapListString[row.GetCell(4).Value] = append(mapListString[row.GetCell(4).Value], row.GetCell(5).Value)
		}
		i++
	}
	fileConfig, err := xlsx.OpenFile("./xlsx/config.xlsx")
	panicError(err)
	btnSheet := fileConfig.Sheet["按钮权限配置"]
	i = 1
	// 放置 角色名称结尾的 key value 是角色 应该拥有的按钮
	var btnMap = make(map[string][]string)
	for i < btnSheet.MaxRow {
		row, err := btnSheet.Row(i)
		panicError(err)
		if len(row.GetCell(0).Value) > 0 && len(row.GetCell(1).Value) > 0 {
			btnMap[row.GetCell(0).Value] = append(btnMap[row.GetCell(0).Value], row.GetCell(1).Value)
		}
		i++
	}

	//读取 老系统中的 角色菜单对应关系
	queryMapList, err := db.DoQueryMapList("select gbrfr.ROLE_ID,gbrfr.FUNCID,gbri.ROLE_NAME from GP_BM_ROLE_FUNC_REL gbrfr inner join GP_BM_ROLE_INFO gbri on gbrfr.ROLE_ID = gbri.ROLE_ID\n", "FUNCID")
	//读取 老系统中的 角色列表 用来判断 角色为 maker 还是checker
	//roleList, err := db.DoQueryRoleInfo()
	panicError(err)
	//log.Print(roleList)
	//读取新系统中的菜单列表，用作获取上级菜单的信息
	queryMap, err := db.QueryMap("select FUNCID,LASTDIRECTORY from GP_BM_FUNCTION", "FUNCID", "LASTDIRECTORY", true)
	//获取新系统中所有为 菜单级别的 func id
	isDirectoryMap, err := db.QueryMap("select FUNCID,'0' as ISDIRECTORY from GP_BM_FUNCTION where ISDIRECTORY = '0'", "FUNCID", "ISDIRECTORY", true)
	panicError(err)
	var roleFuncMap = make(map[string]map[string]string)
	for funcId, roleFuncList := range queryMapList {
		funcNewList := mapListString[funcId]
		for _, roleFunc := range roleFuncList {
			roleId := roleFunc["ROLE_ID"].(string)
			roleName := roleFunc["ROLE_NAME"].(string)
			funcMap := roleFuncMap[roleId]
			if funcMap == nil {
				funcMap = make(map[string]string)
			}
			for _, funcNewId := range funcNewList {
				//当前菜单下面有按钮
				if isDirectoryMap[funcNewId] == "0" {
					for roleNameKey, btnNameList := range btnMap {
						if strings.HasSuffix(roleName, roleNameKey) {
							for _, btnName := range btnNameList {
								btnStr := "BTN@" + funcNewId + "_" + btnName
								funcMap[btnStr] = ""
							}
						}
					}
				}

				for {
					upFuncNewId := queryMap[funcNewId]
					if upFuncNewId == "" {
						log.Printf("未找到的funcId %s", funcNewId)
						break
					} else {
						funcMap[funcNewId] = ""
						funcMap[upFuncNewId] = ""
					}
					funcMap[upFuncNewId] = ""
					if upFuncNewId == "0" {
						break
					}
					funcNewId = upFuncNewId
				}
			}
			roleFuncMap[roleId] = funcMap
		}
	}
	return roleFuncMap
}
