package main

import (
	"github.com/tealeg/xlsx/v3"
	"log"
	"path"
)

func createUser() {
	file := xlsx.NewFile()
	sheet, err := file.AddSheet("用户")
	if err != nil {
		log.Panicf("新增 sheet 失败，错误原因为：%s", err)
	}
	var mapListString = make(map[string]string)
	var roleMap = map[string]string{"补录员": "maker", "审核员": "checker", "查询员": "query"}
	importBusinessLineByExcel(mapListString)
	var businessMap = make(map[string][]string)
	for businessLine, _ := range mapListString {
		businessMap[businessLine[0:3]] = append(businessMap[businessLine[0:3]], businessLine)
	}
	for business, businessList := range businessMap {
		for roleName, roleId := range roleMap {
			row := sheet.AddRow()
			row.SetHeightCM(1)
			row.AddCell().Value = "HSBC" + business + roleId
			row.AddCell().Value = "HSBC" + business + roleId
			row.AddCell().Value = "PUO"
			row.AddCell().Value = "HSBC@qq.com"
			var businessLineName = ""
			for _, business := range businessList {
				if len(businessLineName) > 0 {
					businessLineName = businessLineName + ";" + roleName + "," + business
				}else {
					businessLineName =  roleName + "," + business
				}
			}
			row.AddCell().Value = businessLineName

		}
	}


	err = file.Save(path.Join("out", "user.xlsx"))
	if err != nil {
		log.Panicf("保存文件 init.xlsx 失败，错误原因为：%s", err)
	}
}
