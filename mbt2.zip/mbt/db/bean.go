package db

// RoleInfo 角色
type RoleInfo struct {
	//角色ID
	roleId string
	//角色名称
	roleName string
}
