package db

import (
	"database/sql"
	_ "github.com/mattn/go-oci8"
	"log"
)

var (
	Con    *sql.DB
	ConNew *sql.DB
)

func InitOracleOci8(dbConnStr string) error {
	log.Printf("Open oracle connection [%s]", dbConnStr)
	var err error
	Con, err = sql.Open("oci8", dbConnStr)
	if err != nil {
		log.Printf("Open database fail, err=[%v]\n", err)
		return err
	}
	//defer Con.Close()

	if err := Con.Ping(); err != nil {
		log.Printf("Cannot ping database, err=[%v]\n", err)
		return err
	}

	if _, err := Con.Query("select 1 from dual"); err != nil {
		log.Printf("Test query fail, err=[#{err}]\n")
		return err
	}

	return nil
}

func InitOracleOci8New(dbConnStr string) error {
	log.Printf("Open oracle connection [%s]", dbConnStr)
	var err error
	ConNew, err = sql.Open("oci8", dbConnStr)
	if err != nil {
		log.Printf("Open database fail, err=[%v]\n", err)
		return err
	}
	//defer Con.Close()

	if err := ConNew.Ping(); err != nil {
		log.Printf("Cannot ping database, err=[%v]\n", err)
		return err
	}

	if _, err := ConNew.Query("select 1 from dual"); err != nil {
		log.Printf("Test query fail, err=[#{err}]\n")
		return err
	}

	return nil
}
