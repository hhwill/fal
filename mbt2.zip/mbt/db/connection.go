package db

import (
	"fmt"
	"log"
	"mbtDbUtils/config"
)

func Connection() error {
	dbConnStr := fmt.Sprintf("%s/%s@%s", config.Cfg.Username, config.Cfg.Password, config.Cfg.ConnString)
	dbConnStrNew := fmt.Sprintf("%s/%s@%s", config.Cfg.UsernameNew, config.Cfg.PasswordNew, config.Cfg.ConnStringNew)
	err := InitOracleOci8(dbConnStr)
	err = InitOracleOci8New(dbConnStrNew)
	//err := db.InitOracle(cfg.Username, cfg.Password, cfg.ConnString)
	if err != nil {
		log.Printf("Open oracle connection error[%s]", err)
	}

	return err
}
