package db

import (
	"database/sql"
	"fmt"
	uuid "github.com/satori/go.uuid"
	"log"
	"mbtDbUtils/config"
	"os"
	"path"
	"strconv"
	"strings"
)

// 查询结果返回map flag 为 true 时 查询新数据库 ，为false时查询老数据库
func QueryMap(sqlInfo string, id string, value string, flag bool, args ...interface{}) (map[string]string, error) {
	var rows *sql.Rows
	var err error
	if flag {
		rows, err = ConNew.Query(sqlInfo, args...)
	} else {
		rows, err = Con.Query(sqlInfo, args...)
	}
	if err != nil {
		return nil, err
	}
	columns, _ := rows.Columns()
	columnLength := len(columns)
	cache := make([]interface{}, columnLength) //临时存储每行数据
	for index := range cache {                 //为每一列初始化一个指针
		var a interface{}
		cache[index] = &a
	}
	var queryMap = make(map[string]string) //返回的切片
	for rows.Next() {
		_ = rows.Scan(cache...)

		item := make(map[string]interface{})
		for i, data := range cache {
			item[columns[i]] = *data.(*interface{}) //取实际类型
		}
		if item[value] == nil {
			item[value] = ""
		}
		if item[id] == nil || item[value] == nil {
			continue
		}
		switch item[value].(type) {
		case string:
			queryMap[item[id].(string)] = item[value].(string)
		case float64:
			queryMap[item[id].(string)] = strconv.FormatFloat(item[value].(float64), 'E', -1, 64)
		}
		//queryMap[item[id].(string)] = item[value].(string)
	}
	_ = rows.Close()
	return queryMap, nil
}

// 查询结果返回map
func DoQuery(sqlInfo string) ([]map[string]interface{}, error) {
	rows, err := Con.Query(sqlInfo)
	if err != nil {
		return nil, err
	}
	columns, _ := rows.Columns()
	columnLength := len(columns)
	cache := make([]interface{}, columnLength) //临时存储每行数据
	for index := range cache {                 //为每一列初始化一个指针
		var a interface{}
		cache[index] = &a
	}
	var list []map[string]interface{} //返回的切片
	for rows.Next() {
		_ = rows.Scan(cache...)

		item := make(map[string]interface{})
		for i, data := range cache {
			item[columns[i]] = *data.(*interface{}) //取实际类型
		}
		list = append(list, item)
	}
	_ = rows.Close()
	return list, nil
}

func DoQueryString(sqlInfo string) ([]map[string]string, error) {
	rows, err := Con.Query(sqlInfo)
	if err != nil {
		return nil, err
	}
	columns, _ := rows.Columns()
	columnLength := len(columns)
	cache := make([]interface{}, columnLength) //临时存储每行数据
	for index := range cache {                 //为每一列初始化一个指针
		var a interface{}
		cache[index] = &a
	}
	var list []map[string]string //返回的切片
	for rows.Next() {
		_ = rows.Scan(cache...)

		item := make(map[string]string)
		for i, data := range cache {
			item[columns[i]] = ConvertValueNew(*data.(*interface{})) //取实际类型
		}
		list = append(list, item)
	}
	_ = rows.Close()
	return list, nil
}

func DoQueryNewString(sqlInfo string) ([]map[string]string, error) {
	rows, err := ConNew.Query(sqlInfo)
	if err != nil {
		return nil, err
	}
	columns, _ := rows.Columns()
	columnLength := len(columns)
	cache := make([]interface{}, columnLength) //临时存储每行数据
	for index := range cache {                 //为每一列初始化一个指针
		var a interface{}
		cache[index] = &a
	}
	var list []map[string]string //返回的切片
	for rows.Next() {
		_ = rows.Scan(cache...)

		item := make(map[string]string)
		for i, data := range cache {
			item[columns[i]] = ConvertValueNew(*data.(*interface{})) //取实际类型
		}
		list = append(list, item)
	}
	_ = rows.Close()
	return list, nil
}

// DoQueryMap 查询结果返回map
func DoQueryMap(sqlInfo string, id string, args ...interface{}) (map[string]map[string]interface{}, error) {
	rows, err := Con.Query(sqlInfo, args...)
	if err != nil {
		return nil, err
	}
	columns, _ := rows.Columns()
	columnLength := len(columns)
	cache := make([]interface{}, columnLength) //临时存储每行数据
	for index := range cache {                 //为每一列初始化一个指针
		var a interface{}
		cache[index] = &a
	}
	var queryMap = make(map[string]map[string]interface{}) //返回的切片
	for rows.Next() {
		_ = rows.Scan(cache...)

		item := make(map[string]interface{})
		for i, data := range cache {
			item[columns[i]] = *data.(*interface{}) //取实际类型
		}
		queryMap[item[id].(string)] = item
	}
	_ = rows.Close()
	return queryMap, nil
}

// DoQueryRoleInfo 查询老数据库角色表
func DoQueryRoleInfo() ([]RoleInfo, error) {
	var roleInfoList []RoleInfo
	rows, err := Con.Query("select NVL(ROLE_ID,''),NVL(ROLE_NAME,'') from GP_BM_ROLE_INFO")
	if err != nil {
		return nil, err
	}
	var roleInfo RoleInfo
	for rows.Next() {
		err = rows.Scan(&roleInfo.roleId, &roleInfo.roleName)
		if err != nil {
			return nil, err
		}
		roleInfoList = append(roleInfoList, roleInfo)
	}
	return roleInfoList, nil
}

func DoQueryMapList(sqlInfo string, id string, args ...interface{}) (map[string][]map[string]interface{}, error) {
	rows, err := Con.Query(sqlInfo, args...)
	if err != nil {
		return nil, err
	}
	columns, _ := rows.Columns()
	columnLength := len(columns)
	cache := make([]interface{}, columnLength) //临时存储每行数据
	for index := range cache {                 //为每一列初始化一个指针
		var a interface{}
		cache[index] = &a
	}
	var queryMap = make(map[string][]map[string]interface{}) //返回的切片
	for rows.Next() {
		_ = rows.Scan(cache...)

		item := make(map[string]interface{})
		for i, data := range cache {
			item[columns[i]] = *data.(*interface{}) //取实际类型
		}
		if item[id] == nil { // 返回map 的key 不可以为 nil
			continue
		}
		queryMap[item[id].(string)] = append(queryMap[item[id].(string)], item)
	}
	_ = rows.Close()
	return queryMap, nil
}

func GenSql(tableName string, cols map[string]interface{}) (string, string) {
	var colsStr = ""
	var valStr = ""
	var deleteSqlStr = ""
	for k, v := range cols {
		if len(colsStr) > 0 {
			colsStr = colsStr + ","
			valStr = valStr + ","
		}
		if k == "DATA_ID" {
			_, ok := v.(string)
			if !ok {
				v = uuid.NewV4().String()
			}
			deleteSqlStr = fmt.Sprintf("delete from %s where data_id = '%s';\n", tableName, v)
		}
		defaultValue := config.Cfg.SyncTableList[tableName][k]
		if len(defaultValue) > 0 {
			v = defaultValue
		}
		colsStr = colsStr + k
		valStr = valStr + ConvertValue(v)
	}
	for col := range config.Cfg.SyncTableList[tableName] {
		if (!strings.Contains(colsStr, col)) && col != "Type" && col != "sql" {
			colsStr = colsStr + "," + col
			defaultValue := config.Cfg.SyncTableList[tableName][col]
			valStr = valStr + "," + ConvertValue(defaultValue)
		}
	}

	sqlStr := fmt.Sprintf("insert into %s (%s) values(%s);\n", tableName, colsStr, valStr)
	return sqlStr, deleteSqlStr
}

// GetDeleteSql 生成删除 SQL语句
func GetDeleteSql(tableName string, dataId string) string {
	return fmt.Sprintf("delete from %s where data_id = '%s';\n", tableName, dataId)
}

func ConvertValueNew(value interface{}) string {
	if value == nil {
		return ""
	}
	switch value := value.(type) {
	case int:
		return strconv.Itoa(value)
	case int64:
		return strconv.FormatInt(value, 10)
	case float32:
	case float64:
		return strconv.FormatFloat(value, 'f', 6, 64)
	case string:
		return value
	case []uint8:
		return B2S(value)
	default:
		return ""
	}
	return ""
}

func ConvertValue(value interface{}) string {
	if value == nil {
		return "null"
	}
	switch value := value.(type) {
	case int:
		return strconv.Itoa(value)
	case int64:
		return strconv.FormatInt(value, 10)
	case float32:
	case float64:
		return strconv.FormatFloat(value, 'f', 6, 64)
	case string:
		value = strings.Replace(value, "'", "''", -1)
		return "'" + value + "'"
	case []uint8:
		return B2S(value)
	default:
		return "null"
	}
	return "null"
}

func B2S(bs []uint8) string {
	var ba []byte
	for _, b := range bs {
		ba = append(ba, b)
	}
	return string(ba)
}
func CreateDeleteSqlFile(tableName string, dataIdList []string) {
	deleteFilePathName := path.Join("./sql", "delete", tableName+"_delete.sql")
	deleteF, err := os.OpenFile(deleteFilePathName, os.O_WRONLY|os.O_TRUNC|os.O_CREATE, 0600)
	checkErr(err)
	defer deleteF.Close()
	for _, dataId := range dataIdList {
		_, err = deleteF.Write([]byte(GetDeleteSql(tableName, dataId)))
	}
}
func GenSqlList(tableName string, branchList []map[string]interface{}) []string {
	var sqlList []string
	filePathName := path.Join("./sql", tableName+".sql")
	deleteFilePathName := path.Join("./sql", "delete", tableName+"_delete.sql")
	f, err := os.OpenFile(filePathName, os.O_WRONLY|os.O_TRUNC|os.O_CREATE, 0600)
	defer f.Close()
	deleteF, err := os.OpenFile(deleteFilePathName, os.O_WRONLY|os.O_TRUNC|os.O_CREATE, 0600)
	defer deleteF.Close()
	checkErr(err)
	for _, branch := range branchList {
		sqlStr, deleteSqlStr := GenSql(tableName, branch)
		if config.Cfg.DeleteSqlFlag {
			_, err = f.Write([]byte(deleteSqlStr))
			checkErr(err)
			sqlList = append(sqlList, deleteSqlStr)
		}
		_, err = deleteF.Write([]byte(deleteSqlStr))
		_, err = f.Write([]byte(sqlStr))
		checkErr(err)
		sqlList = append(sqlList, sqlStr)
	}
	return sqlList
}

// GenerateSqlFile 生成SQL文件
func GenerateSqlFile(sqlList []string, fileName string) []string {
	filePathName := path.Join("./sql", fileName+".sql")
	f, err := os.OpenFile(filePathName, os.O_WRONLY|os.O_TRUNC|os.O_CREATE, 0600)
	defer f.Close()
	checkErr(err)
	for _, sqlStr := range sqlList {
		_, err = f.Write([]byte(sqlStr))
		checkErr(err)
	}
	return sqlList
}

func checkErr(err error) {
	if err != nil {
		log.Printf(err.Error())
	}
}

func SyncTable(tableName string, sql string) []string {
	var query []map[string]interface{}
	var err error
	if len(sql) > 0 {
		query, err = DoQuery(sql)
	} else {
		query, err = DoQuery(fmt.Sprintf("select * from %s", tableName))
	}

	if err != nil {
		log.Printf("生成SQL异常 tableName为%s：查询数据库异常%s", tableName, err)
	}
	return GenSqlList(tableName, query)
}

func NewSyncTable(tableName string, sql string) []string {
	var query []map[string]interface{}
	var err error
	if len(sql) > 0 {
		query, err = newDoQuery(sql)
	} else {
		query, err = newDoQuery(fmt.Sprintf("select * from %s", tableName))
	}

	if err != nil {
		log.Printf("生成SQL异常 tableName为%s：查询数据库异常%s", tableName, err)
	}
	return GenSqlList(tableName, query)
}

// 查询结果返回map
func newDoQuery(sqlInfo string) ([]map[string]interface{}, error) {
	rows, err := ConNew.Query(sqlInfo)
	if err != nil {
		return nil, err
	}
	columns, _ := rows.Columns()
	columnLength := len(columns)
	cache := make([]interface{}, columnLength) //临时存储每行数据
	for index := range cache {                 //为每一列初始化一个指针
		var a interface{}
		cache[index] = &a
	}
	var list []map[string]interface{} //返回的切片
	for rows.Next() {
		_ = rows.Scan(cache...)

		item := make(map[string]interface{})
		for i, data := range cache {
			item[columns[i]] = *data.(*interface{}) //取实际类型
		}
		list = append(list, item)
	}
	_ = rows.Close()
	return list, nil
}

//////// 不生成 truncate table 语句
//判断是否需要生成  truncate table 语句
//if config.Cfg.TruncateTable {
//	truncateSql := fmt.Sprintf("truncate table %s;\n", tableName)
//	sqlList = append(sqlList, truncateSql)
//	_, err = f.Write([]byte(truncateSql))
//}
//checkErr(err)
