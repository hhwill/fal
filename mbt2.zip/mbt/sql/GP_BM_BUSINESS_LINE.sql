INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('67cca59f-274d-4687-a261-666b2a2ada18', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'GTRF(DC)', '(信用证)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('affe5a3a-636d-4567-9aca-7e7fd8f24adb', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'CDT(EL-CMB)', '(委托贷款)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('0f6ff354-a4d8-415d-95fd-6fc6b1e4961e', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'GTRF(BADD)', '(票据贴现)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('dfbba7e1-ba35-4601-8903-d9ebe076212f', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'GTRF(OAM)', '(进口押汇(SCF/OAM))', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('c602f6fb-eb83-4929-a2c5-719da7b12ef0', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'CDT(OD-GB)', '(透支)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('7bb276aa-999c-4be4-82ec-a35db05e0950', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'GDL', '(黄金借贷)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('24dc4ccb-d237-4abb-8a30-29dfbe4c5add', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'RBWM(MGT)', '(个人房贷)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('339a83b9-0026-4c6e-bc05-4288c6b21a54', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'RBWM(SBO)', '(个人RBB)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('24339971-c70a-4996-a853-6a6004e1eecb', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'WCAS(BRANCH)', '(企业基本信息)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('664f18c4-648f-4d21-9872-8862b8b4e0f0', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'CDT(CMB)', '(企业贷款)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('87576ec3-341b-48ec-a7f3-6790d6149d99', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'CDT', '[(企业贷款，企业抵质押)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('07648751-7a94-47b3-aa27-da87a6009166', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'CDT(EL-GB)', '(委托贷款)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('f3ac7658-1e3e-4f3a-9a36-4384a833de61', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'CDT(OD-CMB)', '(透支)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('30bfe27b-9844-4b45-bef5-7616a46e31d4', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'GTRF(TF)', '(贸易融资)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('eb62baf3-43a0-49f0-8a0f-b2a9a5922e9f', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'RBWM(UPL)', '(P-LOAN)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('d5d76a9d-ee60-41f8-9ae9-c5d324434b6b', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'CDT(CL-RBB)', '(企业贷款)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('6bc34741-4894-4f6b-aea7-f41c2e91346e', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'CDT(RBB)', '(企业贷款)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('ced51321-c36f-4929-a0e2-c267a7ac48fd', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'GTRF(GTE)', '(保函)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('da62496f-bc27-4d56-8a84-1378bc3c6dd1', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'GTRF(RFN)', '(保理融资，贸易融资)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('7cef8f20-8c0f-45fb-a2df-6bda55da2ee4', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'GTRF(BADI)', '(银行承兑汇票)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('5a876f29-86fb-412a-a4f2-8e13badb2c89', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'CDT(CL-CMB)', '(企业贷款)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('45d12a3a-2e27-4399-a286-1d1123295c83', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'CDT(CL-GB)', '(企业贷款)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('e92db14c-22de-4064-bf79-bc85cf5ce16d', '20210105', 'GINGKOO', '9999', 'XD', null, null, 'CDT(GB)', '(企业贷款)', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');
