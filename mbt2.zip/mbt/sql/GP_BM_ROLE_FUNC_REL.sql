INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('b993a489-927d-40e7-9706-a56998f88c6f', 'ec0d724505f04df1bdd269a26223b0ae', '10060101', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a1e72493-9c65-4db0-af12-02dba24d2c7e', 'ec0d724505f04df1bdd269a26223b0ae', '0', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('05014128-2a5b-4ec5-8ada-f1eeed35a0c7', 'ec0d724505f04df1bdd269a26223b0ae', '100601', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('8d603789-49d9-4587-ad4d-e310095fa0cb', 'ec0d724505f04df1bdd269a26223b0ae', '10060202', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('684fbd70-548e-46b7-a939-6bcb1452da69', 'ec0d724505f04df1bdd269a26223b0ae', '10060603', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('bce19f3e-c539-43e5-a1f7-cde51f3436a4', 'ec0d724505f04df1bdd269a26223b0ae', '10060109', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('0e79c0ca-a5bb-4c62-9daa-67d7058167a8', 'ec0d724505f04df1bdd269a26223b0ae', '1006030401', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a1b1a9e8-099d-44f5-9716-5ff44a783aed', 'ec0d724505f04df1bdd269a26223b0ae', '10060604', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('53d198b1-9fac-4e33-afa4-01d2479afa0b', 'ec0d724505f04df1bdd269a26223b0ae', '10060103', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('97bfdc33-6a93-49ea-a8a9-556268652e05', 'ec0d724505f04df1bdd269a26223b0ae', '1006030403', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('af6d1ebc-9a74-4133-9c40-0b9c4a59d0da', 'ec0d724505f04df1bdd269a26223b0ae', '10060404', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('cbd488cd-6c4e-4873-8d9d-7ff42ecba304', 'ec0d724505f04df1bdd269a26223b0ae', '10060204', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('136db511-1b1f-4e47-b6e6-8ebf9f07b0b7', 'ec0d724505f04df1bdd269a26223b0ae', '10060303', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('26113bf5-f2cc-47a7-aaf1-07123bcdb588', 'ec0d724505f04df1bdd269a26223b0ae', '10060201', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('644c3a41-a556-4a9e-a764-382716c4ae84', 'ec0d724505f04df1bdd269a26223b0ae', '100602', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('132c35ef-20d6-465e-8284-3a8d93fc6b17', 'ec0d724505f04df1bdd269a26223b0ae', '10060105', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('de31a5a0-a7f5-45af-9b90-7070e7b6c96f', 'ec0d724505f04df1bdd269a26223b0ae', '10060402', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('329f0e60-5069-4f19-bafd-ebf272a778db', 'ec0d724505f04df1bdd269a26223b0ae', '10060304', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('66853c38-40a7-4318-b0c3-670f035eb98f', 'ec0d724505f04df1bdd269a26223b0ae', '10060601', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1a71e5e9-37e3-4a77-859d-e16daa6b0582', 'ec0d724505f04df1bdd269a26223b0ae', '10060403', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('885257c4-20e4-47dc-af27-5e3093fbea3b', 'ec0d724505f04df1bdd269a26223b0ae', '10060203', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('49a7238f-e626-481d-b29b-9704c6e7fea0', 'ec0d724505f04df1bdd269a26223b0ae', '10060102', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('8ba3ce12-ee93-44f1-9cfa-2b1d95840aa5', 'ec0d724505f04df1bdd269a26223b0ae', '1006030302', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('8e676aca-d8ee-42aa-aa80-9e15dc5dac72', 'ec0d724505f04df1bdd269a26223b0ae', '1006030301', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('2d31b14a-7c43-4200-b641-5dbff423a428', 'ec0d724505f04df1bdd269a26223b0ae', '10060606', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f7572c97-3e7a-4ea9-af7f-4931051528b7', 'ec0d724505f04df1bdd269a26223b0ae', '10060104', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1e9b0f8d-ecd8-4b7c-9784-a0ec743cf21c', 'ec0d724505f04df1bdd269a26223b0ae', '10060401', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5d9808a4-73b1-4ff1-9f88-e4519a0295b6', 'ec0d724505f04df1bdd269a26223b0ae', '100603', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('3e2da454-5fc4-40bc-8763-85d0ecdf8588', 'ec0d724505f04df1bdd269a26223b0ae', '10060110', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('e73345b4-64af-46b5-83b5-b5ccc167c47b', 'ec0d724505f04df1bdd269a26223b0ae', '1006030402', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('e7e72843-7f2e-4cf1-a8e3-ee32af812138', 'ec0d724505f04df1bdd269a26223b0ae', '100606', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1c8fc3df-b870-4869-9d8f-190e999d6b29', 'ec0d724505f04df1bdd269a26223b0ae', '100604', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('05f8a1a5-2181-4994-a0b2-ec45ccba25dd', 'ec0d724505f04df1bdd269a26223b0ae', '1006', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('e2016a20-a817-4b58-a1f1-3fdc40dfcb88', 'ec0d724505f04df1bdd269a26223b0ae', '10060108', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('847e5b12-e02f-4724-ae14-1ddecf5a3ad6', 'ec0d724505f04df1bdd269a26223b0ae', '10060602', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c15558b6-7167-408b-9b3a-3582fc23ac49', 'ec0d724505f04df1bdd269a26223b0ae', '10060605', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('044977f8-377e-40e5-ba8a-90994c32522b', 'df18554461eb44be9bcb443a4b1d9f7f', '100603', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('4a1a69f1-d5b5-403c-b2c0-7db0df01fcc6', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_640_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('cd644f0e-b16a-4b6d-a31f-7995d4ff7ee6', 'df18554461eb44be9bcb443a4b1d9f7f', '10060105', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d4b6dd0d-e1e1-4d63-90fd-3f06fdfbb986', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_p_01_220', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5603061a-8f51-4e15-a342-b55df1677eee', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_440', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f53adcfe-a236-48b2-b8b2-88fed7183750', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_p_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('242f6b4c-dd76-434d-9986-72680c41819e', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_p_01_120', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('322f1477-59dd-4785-8d0b-063b789230dd', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_620', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('19185a54-0ec2-4e53-bd60-e6f5061a52c7', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_p', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('08e8f1c9-0646-4475-abfb-20835ccbe404', 'df18554461eb44be9bcb443a4b1d9f7f', '10060404', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('50e3ced8-b718-41e4-b65a-824742644909', 'df18554461eb44be9bcb443a4b1d9f7f', '1006030401', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c4399595-d60e-4c6a-bc3e-4795b4f7c4b3', 'df18554461eb44be9bcb443a4b1d9f7f', '10060303', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f9c7c6dc-5101-473e-a1a7-276edc22f8c9', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_610_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('fd19fd2c-d420-4730-b954-5a9460d74dc9', 'df18554461eb44be9bcb443a4b1d9f7f', '10060104', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('249b3abc-c7a4-423a-914d-734f8b7f6c55', 'df18554461eb44be9bcb443a4b1d9f7f', '10060403', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('468b3631-a4a4-45b8-a964-e79d215fb1c0', 'df18554461eb44be9bcb443a4b1d9f7f', '1006030403', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1b58da80-850e-4472-9f77-b50499028788', 'df18554461eb44be9bcb443a4b1d9f7f', '10060203', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c38699ef-06fc-410c-b630-ea9ace7de1a8', 'df18554461eb44be9bcb443a4b1d9f7f', '10060304', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a55a64b1-d4cf-42e0-a884-dd13d9139832', 'df18554461eb44be9bcb443a4b1d9f7f', '0', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('e6fa55ef-857e-4e1d-a24e-8be5bfd03889', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_420_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('27a034fe-9daf-4726-b709-2763151e7b26', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_410', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('e9d54d5b-9dea-4c1c-b892-6c4f95228ce1', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_p_01_debt', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('e0ed8653-85ae-4b1f-8dfa-2a3b5c6c08b9', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_650', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('de1a3efa-1d2f-450a-a04e-b4e74ad064f9', 'df18554461eb44be9bcb443a4b1d9f7f', '1006030302', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('aa00e327-87b9-4320-a25a-e72da6277bc0', 'df18554461eb44be9bcb443a4b1d9f7f', '10060202', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('cfc9a615-8aac-46bf-9770-aab5dcc80e70', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('014dcfb8-7871-4fb5-932a-8940726df46c', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_p_01_130_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('6686aca8-0e81-44b1-a2f3-6afd2150356f', 'df18554461eb44be9bcb443a4b1d9f7f', '100601', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('007d8dfe-e7d3-4059-80ea-5c795cefab82', 'df18554461eb44be9bcb443a4b1d9f7f', '1006030301', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('188160f8-76d4-43d0-a3b2-e67f83b5af74', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_440_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('4be6e6a4-a2c7-41f8-b8cc-5f7dfe430347', 'df18554461eb44be9bcb443a4b1d9f7f', '10060602', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('db7955ec-e7a1-46c0-a216-f1f3bbad5a11', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_p_01_210', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ee740990-32d6-4942-95ef-cbfab1b10af5', 'df18554461eb44be9bcb443a4b1d9f7f', '10060110', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('252afbe8-b24a-41ec-a5b6-cc970cdec46e', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_p_01_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('755b9b17-5040-44b4-a3ac-feaf546815c7', 'df18554461eb44be9bcb443a4b1d9f7f', '10060601', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f2f27fd5-e9e9-425d-ab01-752b17ab676a', 'df18554461eb44be9bcb443a4b1d9f7f', '10060606', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7d89a1c8-6f69-4588-831a-c239fdd364b0', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_p_01_220_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('798f6594-8158-447f-9ba2-95a655699a4a', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_350', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a27bff90-5f8e-42f3-84a5-e99c2bca20d3', 'df18554461eb44be9bcb443a4b1d9f7f', '10060103', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('2fefa46c-2c47-44e8-b5ad-4976204bd2b2', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_420', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('41a8b2e8-aa0a-4571-be37-acaefb75536e', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_640', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('3fb256ab-a6a3-4d97-b720-abf02770b77b', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_fin', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c45730d2-3812-45d8-a892-294d5144fc92', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_630', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a905ce32-9736-498b-b7ce-baa709fab90f', 'df18554461eb44be9bcb443a4b1d9f7f', '10060604', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('59ea2c26-2fcb-4aca-9179-41af36f33062', 'df18554461eb44be9bcb443a4b1d9f7f', '10060605', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d48074d6-e403-4dce-b2db-787e50ac69f0', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('9e1b55a2-1594-463d-9721-c4eeb66bb9f7', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_410_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('366d10d0-d030-446d-8a79-c254c2ed3cf4', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_p_01_210_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('8b4e861d-3fd6-4dd1-be8d-d7d2324d9ff9', 'df18554461eb44be9bcb443a4b1d9f7f', '1006', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d42d33c8-eca9-4d82-a78a-632a56f7f7b9', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('166f2988-0357-4ac6-9b80-290187d92d4f', 'df18554461eb44be9bcb443a4b1d9f7f', '10060603', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('0d201004-25c4-42ab-80c0-d0ead9edaee1', 'df18554461eb44be9bcb443a4b1d9f7f', '100604', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c65e432e-f16b-4920-85a2-93cb01d3ca39', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_03', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('07a7016c-4a89-451b-b397-5960ebf9d92b', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_510', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('9947ae13-bce9-4b90-a4a5-451701abd17b', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_310', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7e6f7da1-f6f6-4b6e-b40c-7982910ac169', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_p_01_110', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1fa89fa4-52cd-48b3-8f96-4321013a5fa5', 'df18554461eb44be9bcb443a4b1d9f7f', '10060109', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d79b04cb-114e-4cbe-b080-1ee709deadab', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_p_01_130', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('48038d9f-f368-4919-9e72-764ce05185b6', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_310_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('af1b7a02-0694-4e28-8585-ec83b3a15f3b', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_p_01_215', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('41a9090d-e47a-458b-8c22-c70d976f1dcf', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_610', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('8ec135e3-d470-4f37-aaa7-0c3f6887669b', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_510_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('47c33b0c-7ec6-4af6-be8b-c1e42b6e77a3', 'df18554461eb44be9bcb443a4b1d9f7f', '10060108', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('428a90c7-938c-4fff-8db3-138050550070', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_650_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f64e2ae8-aee4-469b-a39d-5ed4b1193ba0', 'df18554461eb44be9bcb443a4b1d9f7f', '10060204', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f76e14f0-6d76-4311-8919-d7c8378a15e5', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_p_01_110_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ca4c239d-b79f-4e12-b3c1-2d4530974e8c', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_620_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('bd360bba-7d35-469d-8e84-838be9005f14', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_b_01_630_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('dc2f5db0-0f66-4c5b-ac55-6052842f1647', 'df18554461eb44be9bcb443a4b1d9f7f', '100602', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('289a2402-59e4-48c0-9ffb-bbd598bad05c', 'df18554461eb44be9bcb443a4b1d9f7f', '10060102', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('37d065c0-bd40-48e2-9fd3-08a242be2c7f', 'df18554461eb44be9bcb443a4b1d9f7f', 'mbt_03_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('eb41508c-9466-47bc-a568-81493a513d62', 'df18554461eb44be9bcb443a4b1d9f7f', '10060101', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('459bd606-af57-45c6-8880-9ba29e64205f', 'df18554461eb44be9bcb443a4b1d9f7f', '1006030402', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('6ad81f3e-2ac6-44db-ae49-2b2aaa6e1161', 'df18554461eb44be9bcb443a4b1d9f7f', '10060201', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('272044eb-fd31-4db1-9dc0-1486c4be2f50', 'df18554461eb44be9bcb443a4b1d9f7f', '100606', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('0bee7b46-4df1-4704-b4fa-404d7f73361c', 'df18554461eb44be9bcb443a4b1d9f7f', '10060401', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d790963a-13ce-4235-a675-8f91b6df1fc9', 'df18554461eb44be9bcb443a4b1d9f7f', '10060402', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('170ab54f-375a-4f4f-bcf6-ce8bbaf7f4af', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_01_220', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ae21502b-b404-493a-a6bc-b3c2751fcf27', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_01_debt', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7953f287-524c-4338-9340-e11df7a48233', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_420_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ce7c60e4-a357-4e99-8b55-b1607bdb8851', '31aa52b7fdb34749969bce5673abab7d', '1006030302', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('22f7f562-1c66-4b20-a879-f73c0133e5d2', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_650_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('eac9aaa5-3c96-47da-aaff-47052111ed43', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_01_510_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('9f1c5868-9ca6-467c-bc31-184be8f488a9', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_debt_212', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('daef21da-b4a8-4c41-b3b8-f960358d05be', '31aa52b7fdb34749969bce5673abab7d', '10060109', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('89b5cc4a-53ba-4e1e-8746-f6875b936d99', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('83214a63-b19f-4181-a6af-2beb4c4485b9', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_basic_140', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f0e9cc1b-a353-444a-8700-2b9fb8cd89eb', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_basic_134', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('2677d8a1-6937-4490-a178-edd9042bb033', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_debt_213', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('bfe6c4ab-5586-4503-b413-52310e2f1c45', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_620_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1d9a1e6b-85b8-4b51-8822-ceba36adcd0d', '31aa52b7fdb34749969bce5673abab7d', '10060108', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ff9b9987-9b95-4a46-b651-129adbaf9986', '31aa52b7fdb34749969bce5673abab7d', '100601', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('74173a92-140e-45f2-9848-87582749556e', '31aa52b7fdb34749969bce5673abab7d', '100602', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('158c27d4-85d1-4e80-a19c-4373dd1e8c87', '31aa52b7fdb34749969bce5673abab7d', '10060404', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5e50aaaf-0894-495b-b4d2-664c737f9549', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_440', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('38f40f8d-4798-402f-8d57-e2017334265a', '31aa52b7fdb34749969bce5673abab7d', '10060304', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1975b513-dacc-4363-82c9-1f8b24969873', '31aa52b7fdb34749969bce5673abab7d', '10060303', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a37aca34-63e0-435f-a4fd-fd121a5b4e74', '31aa52b7fdb34749969bce5673abab7d', '1006030301', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('fef35873-e459-43bb-8f86-ebfed986bb80', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_debt_215', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('31c4269a-f92b-429e-8c20-505edd6a444a', '31aa52b7fdb34749969bce5673abab7d', '100606', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c26ba241-2f14-4b25-ba3e-885d0174e90a', '31aa52b7fdb34749969bce5673abab7d', '10060401', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('3b8c00c9-346e-43f9-8c46-af530d2ce892', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_basic_120', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a757a571-1a58-4952-92d8-34ae092f8b7f', '31aa52b7fdb34749969bce5673abab7d', '10060204', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('59d2b091-26c6-4168-8e10-815d82e90129', '31aa52b7fdb34749969bce5673abab7d', '1006030403', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('74b88adc-6b2c-46c3-967d-e90454d01022', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('37298375-340b-4113-9f5f-722233827aaf', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('203f990d-671e-48b5-af7f-d437e4234c5d', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_630_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('b9f413fd-0931-42d4-a804-106a4a68873b', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_640_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a4e19cba-9e0e-487d-9478-912c5cfe1a35', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('05814e48-701c-4254-a463-92e1381ecd4b', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_debt_210', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('9af1d686-dd7e-4101-9478-dbe1ff9bb12b', '31aa52b7fdb34749969bce5673abab7d', '10060110', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('b229d5ac-25ac-4efa-8490-aec0c6da6894', '31aa52b7fdb34749969bce5673abab7d', '10060601', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c07a9fef-b23b-4b05-90bc-23aa65bed5bc', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_310', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('4b919c2b-0355-4aed-9c11-bf8a404478f6', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('cc0afc90-62f4-46e2-aad3-e439aaa01bf2', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_640', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d44efdda-0b50-491e-b39c-a3956339262b', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_credit', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('8daa7438-78b7-43c3-96ee-c0797af5c7c7', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_01_220_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('43f191db-c2c0-438f-8e35-f70ff146c6d1', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_350', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5ee684fc-5c1a-451a-ab7c-08839d57cc72', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_620', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a34298cc-6119-4175-958e-12802ea82791', '31aa52b7fdb34749969bce5673abab7d', '1006030402', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5f0001e8-d37a-442d-9546-88dd152edf4e', '31aa52b7fdb34749969bce5673abab7d', '0', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1f3e95ee-723a-4da4-989e-068a6863f476', '31aa52b7fdb34749969bce5673abab7d', '10060105', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('86e7e324-611b-4bdc-b81b-ce68ce47bfc4', '31aa52b7fdb34749969bce5673abab7d', 'mbt_03_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('b74fe57d-a965-473f-b3db-31f9e45e12d3', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_credit_223', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('9049be99-65d5-440d-ae1b-225612f9b466', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_basic_110', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('0032f32b-99e9-4c09-9608-6dde8c547e2e', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_basic_114', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('73122d5d-e0f2-4bf5-9ea3-c6a54c0122a4', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_01_210_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('34585c5b-cac7-40a9-a4c8-ea3c4bdf747d', '31aa52b7fdb34749969bce5673abab7d', '10060602', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('9f962917-405d-419b-a1fa-1c2b2ed67259', '31aa52b7fdb34749969bce5673abab7d', '100604', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('017d79f9-7188-40c6-8084-6e481a2bb580', '31aa52b7fdb34749969bce5673abab7d', '10060403', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('be98b614-85ee-4ec8-ab77-141b172356c5', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_credit_224', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('2f6a5106-c228-439f-8f94-f71a014a0b4d', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_310_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f0c493e4-e0df-433b-9e31-4f84ec671012', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_420', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('90cd2646-7b13-459a-b6e5-60c9349af34a', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_610_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('bf01e661-838c-4580-9503-0bd8ec1f5175', '31aa52b7fdb34749969bce5673abab7d', '10060603', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('334fb32d-a72e-4f85-b96e-43467ee39f42', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_410', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c43324ba-ecdc-4440-a79e-737306c5dae8', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_01_130', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c4709240-9b35-48ce-a73b-35a0255b72f4', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_510', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a3baa719-ac76-432c-a2d6-79a70bdde511', '31aa52b7fdb34749969bce5673abab7d', '10060203', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('08d2e21c-044b-45d8-96f8-71bf4fabda1e', '31aa52b7fdb34749969bce5673abab7d', '100603', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('3a676d05-e035-49d8-a693-3089bf7a2606', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_630', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('6942dd50-f3fd-47a7-a4c7-d5e31f0440fd', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_01_110', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7f5929c1-ecef-4a6a-b3f5-ec64ee4e23b0', '31aa52b7fdb34749969bce5673abab7d', '10060104', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('588ed5c6-afb5-4365-9461-5e453fb8d601', '31aa52b7fdb34749969bce5673abab7d', '1006030401', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c6dc117a-0f42-4af9-bd6b-e15279ce597f', '31aa52b7fdb34749969bce5673abab7d', '10060102', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('12210475-d61f-4f53-a0fd-ba3216782371', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_650', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('6ce81455-4780-4a0d-8a50-2912b98305c5', '31aa52b7fdb34749969bce5673abab7d', '10060201', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5213024b-5f5d-4ebe-a695-ca869856e856', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_410_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('58d87c0d-15ed-413c-995a-a382953803dc', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_debt_211', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('bb7e5053-ca6f-4d94-8d03-e4c4df2d9ac6', '31aa52b7fdb34749969bce5673abab7d', '10060101', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a091af63-9740-40ad-a9c0-002714b0e3f1', '31aa52b7fdb34749969bce5673abab7d', 'mbt_03', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7b5c52f2-cbdc-4aeb-b93c-95874115ae59', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_debt', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('6539f374-2d65-495d-bbe9-6a52e0530bd8', '31aa52b7fdb34749969bce5673abab7d', '10060605', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('09808c45-5a14-4ea6-9e3c-e6394492e26f', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_credit_221', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('189dcc63-5bf3-4f9b-99c6-bba50aeb3f14', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_610', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('47b357fc-bf9a-4e92-8bc8-9bc31ca35aa0', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_basic_130', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('013e7d30-bc66-4a64-8d99-2960eebae43c', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c0d92d83-1ef9-46a3-a752-b078a3f71a4a', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_credit_220', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('abdcbd93-e862-4914-a895-19a22a82452e', '31aa52b7fdb34749969bce5673abab7d', '10060606', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('641f0dc8-0f34-438d-b171-3d1685ed91ae', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_01_130_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('9c03ce48-b03e-43c7-9544-c46ab8945acc', '31aa52b7fdb34749969bce5673abab7d', '10060103', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('0c5e0a0a-6f41-45fc-b3ff-a578ea149990', '31aa52b7fdb34749969bce5673abab7d', '1006', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('33282578-a1c4-4c27-8b3f-d1317f6b06da', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_01_210', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d9d3625c-684b-409a-9c54-b848880461b9', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_510_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('177aea40-8320-4c68-8788-d0901bdb6a48', '31aa52b7fdb34749969bce5673abab7d', '10060202', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('095eca52-dd0d-4339-af00-1e52edbdbd61', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_credit_222', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('b7acfe52-7b8d-4634-afee-7800ce228199', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_440_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('6d7fdf63-1285-46d6-828c-e24da884e08a', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('db5a6e36-7c58-4916-ac36-de18bc706869', '31aa52b7fdb34749969bce5673abab7d', 'mbt_b_01_fin', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('778f1539-8f0f-4eb7-b0d8-4d1591be15b5', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_01_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('cf9b46a9-12ba-487c-8073-db8b5489238b', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_02_debt_214', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d4fcb5b6-f424-4b3b-8a7c-3f071eb41478', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_01_215', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('38300dfe-b210-4df0-baee-6e53cee126bb', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_01_120', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('9b6a7edc-7c0b-4021-a24f-86508cee901f', '31aa52b7fdb34749969bce5673abab7d', '10060604', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5d5ea750-b4e6-4275-8ac4-7d12984f17d9', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_01_510', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('710abe14-dbca-4432-ab9c-64fa4ae5240a', '31aa52b7fdb34749969bce5673abab7d', '10060402', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('982a1bf1-4615-44e2-9041-a07800e66286', '31aa52b7fdb34749969bce5673abab7d', 'mbt_p_01_110_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ad03fffb-20ac-4754-a238-f26de527613b', 'e7d05822964b4b198678a10ce175b0c8', 'mbt_b_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('83a2e1b1-99df-4176-9916-cb48a0b925c1', 'e7d05822964b4b198678a10ce175b0c8', '0', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('53ad1edd-9984-452a-bd11-944a1bd1583f', 'e7d05822964b4b198678a10ce175b0c8', 'mbt_b_01_420_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a9cae0f4-cc8f-40ae-a4cb-2a86098c8b56', 'e7d05822964b4b198678a10ce175b0c8', 'mbt_b_01_420', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('81da085e-1e7f-4d2a-87b4-964465d94207', 'e7d05822964b4b198678a10ce175b0c8', 'mbt_b_01_350', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('3b2c79e3-b4db-40ab-872a-5356f6b14b76', 'e7d05822964b4b198678a10ce175b0c8', 'mbt_b_01_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ff4f9528-9f91-4269-8a4b-2d361093c645', 'e7d05822964b4b198678a10ce175b0c8', 'mbt_b', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f5cd51e2-660d-4d9a-9c29-ba1c23d14875', 'e7d05822964b4b198678a10ce175b0c8', 'mbt_b_01_310_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('0c8325f9-0db9-4a4c-9848-6811be14f945', 'e7d05822964b4b198678a10ce175b0c8', 'mbt_b_01_310', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7557ad60-fddc-4536-bd8a-259892f2bc08', '7a3af9e92b054c5c8f79a96cf7c7d27b', 'mbt_b_01_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('89fdd372-dd28-4b70-bf7f-9c970792a0e4', '7a3af9e92b054c5c8f79a96cf7c7d27b', 'mbt_b_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7be8e2c1-6689-4dde-8ee9-fd9beafb98ea', '7a3af9e92b054c5c8f79a96cf7c7d27b', '0', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('4474d6a8-2424-4e93-aabc-1e1c6505f467', '7a3af9e92b054c5c8f79a96cf7c7d27b', 'mbt_b_01_310', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('11479399-4e52-41cd-977f-4f58add8ce8d', '7a3af9e92b054c5c8f79a96cf7c7d27b', 'mbt_b_01_350', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('59cae2b6-a59b-4b7a-b725-178023da7bb3', '7a3af9e92b054c5c8f79a96cf7c7d27b', 'mbt_b_01_310_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('61d8bef0-9c5b-4c8f-9136-be924985f0df', '7a3af9e92b054c5c8f79a96cf7c7d27b', 'mbt_b_01_420_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('0eaed68e-49b2-414d-8237-1a127c2fb51d', '7a3af9e92b054c5c8f79a96cf7c7d27b', 'mbt_b_01_420', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('6ebf5437-c63e-4228-9bb8-a0bce6548185', '7a3af9e92b054c5c8f79a96cf7c7d27b', 'mbt_b', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7db4360c-5df9-46e6-9b9a-164c9674cd14', '47901032b321403bac5e758b4c830239', 'mbt_b_01_310_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5f496c88-8e46-41b9-b74c-f9c3f717f3fa', '47901032b321403bac5e758b4c830239', 'mbt_b_01_310', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('0d6b0e37-c799-444e-9bea-ff56670910bc', '47901032b321403bac5e758b4c830239', 'mbt_b_01_350', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('594fce63-7070-478e-beb8-c80aa970304b', '47901032b321403bac5e758b4c830239', 'mbt_b_01_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('2713e211-b400-4e79-b7ea-53e66e898295', '47901032b321403bac5e758b4c830239', 'mbt_b_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('4d81704a-88d7-4cf2-b809-63731fca4c45', '47901032b321403bac5e758b4c830239', 'mbt_b', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ec759ac8-df34-4de4-b956-3753a55b6ac8', '47901032b321403bac5e758b4c830239', '0', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('e9957af1-e633-45b8-b2df-06f48f7bc17e', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_510_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('16917b9e-fa4f-400f-8dea-8c0c4890fbd5', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_01_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('9a7557f9-a9b5-4327-83dc-b9df22728464', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_02', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('65349cb0-cf5b-46d2-9588-dfab1523f7b9', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_310', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('b631c08c-caff-48f1-b0a9-c5b4349eab35', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_01_110_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('0e37ab43-2a95-4b4a-8949-6c592caf0dc2', '66361822c93247248cf3ca003c0e98c9', 'mbt_03', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('214a9fd3-9a87-4195-87c9-62e044871a7c', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_01_510', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('193e048b-89df-4688-9d9e-4690d5cfa3f6', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_02_basic_120', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('cd6b9e04-e441-45a9-8846-6815027c755c', '66361822c93247248cf3ca003c0e98c9', '10060403', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5e561581-161f-4a52-ac39-3d982ff66077', '66361822c93247248cf3ca003c0e98c9', '10060104', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ba740718-56e2-4d5d-94c0-f6c5e5c6fe75', '66361822c93247248cf3ca003c0e98c9', '1006030401', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('05f7beb1-9b9b-4e79-88d0-7a2bd377edee', '66361822c93247248cf3ca003c0e98c9', '10060304', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('10bcd896-5c61-4473-9c64-2cf2a99e8632', '66361822c93247248cf3ca003c0e98c9', '100603', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('e99e3cc5-c8a0-4091-b103-015bc18029b3', '66361822c93247248cf3ca003c0e98c9', 'mbt_p', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('be6db432-92f7-4616-82f2-1f18d86bbe0a', '66361822c93247248cf3ca003c0e98c9', '100602', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('2f570d24-954c-482b-bd30-edb72c7f0e59', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_02_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('3157c969-621f-47f3-a62a-6c505a0588bb', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a174957c-b211-4f65-9830-77845c5f3a4b', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_640', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d13578a0-800b-48a7-98cf-ab4638aaffbc', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_01_110', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('6f4b7a7a-d8c7-4bae-95f2-17ce771794c8', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_01_220', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('4ee305e7-50ad-42b4-8c9c-b0947796a7e2', '66361822c93247248cf3ca003c0e98c9', '10060101', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('31968717-5152-46ab-a841-d86b6964bbc3', '66361822c93247248cf3ca003c0e98c9', '10060203', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('70d3bf41-43f1-47e2-9c2b-c61579acd006', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_610', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('cbc517fa-d785-4a68-a4aa-c1c4cc94740e', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_01_210_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('9a676091-55a2-4d6a-bb6d-dbb0f2b26ba2', '66361822c93247248cf3ca003c0e98c9', '10060108', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('878054a6-0a8a-4466-9193-e6f3ef343e6d', '66361822c93247248cf3ca003c0e98c9', '100601', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d857add5-b004-4f08-89a2-25839548dda1', '66361822c93247248cf3ca003c0e98c9', '1006030302', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a29434d9-8e77-41b8-b705-5eaa589b4970', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_650_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5affebc3-9e7f-4712-aaf1-019678cb2abf', '66361822c93247248cf3ca003c0e98c9', '10060602', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7b8afdec-1d50-45ae-8182-3d34c709b340', '66361822c93247248cf3ca003c0e98c9', '10060606', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('4b1be4d5-813a-4811-8b75-67a393e2d40d', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_01_130_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('67c2ddc6-8dba-4144-9369-f204b652905d', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_420', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('e1bb28f0-ceb7-43b2-b99e-bb5cbceecc7c', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_01_220_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('434e3589-7113-4c3d-b76a-ee855e55e166', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_410', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7091443b-399d-4c39-a483-6dc28695d727', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_01_210', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('51020761-c15e-4f0e-982c-485b63b54959', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_650', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('af73f3a8-90e5-457c-80b0-c83164907f9f', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_01_120', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d0a0c770-e5f1-475b-9157-524f4aa96d95', '66361822c93247248cf3ca003c0e98c9', '10060110', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('8d6923f1-f597-4b19-9912-b21cb60c0dbd', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_630', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('732247c3-b85f-4142-9b35-199f57dc7c94', '66361822c93247248cf3ca003c0e98c9', '10060109', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('faea1ac0-e847-48d7-92c2-7480b5da3ca9', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_620', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5bf7cfc8-f666-4ca3-a939-84e723fd6fde', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_440', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('e2e1b9e2-1cc7-4869-b32f-9c954ab68c8c', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_02_basic_140', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c72c2931-9600-4623-b175-548f9d61422d', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_02_basic_114', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('3c0ccef5-20e2-461b-9a06-5d597c54ae9d', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_01_debt', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c36c4921-5a99-49c7-a4f9-a5ad709872b4', '66361822c93247248cf3ca003c0e98c9', '10060601', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1b62e4ad-33f0-4a84-9360-21937e50ee8b', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_410_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('2ca4fe7b-4671-42af-8a0a-938e70a20283', '66361822c93247248cf3ca003c0e98c9', '100604', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('035cc749-9eed-45f5-879e-0b969092c617', '66361822c93247248cf3ca003c0e98c9', '10060404', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('99c68c8d-3a7a-409d-8e40-bc0887006f47', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_02_basic_134', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a904d23f-24e3-409a-b634-39d3308e5ba8', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a9c0e31c-32f8-4520-8cf7-9c6fbc3135ec', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_640_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f8ac7e5a-231c-4c12-8d57-f1d0899555ff', '66361822c93247248cf3ca003c0e98c9', '1006030301', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('bbb969aa-644b-426b-8ba2-ae6c29c1a385', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_630_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c2d35d83-61f1-4b1a-9622-70795dd0ad09', '66361822c93247248cf3ca003c0e98c9', '10060201', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1c1adb80-1147-4504-85a6-d1eb48da7c3f', '66361822c93247248cf3ca003c0e98c9', '1006030403', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('fbb0a3ab-049a-42ea-8897-9ea68be0d729', '66361822c93247248cf3ca003c0e98c9', '10060402', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('8ad023f5-a833-45b1-9a21-85a1e11f752f', '66361822c93247248cf3ca003c0e98c9', '10060105', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ae086cc9-7e00-44f8-9aef-9667b9b2a918', '66361822c93247248cf3ca003c0e98c9', 'mbt_03_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('48fdc24b-ac61-4448-921c-f08f8b90af8f', '66361822c93247248cf3ca003c0e98c9', '10060603', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5f6c46c1-b02b-4ab5-91e4-d7488bea1a6f', '66361822c93247248cf3ca003c0e98c9', '10060605', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('cf9db92d-d330-48ca-aa0c-4a571174e4ae', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d605bf53-48c6-4e4b-a94c-d7f50ec4a012', '66361822c93247248cf3ca003c0e98c9', '1006030402', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('0d7891e1-1fa9-4d7c-9d78-c74e27178dcc', '66361822c93247248cf3ca003c0e98c9', '1006', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('df591328-c826-4f26-87b2-e5eabe50c42b', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_440_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f7f9f4c3-d56d-45c4-b15b-1d1f24f4132e', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_01_510_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7c11641b-8fd5-4021-a3ce-29d442da07d9', '66361822c93247248cf3ca003c0e98c9', '10060204', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1c4d5a1c-7a9f-4c11-87d9-0b86fdde8cf6', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_fin', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7917fd67-d685-41ec-a173-c2eab642cde8', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_620_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('0ea7d6e7-d374-4327-be3e-4ac5f37174c5', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_350', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('2e003a8d-eeb5-455a-91d5-dd8e425795e0', '66361822c93247248cf3ca003c0e98c9', '10060102', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('aae3ee2b-4fa7-4a55-872c-2080cb47f425', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_01_215', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ac565aea-b721-421a-a8e7-f9bd84b5e3f4', '66361822c93247248cf3ca003c0e98c9', '10060604', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('e2fed801-12a0-4d4a-91fb-854cebe29cd9', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_510', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ed435a1a-9ce5-4c8e-bc22-78bc6df030a4', '66361822c93247248cf3ca003c0e98c9', 'mbt_b', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('59f8e75a-81ea-488f-9597-e7300f01672c', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_420_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('4e8a413a-1cc8-4d95-8b79-9b413a1d6c09', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_01_130', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('64e0d83f-8bb2-47d6-8996-dfd221e3f8b1', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_310_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('3d20593e-01c8-4f56-9bb5-3902ad9b8583', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_02_basic_130', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1546e8d5-8b7b-467d-8930-cdd47f56eb9d', '66361822c93247248cf3ca003c0e98c9', '0', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('2a4f72f4-1aa6-4cb5-8692-287c2cd13b87', '66361822c93247248cf3ca003c0e98c9', '10060202', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('2acf3e21-1b71-4dd3-903f-0fcda3230113', '66361822c93247248cf3ca003c0e98c9', '100606', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f43cc920-7e32-4d07-a1f1-4aafaf0dc233', '66361822c93247248cf3ca003c0e98c9', '10060103', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('deec4ef4-6693-4bb5-b0c6-25e9b9a2853d', '66361822c93247248cf3ca003c0e98c9', '10060303', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('aad9ffb8-6530-481d-a7f3-251c6cc0dc22', '66361822c93247248cf3ca003c0e98c9', 'mbt_b_01_610_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('897dac3f-fc43-4c17-a7dd-fc7c8e8b6314', '66361822c93247248cf3ca003c0e98c9', '10060401', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('865b5c3e-3fd5-405f-b622-f2e2058821ac', '66361822c93247248cf3ca003c0e98c9', 'mbt_p_02_basic_110', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('e79c7f73-2404-4e95-87a1-eaa43f2d76e4', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_440_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('26cf5856-89d1-4e5a-a3c0-de614bfaafa1', '7163276a97d346bcbad529ff8023714b', 'mbt_p_01_220_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('22b92e08-8d2a-4896-8ae3-2b96673ad5cf', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_420_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('82122b71-40a8-40a9-9a21-d14b1141c2da', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_350', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('60eebee8-1204-4516-8aeb-99e6257758a1', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('8673f40d-8e00-4a59-af55-f5d4af9eaa60', '7163276a97d346bcbad529ff8023714b', 'mbt_03_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('80d1041c-6bcf-437a-a9ea-8bf4bc272f8c', '7163276a97d346bcbad529ff8023714b', 'mbt_p_01_110_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('3099556f-d3d0-4ad1-a7b7-22e0a70f1307', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_650', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('bf308565-f809-4ed4-9652-0399b7709d19', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_620_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('e7014d2a-e0bc-4b2c-a9f7-187a95fa1f66', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_650_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7582c99a-7b6d-4c80-92c2-2564084d2006', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_420', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ce6cf654-6481-4495-a907-8f9cf9277ace', '7163276a97d346bcbad529ff8023714b', 'mbt_p_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5e0b2ebc-0e82-4ba2-94d3-df6490f8fa66', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_610_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('db17acc0-25ec-43d6-b272-3fd892757262', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_310_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7ed93d09-f846-4d7b-a9df-eb6e65b28b5e', '7163276a97d346bcbad529ff8023714b', 'mbt_p_01_215', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('972bec05-51d8-4d95-a32e-cef98371b21a', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_310', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d270993b-cd2c-4ca6-821f-aa1aa020dc2f', '7163276a97d346bcbad529ff8023714b', 'mbt_p_01_130_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('81d02c93-3e7f-4ca7-8f37-324d6111a15e', '7163276a97d346bcbad529ff8023714b', 'mbt_p_01_debt', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1095dd5e-b707-4483-af62-ac6959fcc195', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d641a8db-f5c8-4e47-9be7-4293c16655a8', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_640_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('58cd52a5-d2a2-4657-b66b-cb3cd1473350', '7163276a97d346bcbad529ff8023714b', 'mbt_p_01_110', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('58608c97-1741-4360-a280-a7a5f489cdbd', '7163276a97d346bcbad529ff8023714b', 'mbt_p_01_130', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('2aa5146f-e141-4cf6-bf54-79b241eeb939', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_610', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('bf4ea241-a738-4bd2-8b72-1a65c7117758', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_640', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('bb5f8340-787b-4243-bd8a-248d4bb26c64', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_510_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('53b0fe52-835b-4189-9a5d-e921fc0be340', '7163276a97d346bcbad529ff8023714b', 'mbt_p_01_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('74020fe2-a156-48d5-87d7-dd3bb01bfa3b', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_410', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('119f671f-2761-4faf-9575-62e80ddec552', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_620', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('66bdd3cc-8507-449f-b6ab-5c25e3819d47', '7163276a97d346bcbad529ff8023714b', 'mbt_03', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('2dd13249-4df0-4e79-8cfc-f746280459ca', '7163276a97d346bcbad529ff8023714b', 'mbt_p_01_210_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('fa9de92d-a29b-45e5-82b1-d69808f684d0', '7163276a97d346bcbad529ff8023714b', 'mbt_p_01_210', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5d5ee67f-c3c8-4d9a-b086-924cb21dc493', '7163276a97d346bcbad529ff8023714b', '0', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('21b6e780-19ed-41f6-a7dc-380346d59195', '7163276a97d346bcbad529ff8023714b', 'mbt_b', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('bea9c72f-c277-4a46-b244-fa743112b96a', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_630_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('62befed0-051c-4c07-bf27-2e2bdc10244a', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_630', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('8f9570a6-1587-4b6a-bc83-9bd3e63a605b', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_440', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1a523f61-2bed-4186-8908-849763b01e5e', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_510', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('4bd39b8c-a448-44a1-ba7f-cfc77ec72710', '7163276a97d346bcbad529ff8023714b', 'mbt_p', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7bb1a217-8670-436f-a4c4-05bef6235037', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_fin', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('619b93f0-d02d-46f9-9157-4f6bd219fbe3', '7163276a97d346bcbad529ff8023714b', 'mbt_p_01_120', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('210f929d-9adb-4708-89b9-dadc0c46fd10', '7163276a97d346bcbad529ff8023714b', 'mbt_b_01_410_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1e9638d8-dfe5-444f-b20a-1a0a000acc0b', '7163276a97d346bcbad529ff8023714b', 'mbt_p_01_220', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ef6bb9f4-cc77-42fa-96b3-c15d3565c591', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('fbd31e02-f646-4890-9126-64a6d9843534', '1c0b23c5e2974221b6b07ed20e2c2f06', '0', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('504fc419-6682-4639-a06a-c4c1e4e9c4b2', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_440_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('89862718-edcf-4e57-a756-85fe61537262', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_630', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('aa98cdbf-9409-41b7-8bec-63774ac138c0', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p_01_210_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c27617cb-d8ac-4574-b3b3-cb01ff4e3696', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_fin', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('59b270aa-79cd-4f52-ad1f-9d2082f6a0f4', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_420_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7a37ac44-f54a-41a1-818a-d7b20f64f535', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_440', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ac977882-b294-40d2-9d81-7424cb9e72f7', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p_01_215', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('14f2081a-92e5-49bb-abac-26216b32e735', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p_01_220', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('eba90bde-ef9e-4b48-bd0a-1ff9715f9615', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p_01_220_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('db00b8b6-987a-4790-8b3f-71e7b115c327', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_310', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('58518188-76d8-4239-b4d2-3ef4b5c16e71', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p_01_debt', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f7b63e55-dbe1-4707-8960-80b7e2078e6d', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('3fbd5c5a-c98b-4986-88a8-6bf9745bfb37', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('736cc955-02ae-4a3c-b03b-4a975e4dcf08', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_620_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1bc2cdaa-ed95-417a-9fb8-af7c1fc1fd09', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_410_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('b514b6a6-fb9f-4dcc-b568-fac1eddef210', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a3a0f8b0-6256-4af6-97c6-9a14274ae33a', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_03', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('df3eecb4-4e54-4dec-8a66-9d0a3fe96944', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_350', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('2f3dc89a-6778-46ee-8b34-fa411570fa05', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p_01_210', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f56f4203-b04d-4e57-8db4-124da424b819', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_640', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('49ea8188-2fe7-42f2-a4d5-92c64242795d', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_640_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('0d96f4c7-fcda-4cf0-87ff-f151cd01641f', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_650_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1470c878-709a-49ee-b9b8-1a95ff55a40b', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_420', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d770203b-9f35-4459-82cc-e669bb074e0d', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_620', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a2fa890b-f7ca-481f-8d14-5a58374fe617', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p_01_130_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('af474ffc-e7d6-41a9-b5b8-333855bc7954', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p_01_110_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('3de1fbca-a8af-4213-99e9-ee48d2b10149', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_610_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('24736193-27ce-4366-aa6e-eb37039317ec', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_630_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a3ef7ab6-daf9-4a64-81b5-aec1a9b2b1fe', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p_01_110', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('70ebce68-a14c-4d91-9cc5-6c16735e1ee2', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p_01_510', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a1660a39-9ec1-4033-b1d1-c234664ffe73', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p_01_130', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a13ca358-e38d-48c5-bd16-8d4ea3df992d', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_510', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('96178f23-7994-4700-80d1-9dde5cd2209f', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_510_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('62bc47f7-e420-4d8f-bbb8-89ab93e911a0', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_650', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('b54a71f0-d1f0-44e5-b83b-a1e0a1b28cfb', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p_01_120', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('3bcef8b6-19eb-4735-ad14-7bc9f4da3b39', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p_01_510_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('0fd727e6-8002-462e-b3c6-d32ec6a21137', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_410', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('d20b7270-cefa-4c8e-b8ad-d2b53810158a', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_p_01_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a40b9d1e-a9c0-4000-afc3-f2221f020a76', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_03_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('c4bed24c-2f53-4508-ba14-97dc7e86cd60', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7c10787c-34cc-4671-addb-2adaada42cac', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_310_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('16b5047c-8e64-4625-97eb-b33f4d559c9b', '1c0b23c5e2974221b6b07ed20e2c2f06', 'mbt_b_01_610', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('8a1aa27b-3d22-4193-ab91-dc93cd18abd7', '73d6bb9621714f2fa061818ae00c64b7', 'mbt_b_01_510', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('4499ca5c-9de4-4399-94f6-729be76551d3', '73d6bb9621714f2fa061818ae00c64b7', 'mbt_b_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f346690c-cd26-4e7a-8746-1bcf7306677e', '73d6bb9621714f2fa061818ae00c64b7', 'mbt_b', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('fb761649-5983-46a2-80b9-2df5029ed253', '73d6bb9621714f2fa061818ae00c64b7', '0', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a92f7e34-fc43-45ad-a256-6ae0b42577b7', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_510_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('0ea719be-00b1-48bb-aa44-d3d4a4fc6194', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_630_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('e03e4742-426f-4352-8e4d-19075757e625', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_410', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('cc02aaca-6372-4ad1-b9ad-3d4b49a1d52a', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_310_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('a9137821-8e35-4f78-9fa3-5eaf81edc4e2', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_fin', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('94f7d2a4-745f-488b-84e7-c3c25f6e6b76', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('41604cf0-8cba-4406-b55e-e7f34aeb159f', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7c4ed155-10a2-4078-b278-87dd008a26fb', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_620_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('49ebe76a-6f82-4112-ac74-0bca80d184c1', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_630', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('0b98f311-4181-4b0d-ae16-d6e1bfe8fdac', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_310', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('e8b97720-a304-43eb-9cc5-03d5828308cb', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_420', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('3b175771-a6aa-49e4-a119-086df2a45152', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_610_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('54ed4ec9-f7a4-4ffd-94b1-b5166dac4733', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_650', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('960e1941-9093-4535-8b89-12259567b809', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_640_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('79beb379-8fe7-466b-a014-efb1af6d497b', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_440_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('963d370e-e663-4840-9bbf-2a9f15022414', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_03', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('9820bba8-0726-4735-909b-452433d4c60a', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_p', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('3980301e-59b7-46e5-8571-0fb5750c399e', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_620', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('7e31ccbe-eab6-412b-b743-989b72f5fa84', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_510', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('97b52a2b-f217-40e0-8eba-94bb366d5f18', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_650_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('ae832ae9-606a-46f7-9da5-48677b18c69d', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_basic', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('42a0a4e8-647b-48c8-b9c5-8066c0da0dae', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_410_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5c329b1d-3803-4491-8ae2-f19abca0efa1', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_420_chg', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f8336eca-1d90-4aa4-b3b9-24d324bb841d', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_610', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('82fc94a7-8e01-490c-b309-fa82ea62ffce', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_03_01', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('1bc95816-5f04-4fb6-994e-5db35d600ba8', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_350', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('b59d2866-2df3-473e-8178-3bbe401b1903', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_440', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('f5497a78-9bf9-4cd8-ad86-866b9baadb33', '10bb3f302eb2448ead7ff116ab8def3a', 'mbt_b_01_640', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
INSERT INTO GP_BM_ROLE_FUNC_REL (ID, ROLE_ID, FUNCID, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG, CHECK_DESC,
                                      CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, DATA_VERSION,
                                      DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME,
                                      DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                                      DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS, DATA_DATE)
                                      VALUES ('5e56cf6a-b517-4df8-87d4-462301fe5531', '10bb3f302eb2448ead7ff116ab8def3a', '0', null, null, null, null,
									  null, null, '99', '04', null, null, null, null, null, null, 
									  null, null, null, null, null, null, null, null,
									  null, null, null, null, null, null, null);
