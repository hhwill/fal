INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('eb02a755-dff1-4b07-9771-e3ebc75faf70', 'ZXY', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(MGT)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('44694ee9-41d8-4b57-abfb-50d00fe6b44c', 'ZXY', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(SBO)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('82c8b48d-eadd-413f-b473-b476f151ed5b', 'ZXY', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(UPL)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('251d8bee-12f2-4aff-9e63-897bbcb4318e', '11111111', '31aa52b7fdb34749969bce5673abab7d', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(MGT)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('58d1d316-f4f8-4335-a8cd-5f6e6295e32c', '11111111', '31aa52b7fdb34749969bce5673abab7d', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(SBO)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('42699721-7b8c-480e-aff9-c24f1c17a2cf', '11111111', '31aa52b7fdb34749969bce5673abab7d', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(UPL)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('04e8b2e6-379a-4faf-b18a-aeaab66f8adf', '11012222', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(MGT)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('9afa60e4-cfea-40b0-b62d-18da651855a4', '11012222', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(SBO)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('13890d80-bc8d-4a83-8ac6-eb0ddaca97c2', '11012222', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(UPL)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('3c4592a6-cd44-4029-a9ab-fd7e0ba40359', 'testhh2', '31aa52b7fdb34749969bce5673abab7d', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(MGT)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('5fef0e90-9042-4b47-9365-7cdb61621f8c', 'testhh2', '31aa52b7fdb34749969bce5673abab7d', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(SBO)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('f7c7f5ff-35dd-4dce-9dda-580676016877', 'testhh2', '31aa52b7fdb34749969bce5673abab7d', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(UPL)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('aeee5fb8-2da8-43b3-bdf6-f91433ccc8e6', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GTRF(DC)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('b62b1f56-3cb4-4523-887b-1badeba3b7d5', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(EL-CMB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('5404dc59-b63e-41d2-bb4b-5fad8d75eb1f', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GTRF(BADD)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('54393820-ed8c-4d0a-94aa-f93e7985710b', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GTRF(OAM)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('17cd3590-123d-40a5-bd4a-a97fc1cdadeb', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(OD-GB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('1091709c-49fa-48b5-9691-f59a9babd91b', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GDL');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('139c8373-7bc1-4092-b0f1-77b4227a757e', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(MGT)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('830e7ec2-1962-4f07-90c2-e6bf054c1710', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(SBO)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('e9c4d7c5-af83-4939-8d9c-ea719abf2c62', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'WCAS(BRANCH)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('21aee2b1-4651-4125-a220-e6b7915790eb', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(CMB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('79df87eb-93f7-447f-8720-2755663e7cc7', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('f67b79b8-5572-4f83-b9be-89cb5f0fb91f', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(EL-GB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('7b3c4416-0385-401b-964a-d462ae15e695', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(OD-CMB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('829a635d-6133-43e7-b102-b796d6cacab8', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GTRF(TF)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('1faa3a77-dc80-49bd-9169-48ff63d4aab4', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(UPL)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('55c9a922-f8a6-42c7-b841-45f6184bbb77', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(CL-RBB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('33506d67-2c3f-4169-aeee-125d3d2cad38', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(RBB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('f2f7ca62-f127-43d1-9eab-5956bb73278f', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GTRF(GTE)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('56b4fa1a-5e65-4c90-a614-bbc72e4f4cb3', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GTRF(RFN)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('e331cc59-d329-4057-a62a-deea3fb1d284', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GTRF(BADI)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('60291794-2ce1-4774-8b60-f634d25df3cd', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(CL-CMB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('38887b1e-8d0f-42e4-83a4-f898292f3f9f', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(CL-GB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('58a97d3f-1b2b-4d8a-a7cd-7fc9504d0ed0', 'bbbb', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(GB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('fdec746f-a3d4-4761-a402-209e794a0bf3', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GTRF(DC)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('6b63a4e5-8e2b-43a9-bdc0-3c2e4695f65e', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(EL-CMB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('c8466c82-e1b0-44de-944d-0e49b351f092', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GTRF(BADD)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('14bb3742-c4c5-4c62-8823-c6298b06de60', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GTRF(OAM)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('0cfa1908-501f-4c0a-9fbe-cd02ef5325ff', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(OD-GB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('5f030e88-0eaf-4406-b7b1-68476aff2cc4', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GDL');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('6107d16b-639c-4b58-b4a7-98ccec17dff4', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(MGT)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('2b5fa607-415a-4917-a399-7d03af31204d', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(SBO)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('5f9ce407-6ef4-4017-a08f-507f3686d8e6', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'WCAS(BRANCH)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('772b8123-9c80-45b0-945d-10185745ef7a', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(CMB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('844a7161-4ea3-4514-9641-393f478baf05', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('8850756a-f1c5-4245-a659-faa3a722f7c1', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(EL-GB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('06a1bf04-2bb1-4115-8749-c2558dc3af1f', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(OD-CMB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('cad851f2-f503-4313-bace-a00b23ce3fdb', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GTRF(TF)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('b4ea4251-e63d-41e1-a50d-79f3a64dde50', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(UPL)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('8d9e0a5b-4965-4014-923c-128e530550e9', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(CL-RBB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('3fddbdb2-27f7-49ad-b7a8-ab6d90ab6c2c', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(RBB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('e9103840-bf2e-4bf6-8c7e-1939f93e99c5', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GTRF(GTE)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('a88b0a0a-ef2b-401a-9d99-99d4e996bc7b', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GTRF(RFN)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('337a3900-ffbe-4df8-9efa-9e91e8ac747c', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'GTRF(BADI)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('069725df-1265-41f2-a33f-c737136ff1e9', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(CL-CMB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('7275f162-9502-400e-b2f6-b44ab567c354', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(CL-GB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('73353d61-c4cc-4e28-8ab9-3c3665330e05', 'bbbb', '7163276a97d346bcbad529ff8023714b', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'CDT(GB)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('e52671c5-b2df-4b3b-af80-733de1f67371', 'shTest', '31aa52b7fdb34749969bce5673abab7d', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(MGT)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('2e593925-2612-47eb-94d6-0dbabb2156c3', 'shTest', '31aa52b7fdb34749969bce5673abab7d', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(SBO)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('2863f9f7-7805-47d1-a31f-c02b6d596f22', 'shTest', '31aa52b7fdb34749969bce5673abab7d', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(UPL)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('14b6922c-3499-422b-8a10-a35f0a5353d2', 'admin1', '66361822c93247248cf3ca003c0e98c9', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(MGT)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('a2ca5720-9b91-4f2f-a883-31cd81fbea0c', 'admin1', '66361822c93247248cf3ca003c0e98c9', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(SBO)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('626a2e7e-20ea-4375-a1ac-fa96979e42b7', 'admin1', '66361822c93247248cf3ca003c0e98c9', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(UPL)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('b985d22a-a285-40df-917f-da4a04bdce94', 'young', '31aa52b7fdb34749969bce5673abab7d', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(MGT)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('1a30b7e3-7f2e-4c1b-a3b2-7db7e1dc2ad8', 'young', '31aa52b7fdb34749969bce5673abab7d', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(SBO)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('cc3d456d-4317-428e-aaa5-215785f7bbf1', 'young', '31aa52b7fdb34749969bce5673abab7d', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(UPL)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('0469eb5e-c790-45dd-ba6d-5b8720ec13d9', '021001', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(MGT)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('f269fcd9-05b1-46ab-a1a1-3651cc1d6e67', '021001', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(SBO)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('f487a1d9-0ef4-499e-8b36-2b102d8ea3db', '021001', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(UPL)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('be46b433-88a4-42a5-97bc-66dea7f9ca49', 'young2', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(MGT)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('97e16df3-92a6-4507-b9c9-5e1b5c1ea105', 'young2', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(SBO)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('1964bdf5-26a6-44a6-b59d-3e282b889ed7', 'young2', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(UPL)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('0148426d-aaf9-4003-82e7-84ec19af7b4f', 'testhh1', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(MGT)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('bb22e581-ceea-4d0a-82f5-b50e1a0e5547', 'testhh1', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(SBO)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('f9c1555a-18bf-40b1-907f-851c95a41e8d', 'testhh1', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(UPL)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('b633d5d6-d3c5-4709-a511-77b41363c22c', 'caroline', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(MGT)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('87b01f99-d106-4c10-b352-1a3398facf1e', 'caroline', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(SBO)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('c15b864c-8070-4d4d-bb4e-905c5af371bf', 'caroline', 'df18554461eb44be9bcb443a4b1d9f7f', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(UPL)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('4a145d53-b761-4658-b295-d0d70cef30fa', 'admin', '31aa52b7fdb34749969bce5673abab7d', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(MGT)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('7371f7e4-f571-4bed-a245-5c99b3f2b22e', 'admin', '31aa52b7fdb34749969bce5673abab7d', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(SBO)');

INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('b55a2e67-ab06-4fad-859f-8b708294c371', 'admin', '31aa52b7fdb34749969bce5673abab7d', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, 'RBWM(UPL)');

