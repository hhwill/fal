delete from GP_BM_SYS_STAT where data_id = '49943b8359084fe19f5fa79f20a6581b';
