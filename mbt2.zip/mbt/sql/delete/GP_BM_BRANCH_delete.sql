delete from GP_BM_BRANCH where data_id = '3ffba8018f074a32ae4553487d169f4b';
delete from GP_BM_BRANCH where data_id = '3614facf6c7d470cb4d6f836b5d9e733';
delete from GP_BM_BRANCH where data_id = '41f73aa8f2b740898a56b5ab44c134f4';
delete from GP_BM_BRANCH where data_id = '10579d37612e4b9eb090b4b4c8888035';
