INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('95588aed-b7e4-42b5-ae37-8443b373cc34', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GTRF(DC)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('31fc4344-98b6-4220-974f-cab6c2f2801c', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GTRF(DC)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('b80de4c5-6edf-43b4-9a31-6c94fa3c70a3', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GTRF(RFN)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('713b85f7-a595-47a9-b448-7dd25e1bbd58', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GTRF(RFN)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('ff13b28b-9330-4c66-a944-9296682960a3', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'RBWM(SBO)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('13c71e3c-d242-41c7-ac1f-6ab40fdcf270', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'RBWM(SBO)',
        '31aa52b7fdb34749969bce5673abab7d', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('8d9eea1a-eb20-4af9-8447-a01df0eb7805', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'RBWM(SBO)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('a7450bb5-67ff-4aab-ae1e-051cd9f63fe1', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'RBWM(SBO)',
        '66361822c93247248cf3ca003c0e98c9', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('9b2e0612-74cb-40a0-aa64-78815298a8f3', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GDL',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('5dab67df-18b6-4b48-a3eb-1e58bd8427fc', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GDL',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('51aa64c1-f306-4c9f-83c6-76b6aaef0571', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'WCAS(BRANCH)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('a7951cc7-6237-4728-8b34-0e546c27ce36', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'WCAS(BRANCH)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('83cf8fa1-9347-453f-815f-758dc96d9d5a', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(OD-CMB)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('ac6b4a58-8650-404e-95cf-d558ae3b9d8c', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(OD-CMB)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('54a5762b-24bc-42dd-992a-2ef427894b5c', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GTRF(BADI)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('67397db9-8c3d-454b-a620-99578b87b4fb', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GTRF(BADI)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('c6e01d61-1d3a-401f-900a-2100bf960ee9', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(CL-GB)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('2541e482-3ec1-4707-9a4e-9513b4fa9224', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(CL-GB)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('526ce6ff-5183-46dc-b89b-0c00fa11fb59', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(GB)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('8a3dd4b1-1a1f-417c-97da-b5cb11317d7f', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(GB)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('a5e61e5b-be7c-4e16-8bc5-e4b2bcc81bad', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'RBWM(MGT)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('9e348ed2-2e7a-4b82-9c2d-5f7746aa0912', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'RBWM(MGT)',
        '31aa52b7fdb34749969bce5673abab7d', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('5e1fad50-a86b-493c-9b72-5c14c1cc5ea3', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'RBWM(MGT)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('54837e1b-7fa4-4955-b855-b3aa8a8ccdc8', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'RBWM(MGT)',
        '66361822c93247248cf3ca003c0e98c9', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('e7f462bf-b69a-441f-921b-afd1fdf3a1b4', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'RBWM(UPL)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('31ee1bf7-22da-4167-894f-e3f09418a498', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'RBWM(UPL)',
        '31aa52b7fdb34749969bce5673abab7d', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('05e24f6d-6268-491b-b76e-1b0498e3a890', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'RBWM(UPL)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('2f62924e-7e9a-4c80-9e24-632caa1eaac3', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'RBWM(UPL)',
        '66361822c93247248cf3ca003c0e98c9', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('cb6465a5-c2da-4b65-9e11-7354fbe3ee21', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(EL-CMB)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('dcb85dee-f25c-4048-a54c-6154d0779796', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(EL-CMB)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('0432c500-7f8e-4c0d-a6b9-c62a08216d58', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GTRF(OAM)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('6c4a489d-43f4-485c-8dc0-58bf83ac64dc', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GTRF(OAM)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('67b37e9c-6406-4f37-aca3-ea934d64924e', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(RBB)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('ff258e46-aa90-47b1-adc4-35c8dc337000', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(RBB)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('afaf7265-7609-4b15-af5b-5e21323830bd', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(CL-CMB)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('cdeae8bb-ea55-4ce8-9bef-2f427e26a926', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(CL-CMB)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('36234c6f-4e02-427f-b071-449d4b1a017d', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GTRF(GTE)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('874230a9-2f0d-44c3-95c3-104f126c661c', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GTRF(GTE)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('0706dfd3-b335-4a43-b4d2-f24269394f93', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GTRF(BADD)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('ec73d465-323c-446b-ba1a-63915de2764c', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GTRF(BADD)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('25e2dcd8-d867-4885-9fa5-600461e1febd', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(OD-GB)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('dd51465d-19d7-4790-985a-e8d23109252f', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(OD-GB)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('ca2873cc-ce61-41ea-a4c5-29e4744abc00', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(CMB)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('55ae5504-9dd0-4056-9b2e-0fc7a06fda85', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(CMB)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('d117a85a-7466-488d-9609-2cd322c526cf', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('c36f1877-972b-44de-8937-9c134389b82d', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('1d05db73-a73d-434b-ac2e-459e339d6cab', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(EL-GB)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('a33f0632-e42c-46a6-b933-67df684bda66', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(EL-GB)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('5822a02f-9e01-4ffd-b736-35a47c92ae66', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GTRF(TF)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('a41cc392-141b-4d2c-a461-2a1e70a40fce', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'GTRF(TF)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('7cb620ee-0fb0-42ec-83ba-ba69caca15b5', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(CL-RBB)',
        'df18554461eb44be9bcb443a4b1d9f7f', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('19a863d9-cb30-41a2-a121-3923192c2bc6', '20210329', 'GINGKOO', '9999', 'HZ', null, null, 'CDT(CL-RBB)',
        '7163276a97d346bcbad529ff8023714b', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);
