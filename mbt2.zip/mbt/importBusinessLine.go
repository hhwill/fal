package main

import (
	"fmt"
	uuid "github.com/satori/go.uuid"
	"github.com/tealeg/xlsx/v3"
	"log"
	"mbtDbUtils/config"
	"mbtDbUtils/db"
	"strings"
)

//导入业务线相关数据
func importBusinessLine() []string {
	var mapListString = make(map[string]string)
	if config.Cfg.ImportBusinessLineFlag {
		done := importBusinessLineByExcel(mapListString)
		if done {
			return nil
		}
	} else {
		done := importBusinessLineByEastDepart(mapListString)
		if done {
			return nil
		}
	}

	//生成GP_BM_BUSINESS_LINE表的 SQL语句
	var sqlList []string
	var businessLineSqlList []string
	var businessLineList []string
	businessLineSqlStr := `INSERT INTO GP_BM_BUSINESS_LINE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, BUSINESS_LINE_NAME, STATUS, REMARKS, CHECK_FLAG, CHECK_DESC,
                                           CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                           DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                           DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                           DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, GPMS_NEXT_ACTION)
		VALUES ('%s', '20210105', 'GINGKOO', '9999', 'XD', null, null, '%s', '%s', '1', null,
        'N', null, null, '20', null, 'O', '3', 1, null, null, 'admin', '20191212', '20191212182856', 'admin',
        '20210105', '20210105133558', 'admin1', '20191212', '20191212182904', null, null, null, null, null, '31');`
	var dataIdList []string
	for businessLine, businessLineName := range mapListString {
		dataId := uuid.NewV4().String()
		if config.Cfg.DeleteSqlFlag {
			sqlList = append(sqlList, db.GetDeleteSql("GP_BM_BUSINESS_LINE", dataId))
		}
		dataIdList = append(dataIdList, dataId)
		businessLineStr := fmt.Sprintf(businessLineSqlStr, dataId, businessLine, businessLineName) + "\n"
		businessLineSqlList = append(businessLineSqlList, businessLineStr)
		businessLineList = append(businessLineList, businessLine)
	}
	db.CreateDeleteSqlFile("GP_BM_BUSINESS_LINE", dataIdList)
	sqlList = append(sqlList, db.GenerateSqlFile(businessLineSqlList, "GP_BM_BUSINESS_LINE")...)
	//处理关联关系
	//1、查询 GP_BM_TLR_ROLE_REL 表
	gpBmTlrRoleRelList, err := db.DoQuery("select TLRNO,ROLE_ID from GP_BM_TLR_ROLE_REL")
	if err != nil {
		log.Panicf("查询 GP_BM_TLR_ROLE_REL 表失败，错误原因为：%s", err)
		return nil
	}
	gpBmTlrRoleRelSqlStr := `INSERT INTO GP_BM_TLR_ROLE_REL (DATA_ID, TLRNO, ROLE_ID, STATUS, RSV5, CORP_ID, ORG_ID, GROUP_ID, CHECK_FLAG,
                                          CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE,
                                          DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                                          DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER,
                                          DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, REMARKS, DATA_DATE,
                                          BUSINESS_LINE)
VALUES ('%s', '%s', '%s', null, null, null, null, null,
        null, null, null, null, null, null, null, null, null, null, 'admin', null, null, null, null, null, null, null,
        null, null, null, null, null, null, null, '%s');
`
	tlrMap, err := db.QueryMap("select TLRNO,GROUP_ID from GP_BM_TLR_INFO", "TLRNO", "GROUP_ID", false)
	if err != nil {
		log.Panicf("查询 GP_BM_TLR_INFO 表失败，错误原因为：%s", err)
		return nil
	}
	var gpBmTlrRoleRelSqlList []string
	var businessLineRoleMapList = make(map[string]map[string]string)
	//2、处理 GP_BM_TLR_ROLE_REL 表数据
	var tlrRoleDataIdList []string
	for _, gpBmTlrRoleRel := range gpBmTlrRoleRelList {
		if gpBmTlrRoleRel["TLRNO"] == nil {
			continue
		}
		tlrNo := gpBmTlrRoleRel["TLRNO"].(string)
		groupId := tlrMap[tlrNo]
		for _, businessLine := range businessLineList {
			//业务线的名字 比部门的名字长，如果业务线名字中 出现了这个部门，业务线授权给这个人。
			//groupId 为 % 是测试用的 账号，应该是拥有所有的权限
			if strings.Index(businessLine, groupId) > -1 || groupId == "%" {
				dataId := uuid.NewV4().String()
				if config.Cfg.DeleteSqlFlag {
					sqlList = append(sqlList, db.GetDeleteSql("GP_BM_TLR_ROLE_REL", dataId))
				}
				tlrRoleDataIdList = append(tlrRoleDataIdList, dataId)
				gpBmTlrRoleRelSql := fmt.Sprintf(gpBmTlrRoleRelSqlStr, dataId, tlrNo, gpBmTlrRoleRel["ROLE_ID"], businessLine) + "\n"
				gpBmTlrRoleRelSqlList = append(gpBmTlrRoleRelSqlList, gpBmTlrRoleRelSql)
				businessLineRoleMap := businessLineRoleMapList[businessLine]
				if businessLineRoleMap == nil {
					businessLineRoleMap = make(map[string]string)
					businessLineRoleMap[gpBmTlrRoleRel["ROLE_ID"].(string)] = ""
				} else {
					businessLineRoleMap[gpBmTlrRoleRel["ROLE_ID"].(string)] = ""
				}
				businessLineRoleMapList[businessLine] = businessLineRoleMap
			}
		}
	}
	db.CreateDeleteSqlFile("GP_BM_TLR_ROLE_REL", tlrRoleDataIdList)
	sqlList = append(sqlList, db.GenerateSqlFile(gpBmTlrRoleRelSqlList, "GP_BM_TLR_ROLE_REL")...)
	//3、处理 GP_BM_BUSINESS_LINE_ROLE 表数据
	var businessLineRoleSqlList []string
	businessLineRoleSqlStr := `INSERT INTO GP_BM_BUSINESS_LINE_ROLE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID,
                                           BUSINESS_LINE, ROLE_ID, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION,
                                           DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC,
                                           DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER,
                                           DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME,
                                           RSV1, RSV2, RSV3, RSV4, RSV5, DATA_HASH)
VALUES ('%s', '20210329', 'GINGKOO', '9999', 'HZ', null, null, '%s',
        '%s', 'N', null, null, '99', '04', '0', null, 'O', 0, null, null, 'admin', null,
        null, 'admin', '20210329', '20210329143841', null, null, null, null, null, null, null, null, null);`
	var businessLineDataIdList []string
	for businessLine, roleList := range businessLineRoleMapList {
		for role := range roleList {
			dataId := uuid.NewV4().String()
			if config.Cfg.DeleteSqlFlag {
				sqlList = append(sqlList, db.GetDeleteSql("GP_BM_BUSINESS_LINE_ROLE", dataId))
			}
			businessLineDataIdList = append(businessLineDataIdList, dataId)
			businessLineRoleSql := fmt.Sprintf(businessLineRoleSqlStr, dataId, businessLine, role) + "\n"
			businessLineRoleSqlList = append(businessLineRoleSqlList, businessLineRoleSql)
		}
	}
	db.CreateDeleteSqlFile("GP_BM_BUSINESS_LINE_ROLE", businessLineDataIdList)
	sqlList = append(sqlList, db.GenerateSqlFile(businessLineRoleSqlList, "GP_BM_BUSINESS_LINE_ROLE")...)
	return sqlList
}

//导入业务线相关数据-查询数据库
func importBusinessLineByEastDepart(mapString map[string]string) bool {
	eastDepartList, err := db.DoQuery("select DEPART,DEPART_NAME from EAST_DEPART")
	if err != nil {
		log.Panicf("查询 EAST_DEPART 表失败，错误原因为：%s", err)
		return true
	}
	for _, eastDepart := range eastDepartList {
		depart := db.ConvertValue(eastDepart["DEPART"])
		departName := db.ConvertValue(eastDepart["DEPART_NAME"])
		mapString[depart] = departName
	}
	return false
}

//导入业务线相关数据-读取Excel
func importBusinessLineByExcel(mapString map[string]string) bool {
	file, err := xlsx.OpenFile("./xlsx/业务条线整理.xlsx")
	if err != nil {
		log.Panicf("导入 业务条线整理.xlsx 文件失败，错误原因为：%s", err)
		return true
	}
	sheet := file.Sheet["Sheet1"]
	var i = 1
	for i < sheet.MaxRow {
		row, err := sheet.Row(i)
		panicError(err)
		if len(row.GetCell(4).Value) > 0 && len(row.GetCell(5).Value) > 0 {
			mapString[row.GetCell(4).Value] = row.GetCell(5).Value
		}
		i++
	}
	return false
}
