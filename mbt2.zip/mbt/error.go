package main

import "log"

func panicError(err error) {
	if err != nil {
		panic(err)
	}
}

func panicErrWithMsg(err error, errMsg string) {
	if err != nil {
		log.Panic(err, errMsg)
	}
}

func panicBiz(errMsg string) {
	panic(errMsg)
}
