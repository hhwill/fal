-- 删除角色 菜单 关联表 垃圾数据
delete
from GP_BM_ROLE_FUNC_REL
where FUNCID not in (select GP_BM_FUNCTION.FUNCID from GP_BM_FUNCTION)