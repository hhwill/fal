package main

import (
	"fmt"
	"github.com/tealeg/xlsx/v3"
	"log"
	"mbtDbUtils/db"
)

//生成 数据字典SQL
func importDataDic() []string {
	log.Print("开始生成数据字典SQL！")
	var mapString = make(map[string]string)
	if importDataDicByExcel(mapString) {
		return nil
	}
	var dataTypeNoList []string
	for dataTypeNo := range mapString {
		dataTypeNoList = append(dataTypeNoList, dataTypeNo)
	}
	dataTypeNoStr := getDataTypeNoStr(dataTypeNoList)
	//查询新数据库中 存在的 DATA_TYPE_NO
	sql := fmt.Sprintf("select distinct DATA_TYPE_NO from GP_BM_DATA_DIC where DATA_TYPE_NO in (%s)", dataTypeNoStr)
	queryMap, err := db.QueryMap(sql, "DATA_TYPE_NO", "", true)
	if err != nil {
		log.Panicf("生成数据字典SQL失败，查询信息数据库失败，错误原因为：%s", err)
		return nil
	}
	dataTypeNoNewList := mapKeyToList(queryMap)
	dataTypeNoList = []string{}
	for dataTypeNo := range mapString {
		//当前数据库中 有 Excel 中的数据就不从老数据库进行导出了
		if IsContain(dataTypeNoNewList, dataTypeNo) {
			continue
		}
		dataTypeNoList = append(dataTypeNoList, dataTypeNo)
	}
	sql = fmt.Sprintf("select * from GP_BM_DATA_DIC where DATA_TYPE_NO in (%s)", dataTypeNoStr)
	sqlList := db.SyncTable("GP_BM_DATA_DIC", sql)
	log.Print("生成数据字典SQL结束！")
	return sqlList
}

func getDataTypeNoStr(dataTypeNoList []string) string {
	var dataTypeNoStr string
	for index, dataTypeNo := range dataTypeNoList {
		if index > 0 {
			dataTypeNoStr = dataTypeNoStr + ","
		}
		dataTypeNoStr = dataTypeNoStr + "'" + dataTypeNo + "'"
	}
	return dataTypeNoStr
}

func mapKeyToList(mapString map[string]string) []string {
	var strList []string
	for key := range mapString {
		strList = append(strList, key)
	}
	return strList
}

//导入数据字典-读取Excel
func importDataDicByExcel(mapString map[string]string) bool {
	file, err := xlsx.OpenFile("./xlsx/ETL中字典表使用情况.xlsx")
	if err != nil {
		log.Panicf("导入 ETL中字典表使用情况.xlsx 文件失败，错误原因为：%s", err)
		return true
	}
	sheet := file.Sheet["字典表整理"]
	var i = 1
	for i < sheet.MaxRow {
		row, err := sheet.Row(i)
		panicError(err)
		if len(row.GetCell(2).Value) > 0 && len(row.GetCell(3).Value) > 0 {
			mapString[row.GetCell(2).Value] = row.GetCell(3).Value
		}
		i++
	}
	return false
}
