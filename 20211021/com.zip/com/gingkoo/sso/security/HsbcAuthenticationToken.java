package com.gingkoo.sso.security;

import java.util.Collection;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

public class HsbcAuthenticationToken extends AbstractAuthenticationToken {
    private static final long serialVersionUID = 420L;
    private final Object principal;
    private Object credentials;
    private String username;
    private String email;
    private String adGroup;

    public HsbcAuthenticationToken(Object principal, Object credentials, String adGroup) {
        super(null);
        this.principal = principal;
        this.credentials = credentials;
        this.adGroup = adGroup;
        this.setAuthenticated(false);
    }

    public HsbcAuthenticationToken(Object principal, Object credentials, String adGroup,
                                   Collection<? extends GrantedAuthority> authorities) {
        super(authorities);
        this.principal = principal;
        this.credentials = credentials;
        this.adGroup = adGroup;
        super.setAuthenticated(true);
    }

    public Object getCredentials() {
        return this.credentials;
    }

    public Object getPrincipal() {
        return this.principal;
    }

    public String getAdGroup() {
        return adGroup;
    }

    public void setAuthenticated(boolean isAuthenticated) throws IllegalArgumentException {
        if (isAuthenticated) {
            throw new IllegalArgumentException("Cannot set this token to trusted - use constructor which takes a GrantedAuthority list instead");
        } else {
            super.setAuthenticated(false);
        }
    }

    public void eraseCredentials() {
        super.eraseCredentials();
        this.credentials = null;
    }

    public void setCredentials(Object credentials) {
        this.credentials = credentials;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setAdGroup(String adGroup) {
        this.adGroup = adGroup;
    }
}
