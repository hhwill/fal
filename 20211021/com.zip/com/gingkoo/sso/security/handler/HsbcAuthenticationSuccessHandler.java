package com.gingkoo.sso.security.handler;

import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.Contract;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.gingkoo.common.security.config.GkWebAuthenticationDetails;
import com.gingkoo.common.security.config.UserInfo;
import com.gingkoo.common.security.principal.SecurityPrincipal;
import com.gingkoo.common.security.service.UserRoleService;
import com.gingkoo.gf4j2.core.util.DateUtil;
import com.gingkoo.gf4j2.framework.entity.GpBmBranch;
import com.gingkoo.gf4j2.framework.entity.GpBmRoleInfo;
import com.gingkoo.gf4j2.framework.entity.GpBmTlrInfo;
import com.gingkoo.gf4j2.framework.entity.bean.ExtensBean;
import com.gingkoo.gf4j2.framework.entity.bean.UserSessionInfo;
import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.excp.CommonException;
import com.gingkoo.gf4j2.framework.util.ApplicationContextUtil;
import com.gingkoo.gf4j2.framework.util.DataFormat;
import com.gingkoo.gf4j2.framework.util.i18n.MessageResources;
import com.gingkoo.gpms.platform.security.smuser.SmUserRepository;

import static com.gingkoo.root.facility.datetime.ImmutableDateFormat.SIMPLE_DATE_TIME;

@Slf4j
@Component
public class HsbcAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    private final SmUserRepository smUserRepository;

    @Contract(pure = true)
    public HsbcAuthenticationSuccessHandler(SmUserRepository smUserRepository) {
        this.smUserRepository = smUserRepository;
    }

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) {
        updateSession(authentication);

        try {
            //兼容老程序 设置 GlobalInfo 和session
            UserInfo userInfo = SecurityPrincipal.getUserInfo();
            if (userInfo != null) {
                GlobalInfo globalInfo = GlobalInfo.initInstance();
                globalInfo.setTxnDate(DataFormat.trsUtilDateToSqlDate(new Date()));
                globalInfo.setTxnTime(DateUtil.getCurrentTime());
                GpBmTlrInfo gpBmTlrInfo = userInfo.getGpBmTlrInfo();
                globalInfo.setBrno(gpBmTlrInfo.getBrno());
                globalInfo.setBrcode(gpBmTlrInfo.getBrcode());
                globalInfo.setCorpId(gpBmTlrInfo.getCorpId());
                globalInfo.setOrgId(gpBmTlrInfo.getOrgId());
                globalInfo.setGroupId(gpBmTlrInfo.getGroupId());
                globalInfo.setTlrno(gpBmTlrInfo.getTlrno());
                globalInfo.setTlrName(gpBmTlrInfo.getTlrName());

                UserRoleService userRoleService = ApplicationContextUtil.getBean(UserRoleService.class);
                GpBmBranch gpBmBranch = userRoleService.getGpBmBranchByBrno(gpBmTlrInfo.getBrno());
                if (gpBmBranch != null) {
                    globalInfo.setBrName(gpBmBranch.getBrname());
                    globalInfo.setBrClass(gpBmBranch.getBrclass());
                }

                //国际化设置
                Locale locale = MessageResources.getlocale(request);
                globalInfo.setLocale(locale);
                //权限映射的创建,用户的功能列表的获取
                userRoleService.initGlobalInfoWithGpBmFunction(globalInfo);
                //处理扩展
                List<GpBmRoleInfo> gpBmRoleInfos = userInfo.getGpBmRoleInfos();
                ExtensBean exbean = new ExtensBean();
                exbean.setRoleList(gpBmRoleInfos);
                //人员名称
                exbean.setTlrName(globalInfo.getTlrName());
                globalInfo.setExtensBean(exbean);
                GlobalInfo.setCurrentInstance(globalInfo);

                UserSessionInfo sessionInfo = new UserSessionInfo();
                sessionInfo.setTlrNo(globalInfo.getTlrno());
                sessionInfo.setTlrName(globalInfo.getTlrName());
                sessionInfo.setTxDate(globalInfo.getTxnDate());
                /* 20191209 add by cjm begin */
                sessionInfo.setLastLoginTime(gpBmTlrInfo.getLastAccessTime());
                sessionInfo.setLastLoginFailTime(gpBmTlrInfo.getLastFailedTime());
                sessionInfo.setLastLogoutTime(gpBmTlrInfo.getLastLogoutTime());
                /* 20191209 add by cjm end */
                request.getSession().setAttribute(UserSessionInfo.USER_SESSION_INFO, sessionInfo);
                request.getSession().setAttribute(GlobalInfo.KEY_GLOBAL_INFO, globalInfo);
            }

        } catch (CommonException e) {
            log.info("Set GlobalInfo error", e);
        }
    }

    private void updateSession(Authentication authentication) {
        Object principal = authentication.getPrincipal();
        if (principal instanceof UserInfo) {
            GpBmTlrInfo tlrInfo = ((UserInfo) principal).getGpBmTlrInfo();
            tlrInfo.setLastAccessTime(SIMPLE_DATE_TIME.format(new Date()));

            Object details = authentication.getDetails();
            if (details instanceof GkWebAuthenticationDetails) {
                GkWebAuthenticationDetails webAuthenticationDetails = (GkWebAuthenticationDetails) details;
                tlrInfo.setLoginIp(webAuthenticationDetails.getRealAddress());
                tlrInfo.setSessionId(webAuthenticationDetails.getSessionId());
            }

            smUserRepository.updateSession(tlrInfo.getDataId(),
                    tlrInfo.getSessionId(), tlrInfo.getLoginIp(), tlrInfo.getLastAccessTime());
        }
    }
}
