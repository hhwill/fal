package com.gingkoo.sso.security.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.ssl.Base64;
import org.opensaml.DefaultBootstrap;
import org.opensaml.common.SAMLVersion;
import org.opensaml.saml2.core.*;
import org.opensaml.saml2.core.impl.*;
import org.joda.time.DateTime;

import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.io.Marshaller;
import org.opensaml.xml.io.MarshallingException;
import org.opensaml.xml.util.XMLHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gingkoo.sso.security.config.HsbcProperties;

import static org.opensaml.xml.Configuration.getMarshallerFactory;

@Slf4j
@Service
public class HsbcUserService {

    private final HsbcProperties properties;

    public HsbcUserService(HsbcProperties properties) {
        this.properties = properties;
    }

    @Transactional
    public String createSamlRequestURL() throws ConfigurationException, MarshallingException, IOException {
        IssuerBuilder issuerBuilder = new IssuerBuilder();
        Issuer issuerOb = issuerBuilder.buildObject("urn:oasis:names:tc:SAML:2.0:assertion", "Issuer", "saml");
        issuerOb.setValue(properties.getEntityId());

        NameIDPolicyBuilder nameIDPolicyBuilder = new NameIDPolicyBuilder();
        NameIDPolicy nameIDPolicy = nameIDPolicyBuilder.buildObject();
        nameIDPolicy.setFormat("urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified");
        nameIDPolicy.setAllowCreate(true);

        AuthnContextClassRefBuilder authnContextClassRefBuilder = new AuthnContextClassRefBuilder();
        AuthnContextClassRef authnContextClassRef = authnContextClassRefBuilder.buildObject("urn:oasis:names:tc:SAML" +
                ":2.0:assertion", "AuthnContextClassRef", "saml");
        authnContextClassRef.setAuthnContextClassRef("urn:oasis:names:tc:SAML:2.0:ac:classes:unspecified");

        RequestedAuthnContextBuilder requestedAuthnContextBuilder = new RequestedAuthnContextBuilder();
        RequestedAuthnContext requestedAuthnContext = requestedAuthnContextBuilder.buildObject();
        requestedAuthnContext.setComparison(AuthnContextComparisonTypeEnumeration.EXACT);
        requestedAuthnContext.getAuthnContextClassRefs().add(authnContextClassRef);

        SecureRandom secRandom = new SecureRandom();
        byte[] result = new byte[18];
        secRandom.nextBytes(result);
        String authReqRandomId = String.valueOf(Hex.encodeHex(result));

        AuthnRequestBuilder authnRequestBuilder = new AuthnRequestBuilder();
        AuthnRequest authnRequest = authnRequestBuilder.buildObject("urn:oasis:names:tc:SAML:2.0:protocol",
                "AuthnRequest", "samlp");
        DateTime issueInstant = new DateTime();
        authnRequest.setIssueInstant(issueInstant);
        authnRequest.setProtocolBinding("urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST");
        authnRequest.setAssertionConsumerServiceURL(properties.getConsumerServiceUrl());
        authnRequest.setIssuer(issuerOb);
        authnRequest.setNameIDPolicy(nameIDPolicy);
        authnRequest.setRequestedAuthnContext(requestedAuthnContext);
        authnRequest.setID("VIDEO_" + authReqRandomId);
        authnRequest.setDestination(properties.getDestinationUrl());
        authnRequest.setVersion(SAMLVersion.VERSION_20);

        DefaultBootstrap.bootstrap();

        Marshaller marshaller = getMarshallerFactory().getMarshaller(authnRequest);
        org.w3c.dom.Element authDOM = marshaller.marshall(authnRequest);
        StringWriter rspWrt = new StringWriter();
        XMLHelper.writeNode(authDOM, rspWrt);
        String messageXML = rspWrt.toString();

        ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
        Deflater deflater = new Deflater(Deflater.DEFLATED, true);
        DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(bytesOut, deflater);
        deflaterOutputStream.write(messageXML.getBytes(StandardCharsets.UTF_8));
        deflaterOutputStream.finish();
        log.info(messageXML);

        String samlRequest = new String(Base64.encodeBase64(bytesOut.toByteArray()));
        return properties.getDestinationUrl() + "?SAMLRequest=" + URLEncoder.encode(samlRequest, "UTF-8");
    }
}
