package com.gingkoo.sso.security.service;

import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.Contract;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

@Slf4j
class HsbcUserDetailsService implements UserDetailsService {

    private final UserDetailsService delegate;

    @Contract(pure = true)
    public HsbcUserDetailsService(UserDetailsService delegate) {
        this.delegate = delegate;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserDetails userDetails;
        try {
            userDetails = delegate.loadUserByUsername(username);
        } catch (UsernameNotFoundException e) {
            throw new UsernameNotFoundException("Username [" + username + "] not find ", e);
        }
        return userDetails;
    }

}
