package com.gingkoo.sso.security.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Contract;
import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.gingkoo.common.security.config.UserInfo;
import com.gingkoo.gf4j2.framework.entity.GpBmRoleInfo;
import com.gingkoo.gf4j2.framework.entity.GpBmTlrInfo;
import com.gingkoo.sso.security.HsbcAuthenticationToken;
import com.gingkoo.sso.security.bean.HsbcUser;
import com.gingkoo.sso.security.repository.HsbcUserRepository;

@Component
public class HsbcAuthenticationUserDetailsService implements AuthenticationUserDetailsService<HsbcAuthenticationToken> {

    private final UserDetailsService userDetailsService;
    private final HsbcUserRepository hsbcUserRepository;


    @Contract(pure = true)
    public HsbcAuthenticationUserDetailsService(UserDetailsService userDetailsService, HsbcUserRepository hsbcUserRepository) {
        this.userDetailsService = new HsbcUserDetailsService(userDetailsService);
        this.hsbcUserRepository = hsbcUserRepository;
    }

    public static int getIndexOf(String data, String str, int num) {
        Pattern pattern = Pattern.compile(str);
        Matcher findMatcher = pattern.matcher(data);
        //标记遍历字符串的位置
        int indexNum = 0;
        while (findMatcher.find()) {
            indexNum++;
            if (indexNum == num) {
                break;
            }
        }
        return findMatcher.start();
    }

    @Override
    public UserDetails loadUserDetails(HsbcAuthenticationToken token) throws UsernameNotFoundException {
        String username = token.getName();
        if (username.length() > 1024) {
            throw new UsernameNotFoundException("User id is too lang.");
        }
        UserDetails userDetails;
        synchronized (username.intern()) {
            try {
                userDetails = userDetailsService.loadUserByUsername(username);
            } catch (UsernameNotFoundException ignore) {
                HsbcUser user = new HsbcUser();
                user.setId((String) token.getPrincipal());
                user.setName(token.getUsername());
                user.setEmail(token.getEmail());
                user.setOrg("HSBC");
                user.setActive(true);

                String adGroup = token.getAdGroup();
                List<GpBmRoleInfo> roles = new ArrayList<>();
                if (StringUtils.isNotEmpty(adGroup)) {
                    String role = adGroup.substring(getIndexOf(adGroup, "-", 3) + 1);
                    GpBmRoleInfo checker = hsbcUserRepository.loadCache(role);
                    if (checker != null) {
                        roles.add(checker);
                    } else {
                        throw new UsernameNotFoundException("User role not find.");
                    }
                    user.setRole(role);
                }
                hsbcUserRepository.createUser(user, roles);
                userDetails = userDetailsService.loadUserByUsername(username);
            }
            if (userDetails instanceof UserInfo) {
                UserInfo userInfo = ((UserInfo) userDetails);
                GpBmTlrInfo gpBmTlrInfo = userInfo.getGpBmTlrInfo();
                String role = gpBmTlrInfo.getRoleId();
                String adGroup = token.getAdGroup();

                if (StringUtils.isEmpty(role) || (StringUtils.isNotEmpty(adGroup) && !adGroup.endsWith(role))) {
                    role = adGroup.substring(getIndexOf(adGroup, "-", 3) + 1);
                    gpBmTlrInfo.setRoleId(role);
                    hsbcUserRepository.updateGpBmTlrInfoAdGroup(gpBmTlrInfo);
                    List<GpBmRoleInfo> roles = new ArrayList<>();
                    if (StringUtils.isNotEmpty(adGroup)) {
                        GpBmRoleInfo checker = hsbcUserRepository.loadCache(role);
                        if (checker != null) {
                            roles.add(checker);
                        } else {
                            throw new UsernameNotFoundException("User role not find.");
                        }
                    }
                    hsbcUserRepository.refreshRoles(gpBmTlrInfo, roles);
                }
            }
        }
        return userDetails;
    }

//    @Override
//    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//        List<Role> roles = userAccessor.getRoles(username);
//        log.info("Retrieve roles {} for `{}`", roles, username);
//
//        List<GpBmRoleInfo> roleInfoList = retrieveRoles(username, roles);
//
//        UserDetails userDetails = null;
//        try {
//            userDetails = delegate.loadUserByUsername(username);
//        } catch (UsernameNotFoundException ignored) {
//        }
//
//        if (userDetails == null) {
//            userDetails = createUser(username, roleInfoList);
//
//        } else if (userDetails instanceof UserInfo) {
//            Set<String> roleSet = roleInfoList.stream().map(GpBmRoleInfo::getRoleId).collect(toSet());
//
//            UserInfo userInfo = (UserInfo) userDetails;
//            Set<String> userRoleSet = userInfo.getGpBmRoleInfos().stream()
//                    .map(GpBmRoleInfo::getRoleId)
//                    .collect(toSet());
//
//            if (!roleSet.equals(userRoleSet)) {
//                userDetails = refreshRoles(username, userInfo.getGpBmTlrInfo(), roleInfoList);
//            }
//
//        } else {
//            throw new UsernameNotFoundException("Unknown UserDetails " + userDetails);
//        }
//
//        return userDetails;
//    }
//
//    private List<GpBmRoleInfo> retrieveRoles(String username, List<Role> roles) throws UsernameNotFoundException {
//        if (roles.isEmpty()) {
//            String message = format("No roles for `%s`", username);
//            log.error(message);
//            throw new UsernameNotFoundException(message);
//        }
//
//        List<GpBmRoleInfo> results = new ArrayList<>();
//        for (Role role : roles) {
//            Optional<GpBmRoleInfo> roleInfo = smUserRepository.findRole(role.getId());
//            if (!roleInfo.isPresent()) {
//                String message = format("Unknown role `%s` for `%s`", role, username);
//                log.error(message);
//                throw new UsernameNotFoundException(message);
//            }
//            results.add(roleInfo.get());
//        }
//
//        return results;
//    }
//
//    private UserDetails createUser(String username, List<GpBmRoleInfo> roles) throws UsernameNotFoundException {
//        User user = userAccessor.getUser(username);
//        log.info("Retrieve user {}", user);
//
//        smUserRepository.createUser(user, roles);
//        return delegate.loadUserByUsername(username);
//    }
//
//    private UserDetails refreshRoles(String username, GpBmTlrInfo tlrInfo, List<GpBmRoleInfo> roles) {
//        smUserRepository.refreshRoles(tlrInfo, roles);
//        return delegate.loadUserByUsername(username);
//    }

}