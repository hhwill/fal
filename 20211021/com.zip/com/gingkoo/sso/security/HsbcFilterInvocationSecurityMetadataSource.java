package com.gingkoo.sso.security;

import java.util.*;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

import com.gingkoo.common.security.dao.JdbcRequestMapBulider;

public class HsbcFilterInvocationSecurityMetadataSource implements FilterInvocationSecurityMetadataSource, InitializingBean {
    private static final List<ConfigAttribute> NULL_CONFIG_ATTRIBUTE = null;
    // 资源权限集合
    private Map<RequestMatcher, Collection<ConfigAttribute>> requestMap;

    //查找数据库权限和资源关系
    private JdbcRequestMapBulider builder;

    public HsbcFilterInvocationSecurityMetadataSource() {

    }

    public HsbcFilterInvocationSecurityMetadataSource(
            LinkedHashMap<RequestMatcher, Collection<ConfigAttribute>> requestMap) {
        this.requestMap = requestMap;
    }

    /*
     * 更具访问资源的地址查找所需要的权限
     */
    @Override
    public Collection<ConfigAttribute> getAttributes(Object object) throws IllegalArgumentException {
        final HttpServletRequest request = ((FilterInvocation) object).getRequest();

        Collection<ConfigAttribute> attrs = NULL_CONFIG_ATTRIBUTE;
        for (Map.Entry<RequestMatcher, Collection<ConfigAttribute>> entry : requestMap.entrySet()) {
            if (entry.getKey().matches(request)) {
                attrs = entry.getValue();
                break;
            }
        }
        return attrs;
    }

    /*
     * 获取所有的权限
     */
    @Override
    public Collection<ConfigAttribute> getAllConfigAttributes() {
        Set<ConfigAttribute> allAttributes = new HashSet<>();
        for (Map.Entry<RequestMatcher, Collection<ConfigAttribute>> entry : requestMap.entrySet()) {
            allAttributes.addAll(entry.getValue());
        }
        return allAttributes;
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return FilterInvocation.class.isAssignableFrom(clazz);
    }

    //绑定requestMap
    protected Map<RequestMatcher, Collection<ConfigAttribute>> bindRequestMap() {
        Map<RequestMatcher, Collection<ConfigAttribute>> requestMap = builder.buildRequestMap();

        RequestMatcher apiMatcher = new AntPathRequestMatcher("/api/user/validate**");
        List<ConfigAttribute> apiConfigs = new ArrayList<>();
        apiConfigs.add(new SecurityConfig("ROLE_ANONYMOUS"));
        requestMap.put(apiMatcher, apiConfigs);

        RequestMatcher commonMatcher = new AntPathRequestMatcher("/common/**");
        List<ConfigAttribute> commonConfigs = new ArrayList<>();
        commonConfigs.add(new SecurityConfig("ROLE_ANONYMOUS"));
        requestMap.put(commonMatcher, commonConfigs);

        RequestMatcher requestMatcher = new AntPathRequestMatcher("/**");
        List<ConfigAttribute> configs = new ArrayList<>();
        configs.add(new SecurityConfig("ROLE_USER"));
        requestMap.put(requestMatcher, configs);

        return requestMap;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if (requestMap == null || requestMap.isEmpty()) {
            this.requestMap = this.bindRequestMap();
        } else {
            this.requestMap.putAll(this.bindRequestMap());
        }
    }

    public void refreshResuorceMap() {
        if (requestMap == null || requestMap.isEmpty()) {
            this.requestMap = this.bindRequestMap();
        } else {
            this.requestMap.putAll(this.bindRequestMap());
        }
    }

    /******************* GET & SET *******************************/
    public JdbcRequestMapBulider getBuilder() {
        return builder;
    }

    public void setBuilder(JdbcRequestMapBulider builder) {
        this.builder = builder;
    }
}