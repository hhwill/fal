package com.gingkoo.sso.security;

import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.io.MarshallingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.saml.util.SAMLUtil;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.web.filter.GenericFilterBean;

import com.gingkoo.sso.security.service.HsbcUserService;

public class HsbcEntryPoint extends GenericFilterBean implements AuthenticationEntryPoint {

    private final RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();
    private String filterProcessesUrl = "/login";
    @Autowired
    private HsbcUserService hsbcUserService;

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
                         AuthenticationException e) throws IOException, ServletException {
        try {
            String targetUrl = hsbcUserService.createSamlRequestURL();
            redirectStrategy.sendRedirect(request, response, targetUrl);
        } catch (ConfigurationException | MarshallingException ex) {
            request.setAttribute("errormsg", "IMAS用户验证失败," + ex.getMessage());
            request.getRequestDispatcher("/common/error.jsp").forward(request, response);
        }
    }

    public String getFilterProcessesUrl() {
        return filterProcessesUrl;
    }

    public void setFilterProcessesUrl(String filterProcessesUrl) {
        this.filterProcessesUrl = filterProcessesUrl;
    }

    protected boolean processFilter(HttpServletRequest request) {
        return SAMLUtil.processFilter(this.filterProcessesUrl, request);
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        FilterInvocation fi = new FilterInvocation(request, response, chain);
        if (!this.processFilter(fi.getRequest())) {
            chain.doFilter(request, response);
        } else {
            this.commence(fi.getRequest(), fi.getResponse(), null);
        }
    }
}
