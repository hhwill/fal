package com.gingkoo.sso.security.bean;

import lombok.Data;

@Data
public class HsbcUser {

    private String id;
    private String name;
    private String email;
    private String role;
    private String org;
    private boolean active;

}
