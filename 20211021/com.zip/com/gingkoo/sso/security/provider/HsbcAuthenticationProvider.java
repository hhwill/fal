package com.gingkoo.sso.security.provider;

import java.math.BigDecimal;
import java.util.Date;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceAware;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.SpringSecurityMessageSource;
import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
import org.springframework.security.core.authority.mapping.NullAuthoritiesMapper;
import org.springframework.security.core.userdetails.UserCache;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsChecker;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.core.userdetails.cache.NullUserCache;
import org.springframework.util.Assert;

import com.gingkoo.common.security.config.GkWebAuthenticationDetails;
import com.gingkoo.common.security.config.UserInfo;
import com.gingkoo.common.security.service.UserRoleService;
import com.gingkoo.gf4j2.framework.entity.GpBmLoginLog;
import com.gingkoo.gf4j2.framework.entity.GpBmTlrInfo;
import com.gingkoo.root.facility.string.UuidHelper;
import com.gingkoo.sso.security.HsbcAuthenticationToken;
import com.gingkoo.sso.security.service.HsbcAuthenticationUserDetailsService;

import static com.gingkoo.root.facility.datetime.ImmutableDateFormat.SIMPLE_DATE_TIME;

@Slf4j
public class HsbcAuthenticationProvider implements AuthenticationProvider, InitializingBean, MessageSourceAware {

    private final UserCache userCache = new NullUserCache();
    private final UserDetailsChecker preAuthenticationChecks = new DefaultPreAuthenticationChecks();
    private final UserDetailsChecker postAuthenticationChecks = new DefaultPostAuthenticationChecks();
    private final GrantedAuthoritiesMapper authoritiesMapper = new NullAuthoritiesMapper();
    @Autowired
    protected HsbcAuthenticationUserDetailsService userDetailsService;
    @Autowired
    protected UserRoleService userRoleService;
    protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();

    public HsbcAuthenticationProvider() {
    }

    protected void additionalAuthenticationChecks(UserDetails userDetails, HsbcAuthenticationToken authentication) throws AuthenticationException {
        GpBmTlrInfo gpBmTlrInfo = null;
        if (userDetails instanceof UserInfo) {
            gpBmTlrInfo = ((UserInfo) userDetails).getGpBmTlrInfo();
        }
        if (gpBmTlrInfo == null) {
            return;
        }

        if (authentication.getDetails() instanceof GkWebAuthenticationDetails) {
            GkWebAuthenticationDetails webAuthenticationDetails = (GkWebAuthenticationDetails) authentication.getDetails();
            gpBmTlrInfo.setLoginIp(webAuthenticationDetails.getRealAddress());
            gpBmTlrInfo.setSessionId(webAuthenticationDetails.getSessionId());
        }
        gpBmTlrInfo.setTotPswdErrCnt(new BigDecimal(0));

        Date now = new Date();
        String currentTime = SIMPLE_DATE_TIME.format(now);

        GpBmLoginLog gpBmLoginLog = new GpBmLoginLog();
        gpBmLoginLog.setLoginSucTm(gpBmTlrInfo.getLastAccessTime());
        gpBmLoginLog.setLoginRemark("登录成功");
        gpBmLoginLog.setTlrNo(gpBmTlrInfo.getTlrno());
        gpBmLoginLog.setBrNo(gpBmTlrInfo.getBrno());
        gpBmLoginLog.setCorpId(gpBmTlrInfo.getCorpId());
        gpBmLoginLog.setCrtTm(currentTime);
        gpBmLoginLog.setGroupId(gpBmTlrInfo.getGroupId());
        gpBmLoginLog.setLoginAddr(gpBmTlrInfo.getLoginIp());
        gpBmLoginLog.setSessionId(gpBmTlrInfo.getSessionId());
        gpBmLoginLog.setDataId(UuidHelper.fastClean());
        this.userRoleService.saveGpBmTlrInfoLoginInfoWithGpBmLoginLog(gpBmTlrInfo, gpBmLoginLog);

    }

    protected UserDetails retrieveUser(HsbcAuthenticationToken authentication) throws AuthenticationException {
        UserDetails loadedUser = this.userDetailsService.loadUserDetails(authentication);
        //todo sso返回用户信息本系统不存在则持久化
        if (loadedUser == null) {
            throw new InternalAuthenticationServiceException("UserDetailsService returned null, which is an interface contract violation");
        } else {
            return loadedUser;
        }
    }

    public final void afterPropertiesSet() throws Exception {
        Assert.notNull(this.userCache, "A user cache must be set");
        Assert.notNull(this.messages, "A message source must be set");
    }

    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        Assert.isInstanceOf(HsbcAuthenticationToken.class, authentication, this.messages.getMessage("HsbcAuthenticationProvider.onlySupports", "Only HsbcAuthenticationToken is supported"));
        String username = authentication.getPrincipal() == null ? "NONE_PROVIDED" : authentication.getName();
        boolean cacheWasUsed = true;
        UserDetails user = this.userCache.getUserFromCache(username);
        if (user == null) {
            cacheWasUsed = false;

            try {
                user = this.retrieveUser((HsbcAuthenticationToken) authentication);
            } catch (UsernameNotFoundException var6) {
                log.debug("User '" + username + "' not found");
                throw var6;
            }

            Assert.notNull(user, "retrieveUser returned null - a violation of the interface contract");
        }

        try {
            this.preAuthenticationChecks.check(user);
            this.additionalAuthenticationChecks(user, (HsbcAuthenticationToken) authentication);
        } catch (AuthenticationException var7) {
            if (!cacheWasUsed) {
                throw var7;
            }

            cacheWasUsed = false;
            user = this.retrieveUser((HsbcAuthenticationToken) authentication);
            this.preAuthenticationChecks.check(user);
            this.additionalAuthenticationChecks(user, (HsbcAuthenticationToken) authentication);
        }

        this.postAuthenticationChecks.check(user);
        if (!cacheWasUsed) {
            this.userCache.putUserInCache(user);
        }

        Object principalToReturn = user;
        return this.createSuccessAuthentication(principalToReturn, authentication, user);
    }

    protected Authentication createSuccessAuthentication(Object principal, Authentication authentication,
                                                         UserDetails user) {
        HsbcAuthenticationToken result = new HsbcAuthenticationToken(principal, authentication.getCredentials(),
                ((HsbcAuthenticationToken) authentication).getAdGroup(),
                this.authoritiesMapper.mapAuthorities(user.getAuthorities()));
        result.setDetails(authentication.getDetails());
        return result;
    }

    public void setMessageSource(MessageSource messageSource) {
        this.messages = new MessageSourceAccessor(messageSource);
    }

    public boolean supports(Class<?> authentication) {
        return HsbcAuthenticationToken.class.isAssignableFrom(authentication);
    }

    private class DefaultPostAuthenticationChecks implements UserDetailsChecker {
        private DefaultPostAuthenticationChecks() {
        }

        public void check(UserDetails user) {
            if (!user.isCredentialsNonExpired()) {
                log.debug("User account credentials have expired");
                throw new CredentialsExpiredException(HsbcAuthenticationProvider.this.messages.getMessage("HsbcAuthenticationProvider.credentialsExpired", "User credentials have expired"));
            }
        }
    }

    private class DefaultPreAuthenticationChecks implements UserDetailsChecker {
        private DefaultPreAuthenticationChecks() {
        }

        public void check(UserDetails user) {
            if (!user.isAccountNonLocked()) {
                log.debug("User account is locked");
                throw new LockedException(HsbcAuthenticationProvider.this.messages.getMessage("HsbcAuthenticationProvider.locked", "User account is locked"));
            } else if (!user.isEnabled()) {
                log.debug("User account is disabled");
                throw new DisabledException(HsbcAuthenticationProvider.this.messages.getMessage("HsbcAuthenticationProvider.disabled", "User is disabled"));
            } else if (!user.isAccountNonExpired()) {
                log.debug("User account is expired");
                throw new AccountExpiredException(HsbcAuthenticationProvider.this.messages.getMessage("HsbcAuthenticationProvider.expired", "User account has expired"));
            }
        }
    }
}
