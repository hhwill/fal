package com.gingkoo.sso.security.repository;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.github.benmanes.caffeine.cache.LoadingCache;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Contract;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;

import com.gingkoo.gf4j2.framework.entity.GpBmBranch;
import com.gingkoo.gf4j2.framework.entity.GpBmRoleInfo;
import com.gingkoo.gf4j2.framework.entity.GpBmTlrInfo;
import com.gingkoo.gf4j2.framework.util.BusinessEnum.REPORT_ST1;
import com.gingkoo.gpms.platform.security.smuser.repository.SmUserRoleRepository;
import com.gingkoo.gpms.platform.security.smuser.repository.SmUserTlrRepository;
import com.gingkoo.gpms.privilege.entity.GpBmBusinessLine;
import com.gingkoo.gpms.privilege.entity.GpBmTlrRoleBizRel;
import com.gingkoo.root.facility.datetime.ImmutableDateFormat;
import com.gingkoo.root.facility.lang.RandomHelper;
import com.gingkoo.root.facility.spring.annotation.InTransaction;
import com.gingkoo.root.facility.string.UuidHelper;
import com.gingkoo.sso.security.bean.HsbcUser;

import static com.gingkoo.root.facility.collection.CacheHelper.mediumCache;

@Repository
public class HsbcUserRepository {
    private final BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
    private final HsbcBusinessLineRepository businessLineRepository;
    private final HsbcBranchRepository branchRepository;
    private final SmUserTlrRepository tlrRepository;
    private final SmUserRoleRepository roleRepository;
    private final HsbcTlrRoleBizRelRepository roleRelRepository;
    private final LoadingCache<String, GpBmRoleInfo> roleCache = mediumCache(this::loadCache);

    @Contract(pure = true)
    public HsbcUserRepository(HsbcBusinessLineRepository businessLineRepository,
                              HsbcBranchRepository branchRepository, SmUserTlrRepository tlrRepository,
                              SmUserRoleRepository roleRepository, HsbcTlrRoleBizRelRepository roleRelRepository) {
        this.businessLineRepository = businessLineRepository;
        this.branchRepository = branchRepository;
        this.tlrRepository = tlrRepository;
        this.roleRepository = roleRepository;
        this.roleRelRepository = roleRelRepository;
    }

    public GpBmRoleInfo loadCache(String roleName) {
        return findRole(roleName).orElse(null);
    }

    public GpBmRoleInfo getCacheRole(String roleName) {
        return roleCache.get(roleName);
    }

    @InTransaction
    public GpBmTlrInfo updateGpBmTlrInfoAdGroup(GpBmTlrInfo gpBmTlrInfo) {
        GpBmTlrInfo hisTlrInfo = tlrRepository.getOne(gpBmTlrInfo.getDataId());
        hisTlrInfo.setRoleId(gpBmTlrInfo.getRoleId());
        return tlrRepository.save(hisTlrInfo);
    }

    public Optional<GpBmRoleInfo> findRole(String roleName) {
        return this.roleRepository.findByRoleNameIgnoreCase(roleName);
    }

    @InTransaction
    public void refreshRoles(GpBmTlrInfo tlrInfo, List<GpBmRoleInfo> roles) {
        this.roleRelRepository.deleteByTlrno(tlrInfo.getTlrno());
        this.saveRoles(tlrInfo, roles);
    }

    @InTransaction
    public void createUser(HsbcUser user, List<GpBmRoleInfo> roles) {
        Date now = new Date();
        String date = ImmutableDateFormat.SIMPLE_DATE.format(now);
        String time = ImmutableDateFormat.SIMPLE_DATE_TIME.format(now);

        String role = user.getRole();
        String groupId = role;
        if (StringUtils.isNotEmpty(role) && (role.endsWith("-SUP") || role.endsWith("-OPR"))) {
            groupId = role.substring(0, role.lastIndexOf('-'));
            GpBmBusinessLine businessLine = businessLineRepository.getFirstByBusinessLine(groupId);
            if (businessLine == null) {
                businessLine = new GpBmBusinessLine();
                businessLine.setDataId(UuidHelper.randomCleanUpper());
                businessLine.setBusinessLine(groupId);
                businessLine.setBusinessLineName(groupId);
                businessLine.setDataCrtDate(date);
                businessLine.setDataCrtTime(time);
                businessLineRepository.save(businessLine);
            }
        }

        String orgId = user.getOrg();
        GpBmBranch branch = branchRepository.getFirstByBrno(orgId);
        if (branch == null) {
            branch = new GpBmBranch();
            branch.setDataId(UuidHelper.randomCleanUpper());
            branch.setBrcode(orgId);
            branch.setBrno(orgId);
            branch.setGroupId(groupId);
            branch.setOrgId(orgId);
            branch.setCorpId(orgId);
            branch.setDataCrtDate(date);
            branch.setDataCrtTime(time);
            branchRepository.save(branch);
        }
        GpBmTlrInfo tlrInfo = new GpBmTlrInfo();
        tlrInfo.setDataId(UuidHelper.randomCleanUpper());
        tlrInfo.setTlrno(user.getId());
        tlrInfo.setTlrName(user.getName());
        tlrInfo.setEmail(user.getEmail());
        tlrInfo.setCorpId(branch.getCorpId());
        tlrInfo.setOrgId(branch.getOrgId());
        tlrInfo.setGroupId(branch.getGroupId());
        tlrInfo.setBrno(branch.getBrno());
        tlrInfo.setBrcode(branch.getBrcode());
        tlrInfo.setStatus("1");
        tlrInfo.setSt(REPORT_ST1.Y.value);
        tlrInfo.setIsLock("0");
        tlrInfo.setFlag("1");
        tlrInfo.setNextAction("99");
        tlrInfo.setDataStatus("04");
        tlrInfo.setDataDate(date);
        tlrInfo.setCredateDate(date);
        tlrInfo.setDataCrtUser("HSBC_USER");
        tlrInfo.setDataCrtDate(date);
        tlrInfo.setDataCrtTime(time);
        tlrInfo.setTotPswdErrCnt(BigDecimal.ZERO);
        tlrInfo.setPswdErrCnt(BigDecimal.ZERO);
        tlrInfo.setPasswdEnc("bcrypt");
        tlrInfo.setRoleId(user.getRole());
        String password = RandomHelper.randomAlnum(64);
        tlrInfo.setPassword(this.bCryptPasswordEncoder.encode(password));
        this.tlrRepository.save(tlrInfo);
        this.saveRoles(tlrInfo, roles);
    }

    @InTransaction
    public void updateSession(String dataId, String sessionId, String loginIp, String lastAccessTime) {
        GpBmTlrInfo tlrInfo = this.tlrRepository.findOne(dataId);
        tlrInfo.setSessionId(sessionId);
        tlrInfo.setLoginIp(loginIp);
        tlrInfo.setLastAccessTime(lastAccessTime);
        this.tlrRepository.save(tlrInfo);
    }

    @InTransaction
    void saveRoles(GpBmTlrInfo tlrInfo, List<GpBmRoleInfo> roles) {
        String roleId = tlrInfo.getRoleId();
        List<GpBmBusinessLine> bmBusinessLines = null;
        if (roleId.contains("-IT-")) {
            bmBusinessLines = businessLineRepository.findAll();
        }
        for (GpBmRoleInfo role : roles) {
            if (bmBusinessLines == null) {
                if (StringUtils.isNotEmpty(tlrInfo.getRoleId())) {
                    String groupId = tlrInfo.getRoleId().substring(0, tlrInfo.getRoleId().lastIndexOf('-'));
                    GpBmTlrRoleBizRel tlrRoleRel = new GpBmTlrRoleBizRel();
                    tlrRoleRel.setDataId(UuidHelper.randomCleanUpper());
                    tlrRoleRel.setCorpId(tlrInfo.getCorpId());
                    tlrRoleRel.setRoleId(role.getRoleId());
                    tlrRoleRel.setTlrno(tlrInfo.getTlrno());
                    tlrRoleRel.setStatus("1");
                    tlrRoleRel.setNextAction("99");
                    tlrRoleRel.setDataStatus("04");
                    tlrRoleRel.setBusinessLine(groupId);
                    this.roleRelRepository.save(tlrRoleRel);
                }
            } else {
                for (GpBmBusinessLine bmBusinessLine : bmBusinessLines) {
                    GpBmTlrRoleBizRel tlrRoleRel = new GpBmTlrRoleBizRel();
                    tlrRoleRel.setDataId(UuidHelper.randomCleanUpper());
                    tlrRoleRel.setCorpId(tlrInfo.getCorpId());
                    tlrRoleRel.setRoleId(role.getRoleId());
                    tlrRoleRel.setTlrno(tlrInfo.getTlrno());
                    tlrRoleRel.setStatus("1");
                    tlrRoleRel.setNextAction("99");
                    tlrRoleRel.setDataStatus("04");
                    tlrRoleRel.setBusinessLine(bmBusinessLine.getBusinessLine());
                    this.roleRelRepository.save(tlrRoleRel);
                }
            }
        }
    }
}
