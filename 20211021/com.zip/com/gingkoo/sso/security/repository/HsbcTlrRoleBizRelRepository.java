package com.gingkoo.sso.security.repository;

import com.gingkoo.gpms.privilege.entity.GpBmTlrRoleBizRel;
import com.gingkoo.root.facility.spring.data.jpa.JpaDslRepository;

public interface HsbcTlrRoleBizRelRepository extends JpaDslRepository<GpBmTlrRoleBizRel, String> {
    int deleteByTlrno(String tlrno);
}
