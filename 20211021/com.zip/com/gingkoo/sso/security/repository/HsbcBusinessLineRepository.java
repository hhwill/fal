package com.gingkoo.sso.security.repository;

import org.springframework.stereotype.Repository;

import com.gingkoo.gpms.privilege.entity.GpBmBusinessLine;
import com.gingkoo.root.facility.spring.data.jpa.JpaDslRepository;

@Repository
public interface HsbcBusinessLineRepository extends JpaDslRepository<GpBmBusinessLine, String> {
    GpBmBusinessLine getFirstByBusinessLine(String businessLine);
}
