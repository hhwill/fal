package com.gingkoo.sso.security.repository;

import org.springframework.stereotype.Repository;

import com.gingkoo.gf4j2.framework.entity.GpBmBranch;
import com.gingkoo.root.facility.spring.data.jpa.JpaDslRepository;

@Repository
public interface HsbcBranchRepository extends JpaDslRepository<GpBmBranch, String> {
    GpBmBranch getFirstByBrno(String brno);
}
