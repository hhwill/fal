package com.gingkoo.sso.security.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Data
@Component
public class HsbcProperties {
    @Value("${sso.enabled:false}")
    private boolean enabled;

    @Value("${sso.entity.id:}")
    private String entityId;

    @Value("${sso.destination.url:}")
    private String destinationUrl;

    @Value("${sso.consumer.service.url:}")
    private String consumerServiceUrl;
}
