package com.gingkoo.sso.controller;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;

import lombok.extern.slf4j.Slf4j;
import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.io.MarshallingException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gingkoo.sso.security.service.HsbcUserService;

@Slf4j
@Controller
@RequestMapping("/")
public class SsoController {

    private final HsbcUserService hsbcUserService;

    public SsoController(HsbcUserService hsbcUserService) {
        this.hsbcUserService = hsbcUserService;
    }

    @GetMapping("createSamlRequestUrl")
    public ResponseEntity<String> createSamlRequestURL()
            throws ConfigurationException, MarshallingException, IOException {
        String samlRequestURL = hsbcUserService.createSamlRequestURL();
        return new ResponseEntity<>(samlRequestURL, HttpStatus.OK);
    }

    @GetMapping("ssoLoginPage")
    public String getSsoLoginPage(HttpServletRequest request) {
        String samlRequestURL;
        try {
            samlRequestURL = hsbcUserService.createSamlRequestURL();
        } catch (ConfigurationException | MarshallingException | IOException e) {
            log.error(e.getMessage(), e);
            request.setAttribute("errormsg", e.getMessage());
            return "common/error";
        }
        return "redirect:" + samlRequestURL;
    }

    @GetMapping("ssoErrorPage")
    public String getSsoErrorPage(HttpServletRequest request) {
        request.setAttribute("errormsg", "IMAS用户验证失败");
        return "common/error";
    }

}
