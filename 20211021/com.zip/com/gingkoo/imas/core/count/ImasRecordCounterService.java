package com.gingkoo.imas.core.count;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.google.common.base.Joiner;
import com.google.common.collect.HashBiMap;
import com.google.common.collect.ImmutableMap;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.gingkoo.data.compute.api.ComputeEngine;
import com.gingkoo.data.compute.api.bean.Result;
import com.gingkoo.gf4j2.core.util.UuidHelper;
import com.gingkoo.gf4j2.framework.dao.sql.HibernateSqlRunner;
import com.gingkoo.gf4j2.framework.entity.GpBmBranch;
import com.gingkoo.gf4j2.framework.entity.base.EntityProxy;
import com.gingkoo.gpms.message.service.GNOService;
import com.gingkoo.gpms.platform.task.TaskContext;
import com.gingkoo.gpms.platform.task.TaskManager;
import com.gingkoo.imas.core.bean.ImasRecordCountContext;
import com.gingkoo.imas.core.bean.ImasRecordCountResult;
import com.gingkoo.imas.core.bean.ImasRecordReviseContext;
import com.gingkoo.imas.core.config.ImasSysConfigService;
import com.gingkoo.imas.core.dbsharding.ImasDbShardingService;
import com.gingkoo.imas.core.event.ImasRecordAfterReviseEvent;
import com.gingkoo.imas.core.privilege.ImasAuthManagerHelper;
import com.gingkoo.orm.entity.ImasBmRecordCount;
import com.gingkoo.orm.entity.ImasBmRptCfg;
import com.gingkoo.orm.entity.ImasBmTodoTask;
import com.gingkoo.orm.repository.ImasBmRecordCountRepository;
import com.gingkoo.orm.repository.ImasBmRptCfgRepository;
import com.gingkoo.orm.repository.ImasBmTodoTaskRepository;
import com.gingkoo.rdms.base.data.maintenance.bean.ResourceTemplateInstance;
import com.gingkoo.rdms.base.data.maintenance.enums.CheckFlagEnum;
import com.gingkoo.rdms.base.data.maintenance.enums.OprMode;
import com.gingkoo.rdms.base.data.maintenance.enums.TodoTaskActionEnum;
import com.gingkoo.root.annotation.Languages.SQL;
import com.gingkoo.root.annotation.NonNull;
import com.gingkoo.root.annotation.Nullable;
import com.gingkoo.root.facility.bytecode.StubHelper;
import com.gingkoo.root.facility.database.sql.SqlFragment;
import com.gingkoo.root.facility.database.sql.SqlHelper;
import com.gingkoo.root.facility.datetime.DateHelper;
import com.gingkoo.root.facility.lang.EnumHelper;
import com.gingkoo.root.facility.spring.tx.AfterCommitExecutor;

import static java.time.temporal.ChronoUnit.MILLIS;
import static org.springframework.core.Ordered.LOWEST_PRECEDENCE;

import static com.gingkoo.root.facility.datetime.DateConstants.SIMPLE_DATE;
import static com.gingkoo.root.facility.datetime.DateConstants.SIMPLE_DATE_TIME;

/**
 * 明细统计
 *
 * @author kane
 */
@Slf4j
@Component
@Order(LOWEST_PRECEDENCE - 10000)
public class ImasRecordCounterService implements ApplicationListener<ImasRecordAfterReviseEvent> {
    @SQL
    private static final String FETCH_REPORT_SUB_TASKS
            = "select * from IMAS_BM_TODO_TASK where REPORT_DATE = :dataRptDate and REPORT_CODE = :reportCode and TASK_TYPE = '1'";
    @SQL
    private static final String BUSINESS_LINE_SQL_TPL =
            "select         '%s'                                         DATA_RPT_DATE, " +
                    "       '%s'                                         ORG_ID, " +
                    "       '%s'                                         GROUP_ID, " +
                    "       '3'                                          COUNT_LEVEL, " +
                    "       '%s'                                         REF_ID, " +
                    "       min(NEXT_ACTION)                             NEXT_ACTION, " +
                    "       count(case NEXT_ACTION when '00' then 1 end) REVISE_NUM, " +
                    "       count(case NEXT_ACTION when '10' then 1 end) REVIEW_NUM, " +
                    "       count(case NEXT_ACTION when '20' then 1 end) APPROVE_NUM, " +
                    "       count(case NEXT_ACTION when '30' then 1 end) APPROVED_NUM, " +
                    "       count(case when CHECK_FLAG='F' and NEXT_ACTION = '30' then 1 end) UNCHECK_NUM, " +
                    "       count(case CHECK_FLAG when 'M' then 1 end)   CHECKING_NUM, " +
                    "       count(case CHECK_FLAG when 'Y' then 1 end)   CHECK_SUCCESS_NUM, " +
                    "       count(case CHECK_FLAG when 'F' then 1 end)   CHECK_FAILED_NUM, " +
                    "       count(case when DATA_RPT_FLAG != 'O' then 1 end) REPORT_NUM, " +
                    "       count(1)                                     RECORD_NUM, " +
                    "       min(case when DATA_RPT_FLAG = 'O' then 4 when CHECK_FLAG is null then 2 when NEXT_ACTION = '00' and CHECK_FLAG = 'M' then 1 when NEXT_ACTION = '00' and CHECK_FLAG = 'N' then 2 when NEXT_ACTION = '00' and CHECK_FLAG = 'F' then 3 when NEXT_ACTION = '00' and CHECK_FLAG = 'Y' then 4 end) REVISE_CHECK_FLAG, " +
                    "       min(case when DATA_RPT_FLAG = 'O' then 4 when CHECK_FLAG is null then 2 when NEXT_ACTION = '20' and CHECK_FLAG = 'M' then 1 when NEXT_ACTION = '20' and CHECK_FLAG = 'N' then 2 when NEXT_ACTION = '20' and CHECK_FLAG = 'F' then 3 when NEXT_ACTION = '20' and CHECK_FLAG = 'Y' then 4 end) APPROVE_CHECK_FLAG, " +
                    "       min(case when DATA_RPT_FLAG = 'O' then 4 when CHECK_FLAG is null then 2 when NEXT_ACTION = '30' and CHECK_FLAG = 'M' then 1 when NEXT_ACTION = '30' and CHECK_FLAG = 'N' then 2 when NEXT_ACTION = '30' and CHECK_FLAG = 'F' then 3 when NEXT_ACTION = '30' and CHECK_FLAG = 'Y' then 4 end) APPROVED_CHECK_FLAG, " +
                    "       min(case when DATA_RPT_FLAG = 'O' then 4 when CHECK_FLAG is null then 2 when CHECK_FLAG = 'M' then 1 when CHECK_FLAG = 'N' then 2 when CHECK_FLAG = 'F' then 3 when CHECK_FLAG = 'Y' then 4 end) CHECK_FLAG " +
                    "from ( " +
                    "         select a.DATA_ID, " +
                    "                a.DATA_RPT_DATE, " +
                    "                a.ORG_ID, " +
                    "                a.DATA_RPT_FLAG, " +
                    "                case when b.GROUP_ID is null then a.GROUP_ID else b.GROUP_ID end       GROUP_ID, " +
                    "                case when b.GROUP_ID is null then a.NEXT_ACTION else b.NEXT_ACTION end NEXT_ACTION, " +
                    "                case when b.GROUP_ID is null then a.CHECK_FLAG else b.CHECK_FLAG end   CHECK_FLAG " +
                    "         from %s a " +
                    "                  left join IMAS_BM_RECORD_SUB_STATUS b on a.DATA_ID = b.REF_DATA_ID " +
                    "         where a.DATA_RPT_DATE = :dataRptDate" +
                    "     ) t " +
                    "where %s and NEXT_ACTION != '99' " +
                    "  %s ";

    @SQL
    private static final String ORG_ID_SQL_TPL =
            "select DATA_RPT_DATE, " +
                    "       ORG_ID, " +
                    "       '2'                                          COUNT_LEVEL, " +
                    "       min(NEXT_ACTION)                             NEXT_ACTION, " +
                    "       count(case NEXT_ACTION when '00' then 1 end) REVISE_NUM, " +
                    "       count(case NEXT_ACTION when '10' then 1 end) REVIEW_NUM, " +
                    "       count(case NEXT_ACTION when '20' then 1 end) APPROVE_NUM, " +
                    "       count(case NEXT_ACTION when '30' then 1 end) APPROVED_NUM, " +
                    "       count(case when CHECK_FLAG='F' and NEXT_ACTION = '30' then 1 end)   UNCHECK_NUM, " +
                    "       count(case CHECK_FLAG when 'M' then 1 end)   CHECKING_NUM, " +
                    "       count(case CHECK_FLAG when 'Y' then 1 end)   CHECK_SUCCESS_NUM, " +
                    "       count(case CHECK_FLAG when 'F' then 1 end)   CHECK_FAILED_NUM, " +
                    "       count(case when DATA_RPT_FLAG != 'O' then 1 end) REPORT_NUM, " +
                    "       count(1)                                     RECORD_NUM, " +
                    "       min(case when DATA_RPT_FLAG = 'O' then 4 when CHECK_FLAG is null then 2 when NEXT_ACTION = '00' and CHECK_FLAG = 'M' then 1 when NEXT_ACTION = '00' and CHECK_FLAG = 'N' then 2 when NEXT_ACTION = '00' and CHECK_FLAG = 'F' then 3 when NEXT_ACTION = '00' and CHECK_FLAG = 'Y' then 4 end) REVISE_CHECK_FLAG, " +
                    "       min(case when DATA_RPT_FLAG = 'O' then 4 when CHECK_FLAG is null then 2 when NEXT_ACTION = '20' and CHECK_FLAG = 'M' then 1 when NEXT_ACTION = '20' and CHECK_FLAG = 'N' then 2 when NEXT_ACTION = '20' and CHECK_FLAG = 'F' then 3 when NEXT_ACTION = '20' and CHECK_FLAG = 'Y' then 4 end) APPROVE_CHECK_FLAG, " +
                    "       min(case when DATA_RPT_FLAG = 'O' then 4 when CHECK_FLAG is null then 2 when NEXT_ACTION = '30' and CHECK_FLAG = 'M' then 1 when NEXT_ACTION = '30' and CHECK_FLAG = 'N' then 2 when NEXT_ACTION = '30' and CHECK_FLAG = 'F' then 3 when NEXT_ACTION = '30' and CHECK_FLAG = 'Y' then 4 end) APPROVED_CHECK_FLAG, " +
                    "       min(case when DATA_RPT_FLAG = 'O' then 4 when CHECK_FLAG is null then 2 when CHECK_FLAG = 'M' then 1 when CHECK_FLAG = 'N' then 2 when CHECK_FLAG = 'F' then 3 when CHECK_FLAG = 'Y' then 4 end) CHECK_FLAG  " +
                    " from ( " +
                    "         select a.DATA_ID, " +
                    "                a.DATA_RPT_DATE, " +
                    "                a.ORG_ID, " +
                    "                a.DATA_RPT_FLAG, " +
                    "                case when b.GROUP_ID is null then a.NEXT_ACTION else b.NEXT_ACTION end NEXT_ACTION, " +
                    "                case when b.GROUP_ID is null then a.CHECK_FLAG else b.CHECK_FLAG end   CHECK_FLAG " +
                    "         from %s a " +
                    "                  left join IMAS_BM_RECORD_SUB_STATUS b on a.DATA_ID = b.REF_DATA_ID " +
                    "         where a.DATA_RPT_DATE = :dataRptDate and a.NEXT_ACTION != '99'" +
                    "     ) t " +
                    "group by DATA_RPT_DATE, ORG_ID";

    @SQL
    private static final String RPT_ORG_SQL_TPL =
            "select         '%s'                     DATA_RPT_DATE, " +
                    "       '%s'                   ORG_ID, " +
                    "       '1'                    COUNT_LEVEL, " +
                    "       min(NEXT_ACTION)       NEXT_ACTION, " +
                    "       sum(REVISE_NUM)        REVISE_NUM, " +
                    "       sum(REVIEW_NUM)        REVIEW_NUM, " +
                    "       sum(APPROVE_NUM)       APPROVE_NUM, " +
                    "       sum(APPROVED_NUM)      APPROVED_NUM, " +
                    "       sum(UNCHECK_NUM)       UNCHECK_NUM, " +
                    "       sum(CHECKING_NUM)      CHECKING_NUM, " +
                    "       sum(CHECK_SUCCESS_NUM) CHECK_SUCCESS_NUM, " +
                    "       sum(CHECK_FAILED_NUM)  CHECK_FAILED_NUM, " +
                    "       sum(RECORD_NUM)        RECORD_NUM, " +
                    "       sum(REPORT_NUM)        REPORT_NUM, " +
                    "       min(case REVISE_CHECK_FLAG when null then 2 when 'M' then 1 when 'N' then 2 when 'F' then 3 when 'Y' then 4 end) REVISE_CHECK_FLAG, " +
                    "       min(case APPROVE_CHECK_FLAG when null then 2 when 'M' then 1 when 'N' then 2 when 'F' then 3 when 'Y' then 4 end) APPROVE_CHECK_FLAG, " +
                    "       min(case APPROVED_CHECK_FLAG when null then 2 when 'M' then 1 when 'N' then 2 when 'F' then 3 when 'Y' then 4 end) APPROVED_CHECK_FLAG, " +
                    "       min(case CHECK_FLAG when null then 2 when 'M' then 1 when 'N' then 2 when 'F' then 3 when 'Y' then 4 end) CHECK_FLAG " +
                    "from IMAS_BM_RECORD_COUNT " +
                    "where DATA_RPT_DATE = :dataRptDate " +
                    "  and ORG_ID in (select ORG_ID from IMAS_BM_TODO_TASK where P_TASK_ID = :pTaskId) " +
                    "  and REPORT_CODE = :reportCode" +
                    "  and COUNT_LEVEL = '2'";

    @SQL
    private static final String UPDATE_TASK_SQL =
            "UPDATE IMAS_BM_TODO_TASK " +
                    "SET NEXT_ACTION  = :nextAction, " +
                    "    CHECK_STATUS = :checkFlag, " +
                    "    CHECK_FLAG   = :checkFlag, " +
                    "    TASK_STATUS  = :nextAction " +
                    "WHERE TASK_ID = :taskId";

    @SQL
    private static final String UPDATE_99_TASK_SQL =
            "UPDATE IMAS_BM_TODO_TASK " +
                    "SET NEXT_ACTION  = :nextAction, " +
                    "    TASK_STATUS = :nextAction " +
                    "WHERE TASK_ID = :taskId and TASK_STATUS='99'";

    @SQL
    private static final String UPDATE_TASK_WITHOUT_STATUS_SQL =
            "UPDATE IMAS_BM_TODO_TASK " +
                    "SET CHECK_STATUS = :checkFlag, " +
                    "    CHECK_FLAG   = :checkFlag " +
                    "WHERE TASK_ID = :taskId";

    @SQL
    private static final String SUB_TASK_SUMMARY_SQL =
            "select P_TASK_ID, " +
                    "       sum(case when CHECK_FLAG = 'Y' then 0 else 1 end)   CHECK_FLAG, " +
                    "       sum(case when TASK_STATUS = '30' then 0 else 1 end) TASK_STATUS, " +
                    "       min(TASK_STATUS) MIN_TASK_STATUS " +
                    "from IMAS_BM_TODO_TASK " +
                    "where P_TASK_ID = (select P_TASK_ID from IMAS_BM_TODO_TASK where TASK_ID = :taskId) " +
                    "group by P_TASK_ID";

    @SQL
    private static final String DEL_LEVEL_1_SQL_TPL
            = "delete from IMAS_BM_RECORD_COUNT where DATA_RPT_DATE = :dataRptDate AND REPORT_CODE = :reportCode and ORG_ID = :orgId and COUNT_LEVEL = '1'";
    @SQL
    private static final String DEL_LEVEL_2_SQL_TPL =
            "delete from IMAS_BM_RECORD_COUNT where DATA_RPT_DATE = :dataRptDate AND REPORT_CODE = :reportCode and ORG_ID = :orgId and COUNT_LEVEL = '2'";
    @SQL
    private static final String DEL_LEVEL_3_SQL_TPL
            = "delete from IMAS_BM_RECORD_COUNT where DATA_RPT_DATE = :dataRptDate and REPORT_CODE = :reportCode and ORG_ID = :orgId and GROUP_ID = :groupId and COUNT_LEVEL = '3'";
    @SQL
    private static final String NOT_COMPLETE_MAIN_TASK_COUNT
            = "select count(1) from IMAS_BM_TODO_TASK where REPORT_DATE = :dataRptDate and TASK_TYPE = '0' and TASK_STATUS != '30'";


    private static final Map<String, Integer> CHECK_FLAG_NUMBER = ImmutableMap.of("M", 1, "N", 2, "F", 3, "Y", 4);
    private static final Map<Integer, String> NUMBER_CHECK_FLAG = HashBiMap.create(CHECK_FLAG_NUMBER).inverse();


    private final Cache<String, String> NOTICE_CACHE = Caffeine.newBuilder()
            .expireAfterWrite(10, TimeUnit.MINUTES)
            .build();

    private final ImasDbShardingService shardingService;
    private final ImasBmRecordCountRepository recordCountRepository;
    private final HibernateSqlRunner sqlRunner;
    private final TaskManager taskManager;
    private final ImasBmTodoTaskRepository todoTaskRepository;
    private final ImasAuthManagerHelper authManagerHelper;
    private final GNOService gnoService;
    private final AfterCommitExecutor afterCommitExecutor;
    private final ImasBmRptCfgRepository imasBmRptCfgRepository;
    private final ImasSysConfigService sysConfigService;

    @Autowired
    protected ComputeEngine computeEngine = StubHelper.stub(ComputeEngine.class);

    public ImasRecordCounterService(ImasDbShardingService shardingService,
                                    ImasBmRecordCountRepository recordCountRepository,
                                    HibernateSqlRunner sqlRunner,
                                    TaskManager taskManager,
                                    ImasBmTodoTaskRepository todoTaskRepository,
                                    ImasAuthManagerHelper authManagerHelper, GNOService gnoService,
                                    AfterCommitExecutor afterCommitExecutor, ImasBmRptCfgRepository imasBmRptCfgRepository, ImasSysConfigService sysConfigService) {
        this.shardingService = shardingService;
        this.recordCountRepository = recordCountRepository;
        this.sqlRunner = sqlRunner;
        this.taskManager = taskManager;
        this.todoTaskRepository = todoTaskRepository;
        this.authManagerHelper = authManagerHelper;
        this.gnoService = gnoService;
        this.afterCommitExecutor = afterCommitExecutor;
        this.imasBmRptCfgRepository = imasBmRptCfgRepository;
        this.sysConfigService = sysConfigService;
    }

    public void countByReport(@NonNull String dataRptDate, @NonNull String reportCode,
                              @Nullable String orgIdParam, @Nullable String groupIdParam, String triggerId) {
        countByReport(dataRptDate, reportCode, orgIdParam, groupIdParam, false, triggerId);
    }

    /**
     * 后台统计
     */
    public void countByReport(@NonNull String dataRptDate, @NonNull String reportCode,
                              @Nullable String orgIdParam, @Nullable String groupIdParam, boolean updateTaskStatus, String triggerId) {
        countByReport(dataRptDate, reportCode, orgIdParam, groupIdParam, false, null, updateTaskStatus, triggerId);
    }

    /**
     * 计划任务调用方法  ImasBmRptCfgRepository
     */
    public void countByReportJob(String rptDate) {
        // 日期为空，默认执行上一天的
        countByReportJob(rptDate, sysConfigService.productOprMode() == OprMode.RCD);
    }

    public void countByReportJob(String rptDate, boolean updateTaskStatus) {
        // 日期为空，默认执行上一天的
        if (StringUtils.isBlank(rptDate)) {
            rptDate = LocalDateTime.now().minusDays(1).format(SIMPLE_DATE);
        }
        List<ImasBmRptCfg> list = imasBmRptCfgRepository.findAll();

        for (ImasBmRptCfg cfg : list) {
            countByReport(rptDate, cfg.getReportCode(), null, null, false, null, updateTaskStatus, "JOB");
        }
    }

    /**
     * @param dataRptDate  报表日期
     * @param reportCode   报表编码
     * @param orgIdParam   orgId，可以多个，用英文逗号分隔
     * @param groupIdParam groupId，可以多个，用英文逗号分隔
     * @param isEmptyOpr   是否为空操作，补录事件触发的统计需要此值，做特殊处理
     * @param oprTaskId    操作任务ID，补录事件触发的统计由于要统计关联的多个任务，
     *                     因此这里要做个标识，便于做特殊处理（例如区分空记录怎么更新统计结果）
     * @param triggerId    触发者
     */
    public void countByReport(@NonNull String dataRptDate, @NonNull String reportCode,
                              @Nullable String orgIdParam, @Nullable String groupIdParam,
                              boolean isEmptyOpr, @Nullable String oprTaskId, boolean updateTaskStatus, String triggerId) {
        log.info("count with dataRptDate[{}] reportCode[{}] orgIdParam[{}] groupIdParam[{}] isEmptyOpr[{}] oprTaskId[{}] updateTaskStatus[{}]",
                dataRptDate, reportCode, orgIdParam, groupIdParam, isEmptyOpr, oprTaskId, updateTaskStatus);
        Map<String, Object> sqlParams = new HashMap<>();
        sqlParams.put("dataRptDate", dataRptDate);
        sqlParams.put("reportCode", reportCode);
        // 后台统计 和 任务之间数据有重叠的情况下 需要进行关联统计，而不是只统计一个任务
        @SQL
        String fetchReportSubTasks = FETCH_REPORT_SUB_TASKS;
        if (StringUtils.isNotBlank(orgIdParam)) {
            SqlFragment sqlFragment = SqlHelper.toSqlFragment(orgIdParam);
            fetchReportSubTasks += String.format(" AND ORG_ID IN (%s) ", sqlFragment.getFragment());
            sqlParams.putAll(sqlFragment.getParameters());
        }
        if (StringUtils.isNotBlank(groupIdParam)) {
            SqlFragment sqlFragment = SqlHelper.toSqlFragment(groupIdParam);
            fetchReportSubTasks += String.format(" AND GROUP_ID IN (%s) ", sqlFragment.getFragment());
            sqlParams.putAll(sqlFragment.getParameters());
        }
        List<Map<String, Object>> subTasks = sqlRunner.queryForList(fetchReportSubTasks, sqlParams);
        for (Map<String, Object> subTask : subTasks) {
            // 按照任务进行统计
            String groupId = Objects.toString(subTask.get("GROUP_ID"), "");
            String orgId = Objects.toString(subTask.get("ORG_ID"), "");
            ImasRecordCountContext level3Context = ImasRecordCountContext.builder()
                    .oprMode(sysConfigService.productOprMode())
                    .isEmptyOpr(isEmptyOpr)
                    .dataRptDate(dataRptDate)
                    .reportCode(reportCode)
                    .targetOrgId(orgId)
                    .targetGroupId(groupId)
                    .oprTime(DateHelper.now())
                    .taskId(subTask.get("TASK_ID").toString())
                    .oprTaskId(oprTaskId)
                    .build();
            TaskContext level3TaskContext = taskManager.createTaskContext("明细记录批量统计-" + reportCode + "-" + orgId + "-" + groupId + "-3").build();
            level3TaskContext.go((ctx) -> {
                countLevel3(level3Context, updateTaskStatus);
                Map<String, String> param = new HashMap<>();
                param.put("DATA_RPT_DATE", dataRptDate);
                param.put("REPORT_CODE", reportCode);
                param.put("ORG_ID", orgId);
                param.put("GROUP_ID", groupId);
                param.put("TRIGGER_ID", triggerId);
                try {
                    Result currentDateResult = computeEngine.call("imas.count.after.Level3", param);
                    if (currentDateResult.isOk()) {
                        log.info("imas.count.after.Level3 success with param {} result {}", param, currentDateResult);
                    } else {
                        log.info("imas.count.after.Level3 failed with param {} result {}", param, currentDateResult);
                    }
                } catch (Exception e) {
                    log.info("imas.count.after.Level3 error with param {}" + e.getMessage(), param);
                }
                return "ok";
            });
        }

        ImasRecordCountContext level1And2Context = ImasRecordCountContext.builder()
                .oprMode(sysConfigService.productOprMode())
                .isEmptyOpr(isEmptyOpr)
                .dataRptDate(dataRptDate)
                .reportCode(reportCode)
                .oprTime(DateHelper.now())
                .build();
        TaskContext level1And2TaskContext = taskManager.createTaskContext("明细记录批量统计-" + reportCode + "-1&2").build();
        level1And2TaskContext.go((ctx) -> {
            countLevel1And2(level1And2Context);
            return "ok";
        });

    }

    @Override
    public void onApplicationEvent(ImasRecordAfterReviseEvent imasRecordAfterReviseEvent) {
        ImasRecordReviseContext context = imasRecordAfterReviseEvent.getContext();
        afterCommitExecutor.execute(() -> countByReviseOpr(context));
    }

    /**
     * 补录事件触发统计
     */
    public void countByReviseOpr(ImasRecordReviseContext context) {
        List<String> oprOrgs = authManagerHelper.getUserOprOrgIdsWithoutSub(context.getUserId());
        List<String> groupIds = authManagerHelper.getUserGroups(context.getUserId());
        countByReport(context.getDataRptDate(), context.getReportCode(),
                String.join(",", oprOrgs), String.join(",", groupIds),
                context.isEmptyOpr(), context.getTaskId(), true, "REVISE");
    }

    public void countLevel3(ImasRecordCountContext context, boolean updateTaskStatus) {
        log.debug("[{}]count level 3 start with context[{}]", logId(context), context);
        LocalDateTime startTime = DateHelper.now();
        String orgId = context.getTargetOrgId();
        if (StringUtils.isBlank(orgId)) {
            log.info("[{}]orgId id is null", logId(context));
            return;
        }
        String groupId = context.getTargetGroupId();
        if (StringUtils.isBlank(groupId)) {
            log.info("[{}]group id is null", logId(context));
            return;
        }
        String dataRptDate = context.getDataRptDate();
        String reportCode = context.getReportCode();

        Map<String, Object> sqlParams = new HashMap<>();
        sqlParams.put("dataRptDate", dataRptDate);
        sqlParams.put("reportCode", reportCode);
        sqlParams.put("orgId", orgId);
        String groupIdCond = " AND " + authManagerHelper.sqlPrivilege(reportCode, groupId);
        String tableName = shardingService.shardingTableName("IMAS_PM_" + reportCode, dataRptDate);
        /*
         * 统计结果
         * 1.当有明细数据的时候统计出的结果是正常的
         * 2.当无明细数据的时候统计的数据状态和校验标识为null
         * */
        ImasRecordCountResult result = countByBusinessLine(context, orgId, groupId, tableName, groupIdCond, sqlParams);
        ImasBmRecordCount recordCount = insertCount(result);
        if (recordCount == null || StringUtils.isBlank(recordCount.getRefId())) {
            log.warn("[{}] not save count", logId(context));
            return;
        }
        String taskId = recordCount.getRefId();
        log.debug("[{}] sync todo sub task id[{}]", logId(context), taskId);
        if(updateTaskStatus){
            // 判断是否同步的时候更新任务的状态，因为业务线模式下面明细上面是没有状态的 所以这时候拿明细的最小状态更新任务状态会出问题
            if (sysConfigService.productOprMode() == OprMode.BIZ) {
                log.info("biz count update taskId[{}] check flag to [{}]", taskId, recordCount.getCheckFlag());
                // 业务线模式不更新状态
                sqlRunner.update(UPDATE_TASK_WITHOUT_STATUS_SQL,
                        ImmutableMap.of("checkFlag", recordCount.getCheckFlag(), "taskId", taskId));
                log.info("biz count update taskId[{}] task status to [{}] where task_status is 99", taskId, recordCount.getNextAction());
                sqlRunner.update(UPDATE_99_TASK_SQL,
                        ImmutableMap.of("nextAction", recordCount.getNextAction(), "taskId", taskId));
            } else {
                log.info("rcd count update taskId[{}] status to [{}] check flag to [{}]", taskId, recordCount.getNextAction(), recordCount.getCheckFlag());
                sqlRunner.update(UPDATE_TASK_SQL,
                        ImmutableMap.of("nextAction", recordCount.getNextAction(), "checkFlag", recordCount.getCheckFlag(), "taskId", taskId));
            }
        }else{
            log.info("count update taskId[{}] check flag to [{}] without update status", taskId, recordCount.getCheckFlag());
            sqlRunner.update(UPDATE_TASK_WITHOUT_STATUS_SQL,
                    ImmutableMap.of("checkFlag", recordCount.getCheckFlag(), "taskId", taskId));
        }
        // 同步 todo_task 主任务状态
        List<Map<String, Object>> mainTaskInfoList = sqlRunner.queryForList(SUB_TASK_SUMMARY_SQL, ImmutableMap.of("taskId", taskId));
        if (!CollectionUtils.isEmpty(mainTaskInfoList)) {
            Map<String, Object> mainTaskInfo = mainTaskInfoList.get(0);
            String mainTaskId = mainTaskInfo.get("P_TASK_ID").toString();
            String checkFlag = "0".equals(mainTaskInfo.get("CHECK_FLAG")) ? "Y" : "N";
            String taskStatus = Objects.toString(mainTaskInfo.get("MIN_TASK_STATUS"), "00");
            log.debug("[{}] sync todo main task id[{}] check flag[{}] task status[{}]", logId(context), mainTaskId, checkFlag, taskStatus);
            sqlRunner.update(UPDATE_TASK_SQL,
                    ImmutableMap.of("nextAction", taskStatus, "checkFlag", checkFlag, "taskId", mainTaskId));
        }

        // 是否所有任务都已完成
        long notCompleteNum = sqlRunner.queryForLong(NOT_COMPLETE_MAIN_TASK_COUNT, ImmutableMap.of("dataRptDate", dataRptDate));
        if (notCompleteNum == 0) {
            String topicId = "ALL_REPORT_PROCESS_COMPLETE";
            synchronized (this) {
                if (NOTICE_CACHE.getIfPresent(topicId + dataRptDate) == null) {
                    NOTICE_CACHE.put(topicId + dataRptDate, dataRptDate);
                    log.debug("[{}] all report process complete send mail", logId(context));
                    gnoService.sendMessageImmediate(topicId, ImmutableMap.of("dataRptDate", dataRptDate));
                } else {
                    log.debug("[{}] all report process complete, mail has been sent, not sent again!", logId(context));
                }
            }

        }
        LocalDateTime endTime = DateHelper.now();
        log.debug("[{}]count level 3 end spend [{}ms]", logId(context), startTime.until(endTime, MILLIS));
    }

    public void countLevel1And2(ImasRecordCountContext context) {
        log.debug("[{}]count level 1&2 start with context[{}]", logId(context), context);
        LocalDateTime startTime = DateHelper.now();
        String dataRptDate = context.getDataRptDate();
        String reportCode = context.getReportCode();
        Map<String, Object> sqlParams = new HashMap<>();
        sqlParams.put("dataRptDate", dataRptDate);
        sqlParams.put("reportCode", reportCode);
        String tableName = shardingService.shardingTableName("IMAS_PM_" + reportCode, dataRptDate);
        for(ImasRecordCountResult countResult : countByOrgId(context, tableName, sqlParams)){
            insertCount(countResult);
        }

        for (ImasRecordCountResult countResult : countByRptOrg(context, dataRptDate, reportCode)) {
            insertCount(countResult);
        }
        LocalDateTime endTime = DateHelper.now();
        log.debug("[{}]count level 1&2 end spend [{}ms]", logId(context), startTime.until(endTime, MILLIS));
    }

    @Nullable
    public synchronized ImasBmRecordCount insertCount(ImasRecordCountResult countResult) {
        ImasRecordCountContext context = countResult.getContext();
        Map<String, Object> countRow = countResult.getData();
        if (countRow == null) {
            return null;
        }
        ImasBmRecordCount recordCount = new ImasBmRecordCount();
        recordCount = EntityProxy.of(recordCount).setDataId(UuidHelper.getCleanUuid()).addCreateFootprint("sys", new Date()).getEntity();
        recordCount.fromMap(countRow);
        recordCount.setReportCode(context.getReportCode());
        recordCount.setReportName("");
        String orgId = recordCount.getOrgId();
        String groupId = recordCount.getGroupId();
        String dataRptDate = recordCount.getDataRptDate();
        String reportCode = recordCount.getReportCode();
        String countLevel = recordCount.getCountLevel();
        String taskId = recordCount.getRefId();
        LocalDateTime currCountTime = countResult.getStartTime();
        if ("1".equals(countLevel)) {
            List<ImasBmRecordCount> level1 = recordCountRepository.findLevel1(dataRptDate, orgId, reportCode);
            if (!CollectionUtils.isEmpty(level1) && SIMPLE_DATE_TIME.format(currCountTime).compareTo(level1.get(0).getDataCrtTime()) < 0) {
                // 已存在且统计日期大于当前统计日期 跳过当前统计信息
                log.debug("[{}] not saved count, level 1 count result skip curse of count time more later", logId(context));
                return null;
            }
            sqlRunner.update(DEL_LEVEL_1_SQL_TPL, ImmutableMap.of("dataRptDate", dataRptDate, "reportCode", reportCode, "orgId", orgId));
        } else if ("2".equals(countLevel)) {
            List<ImasBmRecordCount> level2 = recordCountRepository.findLevel2(dataRptDate, orgId, reportCode);
            if (!CollectionUtils.isEmpty(level2) && SIMPLE_DATE_TIME.format(currCountTime).compareTo(level2.get(0).getDataCrtTime()) < 0) {
                // 已存在且统计日期大于当前统计日期 跳过当前统计信息
                log.debug("[{}] not saved count, level 2 count result skip curse of count time more later", logId(context));
                return null;
            }
            sqlRunner.update(DEL_LEVEL_2_SQL_TPL, ImmutableMap.of("dataRptDate", dataRptDate, "reportCode", reportCode, "orgId", orgId));
        } else if ("3".equals(countLevel)) {
            List<ImasBmRecordCount> level3 = recordCountRepository.findLevel3(dataRptDate, orgId, groupId, reportCode);
            if (!CollectionUtils.isEmpty(level3) && SIMPLE_DATE_TIME.format(currCountTime).compareTo(level3.get(0).getDataCrtTime()) < 0) {
                // 已存在且统计日期大于当前统计日期 跳过当前统计信息
                log.debug("[{}] not saved count, level 3 count result skip curse of count time more later", logId(context));
                return null;
            }
            sqlRunner.update(DEL_LEVEL_3_SQL_TPL, ImmutableMap.of("dataRptDate", dataRptDate, "reportCode", reportCode, "orgId", orgId, "groupId", groupId));
            ImasBmTodoTask task = todoTaskRepository.findTask(context.getTaskId());
            /*
             * 1. oprTaskId != null && task.getTaskId = oprTaskId（补录页面事件触发的统计）
             * 1.1 isEmptyOpr = true 直接copy task的状态
             * 1.2 isDetailEmpty() = true 状态为更新为等待、校验标识为未校验
             * 2. isDetailEmpty() = true （后台统计或者非当前操作任务）copy task的状态，防止误更新
             * */
            String oprTaskId = countResult.getContext().getOprTaskId();
            boolean emptyOpr = countResult.getContext().isEmptyOpr();
            if (StringUtils.isNotBlank(oprTaskId) && task.getTaskId().equals(oprTaskId)) {
                if (emptyOpr) {
                    log.debug("[{}] level3 result: revise empty opr and is opr task, copy task status", logId(context));
                    recordCount.setCheckFlag(task.getCheckStatus());
                    recordCount.setTaskStatus(task.getTaskStatus());
                    recordCount.setNextAction(task.getNextAction());
                    setSubCheckStatusByTask(recordCount, task);
                } else if (isDetailEmpty(countResult)) {
                    log.debug("[{}] level3 result: not empty opr but count empty, update status to waiting ", logId(context));
                    recordCount.setCheckFlag("N");
                    recordCount.setTaskStatus("00");
                    recordCount.setNextAction("00");
                    recordCount.setReviseCheckFlag("N");
                    recordCount.setApproveCheckFlag("N");
                    recordCount.setApprovedCheckFlag("N");
                }
            } else if (isDetailEmpty(countResult)) {
                log.debug("[{}] level3 result: not revise count or not opr task, copy task status", logId(context));
                recordCount.setCheckFlag(task.getCheckStatus());
                recordCount.setTaskStatus(task.getTaskStatus());
                recordCount.setNextAction(task.getNextAction());
                setSubCheckStatusByTask(recordCount, task);
            }
        }
        recordCount.setDataCrtTime(SIMPLE_DATE_TIME.format(currCountTime));
        if (!isDetailEmpty(countResult)) {
            log.debug("[{}] level{} result: count empty, update status to waiting", logId(context), countLevel);
            recordCount.setCheckFlag(convertCheckFlag(recordCount.getCheckFlag()));
            recordCount.setReviseCheckFlag(convertCheckFlag(recordCount.getReviseCheckFlag()));
            recordCount.setApproveCheckFlag(convertCheckFlag(recordCount.getApproveCheckFlag()));
            recordCount.setApprovedCheckFlag(convertCheckFlag(recordCount.getApprovedCheckFlag()));

            if (recordCount.getNextAction() == null) {
                recordCount.setNextAction("00");
            }
        }
        recordCount.setTaskStatus(recordCount.getNextAction());
        recordCount.setRefId(taskId);
        recordCount.setRemarks(logId(context));
        recordCountRepository.save(recordCount);
        log.debug("[{}] level {} next action[{}] check flag[{}] revise number[{}]", logId(context), recordCount.getCountLevel(), recordCount.getNextAction(), recordCount.getCheckFlag(), recordCount.getReviseNum());
        return recordCount;

    }

    private ImasRecordCountResult countByBusinessLine(ImasRecordCountContext context, String orgId, String groupId, String tableName, String groupIdCond, Map<String, Object> sqlParams) {
        log.debug("[{}] count by business line", logId(context));
        ResourceTemplateInstance resTplInst = authManagerHelper.getResTplInst(groupId, context.getReportCode());
        String orgIdCond = "ORG_ID = :orgId";
        if (resTplInst != null && resTplInst.isRefSubOrg()) {
            List<String> subOrgIds = authManagerHelper.getSubOrgsByOrgId(orgId).stream().map(GpBmBranch::getBrcode).collect(Collectors.toList());
            orgIdCond = "ORG_ID in ('" + Joiner.on("','").join(subOrgIds) + "')";
        }
        @SQL
        String sql = String.format(BUSINESS_LINE_SQL_TPL, context.getDataRptDate(), orgId, groupId, context.getTaskId(), tableName, orgIdCond, groupIdCond);
        LocalDateTime startTime = DateHelper.now();
        List<Map<String, Object>> data = sqlRunner.queryForList(sql, sqlParams);
        LocalDateTime endTime = DateHelper.now();
        ImasRecordCountResult result = ImasRecordCountResult.of(context, startTime, endTime, data.get(0));
        log.debug("[{}] count by business line spend[{}ms]", logId(context), result.getSpendTime());
        return result;
    }

    private void setSubCheckStatusByTask(ImasBmRecordCount recordCount, ImasBmTodoTask task) {
        switch (Objects.requireNonNull(EnumHelper.parseCode(TodoTaskActionEnum.class, task.getNextAction()))) {
            case TASK_ACTION_REVISE:
                recordCount.setReviseCheckFlag(task.getCheckFlag());
                recordCount.setApproveCheckFlag(CheckFlagEnum.UN_CHECK.getCode());
                recordCount.setApprovedCheckFlag(CheckFlagEnum.UN_CHECK.getCode());
                break;
            case TASK_ACTION_APPROVE:
                recordCount.setReviseCheckFlag(CheckFlagEnum.UN_CHECK.getCode());
                recordCount.setApproveCheckFlag(task.getCheckFlag());
                recordCount.setApprovedCheckFlag(CheckFlagEnum.UN_CHECK.getCode());
                break;
            case TASK_ACTION_APPROVED:
                recordCount.setReviseCheckFlag(CheckFlagEnum.UN_CHECK.getCode());
                recordCount.setApproveCheckFlag(CheckFlagEnum.UN_CHECK.getCode());
                recordCount.setApprovedCheckFlag(task.getCheckFlag());
                break;
            default:
                recordCount.setReviseCheckFlag(CheckFlagEnum.UN_CHECK.getCode());
                recordCount.setApproveCheckFlag(CheckFlagEnum.UN_CHECK.getCode());
                recordCount.setApprovedCheckFlag(CheckFlagEnum.UN_CHECK.getCode());
        }
    }

    private String convertCheckFlag(@Nullable String checkFlag) {
        if (checkFlag != null) {
            if (!CHECK_FLAG_NUMBER.containsKey(checkFlag)) {
                return NUMBER_CHECK_FLAG.getOrDefault(Integer.valueOf(checkFlag), checkFlag);
            } else {
                return checkFlag;
            }
        } else {
            return CheckFlagEnum.UN_CHECK.getCode();
        }

    }

    private List<ImasRecordCountResult> countByOrgId(ImasRecordCountContext context, String tableName, Map<String, Object> sqlParams) {
        log.debug("[{}] count by org id", logId(context));
        @SQL
        String sql = String.format(ORG_ID_SQL_TPL, tableName);
        LocalDateTime startTime = DateHelper.now();
        List<Map<String, Object>> data = sqlRunner.queryForList(sql, sqlParams);
        LocalDateTime endTime = DateHelper.now();
        if (CollectionUtils.isEmpty(data)) {
            return Collections.singletonList(ImasRecordCountResult.of(context, startTime, endTime, null));
        }
        return data.stream().map(record->ImasRecordCountResult.of(context, startTime, endTime, record)).collect(Collectors.toList());
    }

    private List<ImasRecordCountResult> countByRptOrg(ImasRecordCountContext context, String dataRptDate, String reportCode) {
        log.debug("[{}] count by report org", logId(context));
        List<ImasRecordCountResult> results = new ArrayList<>();
        List<ImasBmTodoTask> mainTasks = todoTaskRepository.findMainTasks(dataRptDate, reportCode);
        for (ImasBmTodoTask mainTask : mainTasks) {
            log.debug("[{}] count by report org[{}]", logId(context), mainTask.getOrgId());
            List<ImasBmTodoTask> subTasks = todoTaskRepository.findSubTasksByPTaskId(mainTask.getTaskId());
            if (CollectionUtils.isEmpty(subTasks)) {
                log.warn("[{}]rpt org [{}] does not have any sub task", logId(context), mainTask.getOrgId());
                continue;
            }
            List<String> orgIds = subTasks.stream().map(ImasBmTodoTask::getOrgId).collect(Collectors.toList());
            SqlFragment sqlFragment = SqlHelper.toSqlFragment(orgIds);
            @SQL
            String sql = String.format(RPT_ORG_SQL_TPL, context.getDataRptDate(), mainTask.getOrgId());
            Map<String, Object> sqlParams = new HashMap<>();
            sqlParams.put("dataRptDate", dataRptDate);
            sqlParams.put("reportCode", reportCode);
            sqlParams.put("pTaskId", mainTask.getTaskId());
            sqlParams.putAll(sqlFragment.getParameters());
            LocalDateTime startTime = DateHelper.now();
            Map<String, Object> data = sqlRunner.queryForMap(sql, sqlParams);
            LocalDateTime endTime = DateHelper.now();
            data.put("REF_ID", mainTask.getTaskId());
            ImasRecordCountResult result = ImasRecordCountResult.of(context, startTime, endTime, data);
            log.debug("[{}] count by report org[{}] spend[{}ms]", logId(context), mainTask.getOrgId(), result.getSpendTime());
            results.add(result);
        }
        return results;
    }

    private String logId(ImasRecordCountContext context) {
        return String.join("-",
                context.getOprMode().name(),
                Objects.toString(context.isEmptyOpr()),
                context.getDataRptDate(),
                context.getReportCode(),
                context.getTargetOrgId(),
                context.getTargetGroupId(),
                SIMPLE_DATE_TIME.format(context.getOprTime()));
    }

    private boolean isDetailEmpty(ImasRecordCountResult result) {
        Map<String, Object> data = result.getData();
        return (data.get("NEXT_ACTION") == null || StringUtils.isBlank(data.get("NEXT_ACTION").toString()))
                && (data.get("CHECK_FLAG") == null || StringUtils.isBlank(data.get("CHECK_FLAG").toString()))
                && (Integer.parseInt(Objects.toString(data.get("RECORD_NUM"), "0")) == 0);
    }

}