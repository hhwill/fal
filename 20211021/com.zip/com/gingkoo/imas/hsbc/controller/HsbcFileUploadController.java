package com.gingkoo.imas.hsbc.controller;


import java.io.File;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import com.google.common.base.Splitter;
import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.service.SysParamService;
import com.gingkoo.gpms.api.bean.DataIEResponse;
import com.gingkoo.gpms.importer.entity.GpBmIdUploadlog;
import com.gingkoo.gpms.importer.service.DataImportProcessService;
import com.gingkoo.gpms.util.FileUtil;
import com.gingkoo.imas.hsbc.service.HsbcFileImportService;
import com.gingkoo.root.facility.datetime.ImmutableDateFormat;
import com.gingkoo.root.facility.string.UuidHelper;
import com.gingkoo.root.facility.web.ServletHelper;

import static com.gingkoo.gpms.constant.ImportConstant.IMPORT_SOURCE_TYPE_ODS;

/**
 * 文件上传功能
 */
@Controller
@RequestMapping({"/api/hsbc"})
public class HsbcFileUploadController {
    public static final ImmutableDateFormat FILE_DATE_TIME = ImmutableDateFormat.of("yyyyMMddHHmmssSSS");
    public static final Splitter FILENAME_SPLITTER = Splitter.on('.');
    private static final Splitter UNDERLINE_SPLITTER = Splitter.on('_');
    private static final Logger log = LoggerFactory.getLogger(HsbcFileUploadController.class);
    private final DataImportProcessService processService;
    private final HsbcFileImportService fileImportService;
    private final HttpServletRequest request;

    @Value("${application.home}")
    String filePath;

    public HsbcFileUploadController(DataImportProcessService processService, HsbcFileImportService fileImportService,
                                    HttpServletRequest request) {
        this.processService = processService;
        this.fileImportService = fileImportService;
        this.request = request;
    }


    @ResponseBody
    @RequestMapping(value = {"/hsbcFileUpload"}, method = {RequestMethod.POST})
    public DataIEResponse<?> fileUpload(@RequestParam("file") CommonsMultipartFile file) {
        GlobalInfo globalInfo = GlobalInfo.getCurrentInstanceWithoutException();
        if (globalInfo == null) {
            return DataIEResponse.error("文件上传失败！【无法获取上传用户信息】");
        } else {
            int fileSizeLimit = Integer.parseInt(SysParamService.getSysParamDef("GPMS", "IMP_DIC_FILE_SIZE", "102400000"));
            if (file.getSize() > (long) fileSizeLimit) {
                return DataIEResponse.error("文件上传失败！【文件大小超限制" + FileUtil.formatFileSize(fileSizeLimit) + "】");
            } else {
                String uploadFilePath = SysParamService.getSysParamDir(this.filePath, "GPMS|UPLOAD_PATH");
                File fileDir = new File(uploadFilePath);
                if (!fileDir.exists()) {
                    fileDir.mkdirs();
                }

                String fileName = file.getOriginalFilename();
                String md5Name;
                try (InputStream inputStream = file.getInputStream()) {
                    md5Name = DigestUtils.md5Hex(inputStream) + "." + fileName.substring(fileName.lastIndexOf(
                            ".") + 1);
                } catch (Exception e) {
                    log.error("文件上传失败", e);
                    return DataIEResponse.error("文件上传失败！【" + e.getMessage() + "】");
                }
                try {
                    Date date = new Date();
                    String formatTime = FILE_DATE_TIME.format(date);
                    List<String> fileSplitter = FILENAME_SPLITTER.splitToList(fileName);
                    fileName = fileSplitter.get(0) + "_" + formatTime + "." + fileSplitter.get(1);

                    File targetFile = new File(fileDir, md5Name);
                    if (!targetFile.exists()) {
                        file.transferTo(targetFile);
                    }

                    List<String> fileNameSp = UNDERLINE_SPLITTER.splitToList(fileName);
                    String groupId = fileNameSp.get(1);
                    String dataRptDate = fileNameSp.get(2);

                    GpBmIdUploadlog uploadLog = new GpBmIdUploadlog();
                    uploadLog.setUploadGuid(UuidHelper.fastClean());
                    uploadLog.setStoreName(md5Name);
                    uploadLog.setFileName(fileName);
                    uploadLog.setTargetPath(targetFile.getPath());
                    uploadLog.setWorkDate(dataRptDate);
                    uploadLog.setSndIp(ServletHelper.getRemoteAddr(this.request));
                    uploadLog.setRecIp(InetAddress.getLocalHost().getHostAddress());
                    uploadLog.setFiller1("未导入");
                    uploadLog.setFiller2(file.getOriginalFilename());
                    uploadLog.setFiller3(groupId);
                    uploadLog.setUploadTime(ImmutableDateFormat.SIMPLE_DATE_TIME.format(date));
                    uploadLog.setUploadOrgId(globalInfo.getBrno());
                    uploadLog.setUploader(globalInfo.getTlrno());
                    uploadLog.setUploadSource(IMPORT_SOURCE_TYPE_ODS);
                    this.processService.saveGpBmIdUploadlog(uploadLog);
                    return DataIEResponse.success("文件上传成功", uploadLog.getUploadGuid());
                } catch (Exception e) {
                    log.error("文件上传失败", e);
                    return DataIEResponse.error("文件上传失败！【" + e.getMessage() + "】");
                }
            }
        }
    }

    @ResponseBody
    @RequestMapping(value = {"/testFileImport"})
    public DataIEResponse<?> fileImport() {
        try {
            fileImportService.importFiles();
        } catch (Throwable e) {
            log.error("文件导入失败",e);
            return DataIEResponse.error("文件导入成功");
        }
        return DataIEResponse.success("文件导入成功");
    }

}
