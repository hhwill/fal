package com.gingkoo.imas.autorevise.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.gingkoo.data.compute.api.bean.Result;
import com.gingkoo.gf4j2.framework.entity.bean.DatabaseMetaTableColumn;
import com.gingkoo.gf4j2.framework.service.DatabaseMetaDataService;
import com.gingkoo.imas.autorevise.base.BaseAutoReviseService;
import com.gingkoo.imas.autorevise.base.MergeContext;
import com.gingkoo.imas.autorevise.helper.AutoReviseDataHelper;
import com.gingkoo.imas.bean.*;
import com.gingkoo.imas.core.config.ImasSysConfigService;
import com.gingkoo.imas.core.dbsharding.ImasDbShardingService;
import com.gingkoo.orm.entity.ImasBmRptCfgDtl;
import com.gingkoo.orm.repository.ImasBmRptCfgDtlRepository;
import com.gingkoo.rdms.base.data.g.entity.RdmsDsTableFieldCfg;
import com.gingkoo.rdms.base.data.g.repository.RdmsDsTableFieldCfgRepository;
import com.gingkoo.root.annotation.Languages;
import com.gingkoo.root.facility.spring.annotation.InTransaction;

import static com.gingkoo.imas.service.ImasEtlSyncDataService.EXTRA_COLUMN;
import static com.gingkoo.imas.service.ImasEtlSyncDataService.SP_REPORT_CODE;
import static com.gingkoo.root.facility.datetime.DateConstants.SIMPLE_DATE;
import static com.gingkoo.root.facility.string.StringHelper.COMMA_JOINER;

@Slf4j
@Service
public class MysqlAutoReviseService extends BaseAutoReviseService {
    private final JdbcTemplate jdbcTemplate;
    @Autowired
    private RdmsDsTableFieldCfgRepository dsFieldRepository;

    @Autowired
    private DatabaseMetaDataService metaDataService;

    @Autowired
    private ImasDbShardingService shardingService;

    @Autowired
    private ImasSysConfigService sysConfigService;

    @Autowired
    private ImasBmRptCfgDtlRepository dtlRepository;

    public MysqlAutoReviseService(AutoReviseDataHelper dataHelper, DataSource dataSource) {
        super(dataHelper);
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    @InTransaction
    public Result doMerge(MergeContext context) {
        String dataRptDate = context.getDataRptDate();
        String reportCode = context.getReportCode();
        String orgId = context.getScopeOrgId();
        String groupId = context.getScopeGroupId();

        LocalDate curr = LocalDate.parse(dataRptDate, SIMPLE_DATE);
        String lastDay = curr.minusDays(1).format(SIMPLE_DATE);
        String odsTableName = shardingService.shardingTableName("IMAS_ODS_" + reportCode, dataRptDate);
        String pmTableName = shardingService.shardingTableName("IMAS_PM_" + reportCode, dataRptDate);
        String preOdsTableName = shardingService.shardingTableName("IMAS_ODS_" + reportCode, lastDay);
        String prePmTableName = shardingService.shardingTableName("IMAS_PM_" + reportCode, lastDay);
        boolean isTableSharding = sysConfigService.isPmSharding();
        Map<String, Object> resultMap = new HashMap<>();

        List<String> businessKeys = dsFieldRepository.findByDatasetIdAndKeyType("IMAS_PM_" + reportCode, "U");

        List<String> joinOn = new ArrayList<>();
        List<String> pmMergeOn = new ArrayList<>();
        List<String> pmOdsMergeOn = new ArrayList<>();

        for (String businessKey : businessKeys) {
            if (!businessKey.equals("SJRQ")) {
                joinOn.add("t1." + businessKey + "=t2." + businessKey);
                pmMergeOn.add("t2." + businessKey + "=t1." + businessKey);
                pmOdsMergeOn.add(PM_TABLE_ALIAS + "." + businessKey + "=" + ODS_TABLE_ALIAS + "." + businessKey);
            }
        }

        //增量供数的情况下,合并t1 ods数据
        List<DatabaseMetaTableColumn> rptTableColumns = metaDataService.findColumsByTableName(odsTableName);
        List<String> intoColumns = new ArrayList<>();
        List<String> fromColumns = new ArrayList<>();

        for (DatabaseMetaTableColumn column : rptTableColumns) {
            intoColumns.add(column.getColumnName());
            if (column.getColumnName().equals("SJRQ") || column.getColumnName().equals("DATA_RPT_DATE")) {
                fromColumns.add("'" + dataRptDate + "'");
            } else if (column.getColumnName().equals("DATA_ID")) {
                fromColumns.add("REPLACE(@DATA_ID := UUID(), '-', '')");
            } else {
                fromColumns.add("t1." + column.getColumnName());
            }
        }
        if (context.getSyncMethod() == SyncMethod.INCREMENT && "1".equals(context.getCollectMode())) {
            @Languages.SQL
            String insertHisOdsDataSql = "insert into " + odsTableName + " (" + COMMA_JOINER.join(intoColumns) + ") " +
                    " select " + COMMA_JOINER.join(fromColumns) + " from " + preOdsTableName + " t1 " +
                    " where t1.SJRQ=? " +
                    " and not exists(select 1 from " + odsTableName + " t2 where " + WHERE_CONDITION_JOINER.join(joinOn) + " and t2.SJRQ=?) " +
                    " and exists(select 1 from " + prePmTableName + " t2 where " + WHERE_CONDITION_JOINER.join(joinOn) + " and t2.SJRQ=?)";
            jdbcTemplate.update(insertHisOdsDataSql, lastDay, dataRptDate, lastDay);
        }

        //2，将ods t2全量数据推送至pm t2
        // 分表，全部机构和业务线同步则truncate
        String deleteSql;
        int delNum;
        if (isTableSharding && StringUtils.isEmpty(orgId) && StringUtils.isEmpty(groupId)) {
            deleteSql = "TRUNCATE TABLE " + pmTableName;
            delNum = jdbcTemplate.update(deleteSql);
            log.info("执行TRUNCATE sql为[{}] TRUNCATE结果为[{}]", deleteSql, delNum);
        } else {
            StringBuilder deleteClause = new StringBuilder();
            if (!StringUtils.isEmpty(orgId)) {
                deleteClause.append(transformColumnToSqlString(SCOPE_ORG_COLUMN, PM_TABLE_ALIAS, orgId));
            }
            if (!StringUtils.isEmpty(groupId)) {
                deleteClause.append(transformColumnToSqlString(SCOPE_GROUP_COLUMN, PM_TABLE_ALIAS, groupId));
            }
            deleteSql = "DELETE FROM " + pmTableName + " WHERE SJRQ = ? " + deleteClause.toString().replaceAll(PM_TABLE_ALIAS + ".", "");
            delNum = jdbcTemplate.update(deleteSql, dataRptDate);
            log.info("执行Delete sql为[{}] 删除条数为[{}]", deleteSql, delNum);
        }

        List<ImasBmRptCfgDtl> dtlList = dtlRepository.getAllValidByReportCode(reportCode);
        String columns = dtlList.stream().map(ImasBmRptCfgDtl::getColumnName).filter(columnName -> !"SJRQ".equals(columnName)).collect(Collectors.joining(","));
        String t1Columns = dtlList.stream().map(ImasBmRptCfgDtl::getColumnName).filter(columnName -> !"SJRQ".equals(columnName)).collect(Collectors.joining(",t1."));
        //三张表特殊处理
        if (SP_REPORT_CODE.contains(reportCode)) {
            columns = columns + ",NBJGH";
            t1Columns = t1Columns + ",t1.NBJGH";
        }
        String pmInsertT2Columns = "DATA_RPT_DATE,SJRQ," + EXTRA_COLUMN + "," + columns + ",NEXT_ACTION";
        String odsInsertT2Columns = "'" + dataRptDate + "','" + dataRptDate + "'," +
                "REPLACE(@DATA_ID := UUID(), '-', ''),t1.DATA_DATE,t1.ORG_ID,t1.GROUP_ID,'00','O'," +
                "'1','N',0,'sys_import','" + context.getDateTime() + "','" + context.getStartTime() + "',t1.RSV1,t1" +
                ".RSV2,t1.RSV3,t1.RSV4,t1.RSV5,t1." + t1Columns + ",'00'";

        StringBuilder fromSelectClause = new StringBuilder();
        if (!StringUtils.isEmpty(orgId)) {
            fromSelectClause.append(transformColumnToSqlString(SCOPE_ORG_COLUMN, "t1", orgId));
        }
        if (!StringUtils.isEmpty(groupId)) {
            fromSelectClause.append(transformColumnToSqlString(SCOPE_GROUP_COLUMN, "t1", groupId));
        }

        String dateClause = fromSelectClause.toString();
        dateClause = " WHERE t1.SJRQ='" + dataRptDate + "' " + dateClause;

        String insertSql = "INSERT INTO " + pmTableName + " (" + pmInsertT2Columns + ") " +
                "SELECT " + odsInsertT2Columns + " FROM " + odsTableName + " t1 " + dateClause;

        int syncNum = jdbcTemplate.update(insertSql);
        log.info("执行sql为[{}] 插入数量为[{}]", insertSql, syncNum);

        //采集模式1-变化量 2-增量 3-全量,非变化量模式不用自动补录规则合并
        if (!"1".equals(context.getCollectMode())) {
            resultMap.put("syncNum", syncNum);
            return Result.of(Result.OK.getCode(), "", resultMap);
        }
        //3,用户新增数据和自动补录数据应用到pm t2，形成pm t2数据
        List<RdmsDsTableFieldCfg> autoReviseColumns = dsFieldRepository.findByDatasetIdAndAndAutoReviseFlag("IMAS_PM_" + reportCode, "Y");

        if (autoReviseColumns.isEmpty()) {
            //无补录字段，不走自动补录规则，把当期没有的前一期的pm数据拉到当期
            insertDataNotExists(dataRptDate, lastDay, pmTableName, prePmTableName, pmMergeOn, intoColumns, fromColumns, fromSelectClause);
            resultMap.put("syncNum", syncNum);
            return Result.of(Result.OK.getCode(), "", resultMap);
        }

        String pmUpdateT2Columns = autoReviseColumns.stream()
                .map(f -> "t2." + f.getFieldId() + "=t1." + f.getFieldId())
                .collect(Collectors.joining(","));

        String mergeDateClause = fromSelectClause.toString();
        mergeDateClause = " where t2.SJRQ='" + dataRptDate + "' and t1.SJRQ='" + lastDay + "' " + mergeDateClause;

        @Languages.SQL
        String updateT2PmDataSql =
                "update " + pmTableName + " t2 inner join " + prePmTableName + " t1 on " + WHERE_CONDITION_JOINER.join(pmMergeOn) + " set " + pmUpdateT2Columns +
                        mergeDateClause;
        jdbcTemplate.update(updateT2PmDataSql);

        insertDataNotExists(dataRptDate, lastDay, pmTableName, prePmTableName, pmMergeOn, intoColumns, fromColumns, fromSelectClause);

        //4. ods t1与t2对比自动补录字段标记变化数据
        String autoReviseCompareFields = autoReviseColumns.stream()
                .map(f -> "ifnull(t2." + f.getFieldId() + ",0)=ifnull(t1." + f.getFieldId() + ",0)")
                .collect(Collectors.joining(" and "));
        String odsCompareFlagSql =
                "update " + odsTableName + " t2 left join " + preOdsTableName + " t1 on (" + WHERE_CONDITION_JOINER.join(pmMergeOn) + " and t1.SJRQ='" + lastDay + "' and " + autoReviseCompareFields +
                        ") set t2.RSV1='" + dataRptDate + "' where t2.SJRQ='" + dataRptDate + "' and " +
                        "t1.DATA_ID is null";
        jdbcTemplate.update(odsCompareFlagSql);

        //5.将变化的自动补录字段应用到pm t2
        StringBuilder selectClause = new StringBuilder();
        ReviseRuleType ruleType = ReviseRuleType.ODS;
        AutoReviseRule autoReviseRule = dataHelper.getAutoReviseRule(reportCode);
        if (autoReviseRule != null) {
            //表默认补录规则
            ruleType = autoReviseRule.getReviseRule();
            //行补录规则
            List<AutoReviseRowRule> rowRules = autoReviseRule.getRowRules();
            if (!rowRules.isEmpty()) {
                selectClause.append(" AND ( 1=0 ");
                for (AutoReviseRowRule rowRule : rowRules) {
                    String condition = rowRule.getTriggerCondition();
                    selectClause.append(" OR ( ").append(StringUtils.isEmpty(condition) ? " 1=0 " : condition);
                    if (!StringUtils.isEmpty(rowRule.getOrgScope())) {
                        selectClause.append(transformColumnToSqlString(SCOPE_ORG_COLUMN, ODS_TABLE_ALIAS, rowRule.getOrgScope()));
                    }
                    if (!StringUtils.isEmpty(rowRule.getBusinessLineScope())) {
                        selectClause.append(transformColumnToSqlString(SCOPE_GROUP_COLUMN, ODS_TABLE_ALIAS, rowRule.getBusinessLineScope()));
                    }
                    selectClause.append(" ) ");
                }
                selectClause.append(" ) ");
            }
        }
        if (!StringUtils.isEmpty(orgId)) {
            selectClause.append(transformColumnToSqlString(SCOPE_ORG_COLUMN, ODS_TABLE_ALIAS, orgId));
        }
        if (!StringUtils.isEmpty(groupId)) {
            selectClause.append(transformColumnToSqlString(SCOPE_GROUP_COLUMN, ODS_TABLE_ALIAS, groupId));
        }

        //赋予新dataId，并将数据日期改为当前日期
        //字段自动补录规则
        if (!autoReviseColumns.isEmpty()) {
            List<String> mergeUpdate = new ArrayList<>();
            List<String> insertPmColumns = new ArrayList<>();
            List<String> insertOdsColumns = new ArrayList<>();

            if (isTableSharding) {
                mergeUpdate.add(PM_TABLE_ALIAS + ".DATA_ID=" + ODS_TABLE_ALIAS + ".DATA_ID");
            } else {
                mergeUpdate.add(PM_TABLE_ALIAS + ".DATA_ID=REPLACE(@DATA_ID := UUID(), '-', '')");
            }
            for (DatabaseMetaTableColumn column : rptTableColumns) {
                insertPmColumns.add(column.getColumnName());
                if (column.getColumnName().equals("DATA_ID") && !isTableSharding) {
                    insertOdsColumns.add("REPLACE(@DATA_ID := UUID(), '-', '')");
                } else {
                    insertOdsColumns.add(ODS_TABLE_ALIAS + "." + column.getColumnName());
                }
            }
            for (RdmsDsTableFieldCfg column : autoReviseColumns) {
                ReviseRuleType fieldType = ruleType;
                AutoReviseFieldRule fieldRule = null;
                if (autoReviseRule != null) {
                    fieldRule = autoReviseRule.getFieldRules().stream().filter(r -> r.getFieldName().equals(column.getFieldId())).findAny().orElse(null);
                }

                if (fieldRule != null && fieldRule.getReviseRule() != null) {
                    fieldType = fieldRule.getReviseRule();
                }

                String fieldValue;
                if (fieldType == ReviseRuleType.CUSTOM && (fieldRule != null && StringUtils.isNotEmpty(fieldRule.getCustomRule()))) {
                    if (AUTO_REVISE_FILED_NUMBER.contains(column.getDataType())) {
                        fieldValue = fieldRule.getCustomRule();
                    } else {
                        fieldValue = "'" + fieldRule.getCustomRule() + "'";
                    }
                } else {
                    //补录规则是补录时,为空的数据源值才会被用户补录数据覆盖；否则源数据不变
                    if (fieldType == ReviseRuleType.PM) {
                        fieldValue = "ifnull(" + PM_TABLE_ALIAS + "." + column.getFieldId() + "," + ODS_TABLE_ALIAS + "." + column.getFieldId() + ")";
                    } else {
                        fieldValue = "ifnull(" + ODS_TABLE_ALIAS + "." + column.getFieldId() + "," + PM_TABLE_ALIAS + "." + column.getFieldId() + ")";
                    }
                }
                String caseValue;
                if (fieldRule != null && (StringUtils.isNotEmpty(fieldRule.getOrgScope()) || StringUtils.isNotEmpty(fieldRule.getBusinessLineScope())
                        || StringUtils.isNotEmpty(fieldRule.getTriggerCondition()))) {
                    List<String> scopeConds = buildFieldRuleCondition(fieldRule);
                    //匹配org或group的采用字段规则，否则采用表默认规则
                    String commonValue;
                    if (ruleType == ReviseRuleType.PM) {
                        commonValue = "ifnull(" + PM_TABLE_ALIAS + "." + column.getFieldId() + "," + ODS_TABLE_ALIAS + "." + column.getFieldId() + ")";
                    } else {
                        commonValue = "ifnull(" + ODS_TABLE_ALIAS + "." + column.getFieldId() + "," + PM_TABLE_ALIAS + "." + column.getFieldId() + ")";
                    }
                    caseValue = " CASE WHEN " + WHERE_CONDITION_JOINER.join(scopeConds) + " THEN " + fieldValue + " ELSE " + commonValue + " END ";
                } else {
                    caseValue = fieldValue;
                }
                mergeUpdate.add(PM_TABLE_ALIAS + "." + column.getFieldId() + "=" + caseValue);
            }
            if (!mergeUpdate.isEmpty() || !insertPmColumns.isEmpty()) {
                selectClause.append(" AND ").append(ODS_TABLE_ALIAS).append(".RSV1='").append(dataRptDate).append("' ");

                String updateClause = selectClause.toString();
                updateClause = " where " + ODS_TABLE_ALIAS + ".SJRQ='" + dataRptDate + "' and " + PM_TABLE_ALIAS +
                        ".SJRQ='" + dataRptDate + "'" + updateClause;

                @Languages.SQL
                String updateOdsPmDataSql =
                        "update " + pmTableName + " " + PM_TABLE_ALIAS + " inner join " + odsTableName + " " + ODS_TABLE_ALIAS + " on " + WHERE_CONDITION_JOINER.join(pmOdsMergeOn) + " set " + COMMA_JOINER.join(mergeUpdate) +
                                updateClause;
                jdbcTemplate.update(updateOdsPmDataSql);

                String insertClause = selectClause.toString();
                insertClause = " and " + ODS_TABLE_ALIAS + ".SJRQ='" + dataRptDate + "' " + insertClause;

                insertClause =
                        " where 1=1 " + insertClause + "  and not exists(select 1 from " + pmTableName + "  " + PM_TABLE_ALIAS +
                                " where " + PM_TABLE_ALIAS + ".SJRQ='" + dataRptDate + "' and " + WHERE_CONDITION_JOINER.join(pmOdsMergeOn) + ") ";
                @Languages.SQL
                String insertOdsPmDataSql = "insert into " + pmTableName + " (" + COMMA_JOINER.join(insertPmColumns) +
                        ") select " + COMMA_JOINER.join(insertOdsColumns) + " from " + odsTableName + " " + ODS_TABLE_ALIAS + insertClause;
                jdbcTemplate.update(insertOdsPmDataSql);
            }
        }
        resultMap.put("syncNum", syncNum);
        return Result.of(Result.OK.getCode(), "", resultMap);
    }

    private void insertDataNotExists(String dataRptDate, String lastDay, String pmTableName, String prePmTableName, List<String> pmMergeOn, List<String> intoColumns, List<String> fromColumns, StringBuilder fromSelectClause) {
        String insertClause = " where t2.SJRQ='" + dataRptDate + "' ";

        insertClause =
                " where t1.SJRQ='" + lastDay + "' and not exists(select 1 from " + pmTableName + " t2 " + insertClause + " and " +
                        WHERE_CONDITION_JOINER.join(pmMergeOn) + ") " + fromSelectClause.toString();
        @Languages.SQL
        String insertT2PmDataSql = "insert into " + pmTableName + " (" + COMMA_JOINER.join(intoColumns) + ") " +
                " select " + COMMA_JOINER.join(fromColumns) + " from " + prePmTableName + " t1 " + insertClause;
        jdbcTemplate.update(insertT2PmDataSql);
    }

}
