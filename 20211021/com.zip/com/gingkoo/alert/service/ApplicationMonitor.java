package com.gingkoo.alert.service;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileSystemUtils;
import org.jetbrains.annotations.Contract;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.gingkoo.alert.AlertAPIHelper;

@Slf4j
@Component
public class ApplicationMonitor {

    private final AlertAPIHelper alertAPIHelper;
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    @Contract(pure = true)
    public ApplicationMonitor(AlertAPIHelper alertAPIHelper, DataSource dataSource) {
        this.alertAPIHelper = alertAPIHelper;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    //    @Scheduled(cron = "0 */10 * * * ?")
    @Scheduled(cron = "*/5 * * * * ?")
    public void systemAlert() {
        jvmMemoryAlert();
        diskSpaceAlert();
        dbConnectAlert();
    }

    public void dbConnectAlert() {
        try {
            jdbcTemplate.execute("select 1 from DUAL");
        } catch (Exception e) {
            try {
                alertAPIHelper.sendAlertMajor("database connect error", "数据库连接异常，请及时处理");
            } catch (IOException ex) {
                log.error("提交监控信息出错", ex);
            }
        }
    }

    public void jvmMemoryAlert() {
        Runtime run = Runtime.getRuntime();
        long max = run.maxMemory();
        long total = run.totalMemory();

        //创建一个数值格式化对象
        DecimalFormat df = new DecimalFormat("##.##%");//传入格式模板
        float result = total / (float) max;
        String resultStr = df.format(result);
        log.debug("jvm内存占用：" + resultStr);

        if (result >= 0.8) {
            try {
                alertAPIHelper.sendAlertMajor("jvm warn", "JVM使用超过" + resultStr + "，请及时处理。");
            } catch (IOException e) {
                log.error("提交监控信息出错", e);
            }
        }
    }

    public void diskSpaceAlert() {
        File file = new File("/");
        long total = file.getTotalSpace();
        long used = 0;
        try {
            used = total - FileSystemUtils.freeSpaceKb("/") * 1024;
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
        DecimalFormat df = new DecimalFormat("##.##%");//传入格式模板
        float result = used / (float) total;
        String resultStr = df.format(result);
        log.debug("硬盘占用：" + resultStr);

        if (result >= 0.8) {
            try {
                if (result <= 0.95) {
                    alertAPIHelper.sendAlertMajor("disk space warn", "硬盘空间使用超过" + resultStr + "，请及时处理");
                } else {
                    alertAPIHelper.sendAlertMajor("disk space warn", "硬盘空间已满" + resultStr + "，请及时处理");
                }
            } catch (IOException e) {
                log.error("提交监控信息出错", e);
            }
        }
    }

}
