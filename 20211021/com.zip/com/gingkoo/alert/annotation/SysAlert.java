package com.gingkoo.alert.annotation;

import java.lang.annotation.*;

import com.gingkoo.alert.bean.AlertLevel;

@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface SysAlert {

    String key() default "";

    String desc() default "";

    AlertLevel level() default AlertLevel.ERROR;

    Class<? extends Throwable>[] catchFor() default {};

}


