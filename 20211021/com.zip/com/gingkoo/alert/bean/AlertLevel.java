package com.gingkoo.alert.bean;

import com.gingkoo.root.annotation.NonNull;
import com.gingkoo.root.facility.bean.WithCode;

public enum AlertLevel  implements WithCode<String> {
    INFO("INFO", "信息"),
    WARN("WARN", "警告"),
    ERROR("ERROR", "异常");

    private final String code;
    private final String name;

    AlertLevel(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    @NonNull
    @Override
    public String getCode() {
        return code;
    }
}