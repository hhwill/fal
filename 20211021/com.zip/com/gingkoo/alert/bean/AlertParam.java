package com.gingkoo.alert.bean;

import lombok.Data;

@Data
public class AlertParam {

    private String module;
    private String key;
    private String desc;
    private Object object;
    private Class<Throwable> catchFor;
    private AlertLevel level;

}
