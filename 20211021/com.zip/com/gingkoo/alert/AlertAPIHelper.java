package com.gingkoo.alert;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class AlertAPIHelper {

    @Value("${alert.api.url}")
    private String alertApiUrl;
    @Value("${alert.api.key}")
    private String alertApiKey;
    @Value("${alert.api.version}")
    private String alertApiVersion;
    @Value("${alert.api.type}")
    private String alertApiType;

    public void sendAlertMajor(String object, String text) throws IOException {
        Map<String, String> params = new HashMap<>();
        params.put("@key", alertApiKey);
        params.put("@version", alertApiVersion);
        params.put("@type", alertApiType);
        params.put("severity", "MAJOR");
        params.put("object", object);
        params.put("text", text);
        String responseMessage = HttpClientUtil.doPost(alertApiUrl, params);
        if (responseMessage != null) {
            log.info("Send Major Alert Success! object is {}, text is {} ", object, text);
        }
    }

    public void sendAlertMinor(String object, String text) throws IOException {
        Map<String, String> params = new HashMap<>();
        params.put("@key", alertApiKey);
        params.put("@version", alertApiVersion);
        params.put("@type", alertApiType);
        params.put("severity", "MINOR");
        params.put("object", object);
        params.put("text", text);
        String responseMessage = HttpClientUtil.doPost(alertApiUrl, params);
        if (responseMessage != null) {
            log.info("Send Minor Alert Success! object is {}, text is {} ", object, text);
        }
    }

}
