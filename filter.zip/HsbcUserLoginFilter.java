package com.gingkoo.sso.security;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.ssl.Base64;
import org.jdom2.Content;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.io.MarshallingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.gingkoo.sso.security.config.HsbcProperties;
import com.gingkoo.sso.security.service.HsbcUserService;

@Slf4j
public class HsbcUserLoginFilter extends AbstractAuthenticationProcessingFilter {

    private final RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();
    @Autowired
    private HsbcProperties properties;
    @Autowired
    private HsbcUserService hsbcUserService;

    public HsbcUserLoginFilter() {
        super(new AntPathRequestMatcher("/login"));
    }

    public HsbcUserLoginFilter(String filterProcessesUrl) {
        super(new AntPathRequestMatcher(filterProcessesUrl));
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        if (!properties.isEnabled()) {
            chain.doFilter(request, response);
            return;
        }

        super.doFilter(request, response, chain);
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException, IOException, ServletException {
        BufferedReader bufferedReader = request.getReader();
        String responseStr;
        StringBuilder wholeResponseStr = new StringBuilder();
        while ((responseStr = bufferedReader.readLine()) != null) {
            wholeResponseStr.append(responseStr);
        }
        String uri = request.getRequestURI().substring(request.getContextPath().length());
        if (uri.startsWith("/login")) {
            log.info("Saml Response /login:" + wholeResponseStr);
        }
        if (!wholeResponseStr.toString().contains("SAMLResponse")) {
            try {
                String targetUrl = hsbcUserService.createSamlRequestURL();
                redirectStrategy.sendRedirect(request, response, targetUrl);
            } catch (ConfigurationException | MarshallingException ex) {
                request.setAttribute("errormsg", "IMAS用户验证失败," + ex.getMessage());
                request.getRequestDispatcher("/common/error.jsp").forward(request, response);
            }
            return null;
        }

        log.info("Saml Response body:" + wholeResponseStr);
        String urlDecoded = URLDecoder.decode(wholeResponseStr.toString().split("SAMLResponse=")[1],
                StandardCharsets.UTF_8.name());
        String baseDecoded = new String(Base64.decodeBase64(urlDecoded.getBytes(StandardCharsets.UTF_8)));

        log.info("Saml Response Decoded: " + baseDecoded);

        String responseStatus = "";
        String staffId = "";
        String fullName = "";
        String email = "";
        String userGroup = "";
        try {
            SAXBuilder builder = new SAXBuilder();
            Document xmlDocument = builder.build(new StringReader(baseDecoded));
            Element root = xmlDocument.getRootElement();

            for (Content content : root.getContent()) {
                Element eleContent = (Element) content;
                if ("Status".equals(eleContent.getName())) {
                    Element elementStatus = (Element) eleContent.getContent(0);

                    if (elementStatus != null) {
                        responseStatus = elementStatus.getAttributeValue("Value");
                    }
                }
                if ("Assertion".equals(eleContent.getName())) {
                    for (Content assertion : eleContent.getContent()) {
                        Element elementAssertion = (Element) assertion;
                        if (elementAssertion != null && "Subject".equals(elementAssertion.getName())) {
                            for (Content contentSubject : elementAssertion.getContent()) {
                                Element elementSubject = (Element) contentSubject;
                                if (elementSubject != null && "NameID".equals(elementSubject.getName())) {
                                    staffId = elementSubject.getValue();
                                }
                            }
                        }
                        if (elementAssertion != null && "AttributeStatement".equals(elementAssertion.getName())) {
                            for (Content contentAttribute : elementAssertion.getContent()) {
                                Element elementAttribute = (Element) contentAttribute;
                                if (elementAttribute != null && "fullname".equals(elementAttribute.getAttributeValue("Name"))) {
                                    Element elementName = (Element) elementAttribute.getContent();
                                    fullName = elementName.getContent(0).getValue();
                                }
                                if (elementAttribute != null && "e-mail".equals(elementAttribute.getAttributeValue("Name"))) {
                                    Element elementName = (Element) elementAttribute.getContent();
                                    email = elementName.getContent(0).getValue();
                                }
                                if (elementAttribute != null && "user group".equals(elementAttribute.getAttributeValue(
                                        "Name"))) {
                                    Element elementName = (Element) elementAttribute.getContent();
                                    userGroup = elementName.getContent(0).getValue();
                                }
                            }
                        }
                    }
                }
            }
            log.info("responseStatus:" + responseStatus);
            log.info("staffId:" + staffId);
            log.info("fullname:" + fullName);
            log.info("userGroup" + userGroup);
        } catch (JDOMException e) {
            log.error("解析SAML响应出错", e);
            request.setAttribute("errormsg", "IMAS用户验证失败," + e.getMessage());
            request.getRequestDispatcher("/common/error.jsp").forward(request, response);
            return null;
        }
        HsbcAuthenticationToken authRequest = new HsbcAuthenticationToken(staffId, "", userGroup);
        authRequest.setEmail(email);
        authRequest.setUsername(fullName);
        authRequest.setAdGroup(userGroup);
        this.setDetails(request, authRequest);
        return this.getAuthenticationManager().authenticate(authRequest);
    }

    protected void setDetails(HttpServletRequest request, HsbcAuthenticationToken authRequest) {
        authRequest.setDetails(this.authenticationDetailsSource.buildDetails(request));
    }

    public void setSessionStrategy(SessionAuthenticationStrategy sessionStrategy) {
        this.setSessionAuthenticationStrategy(sessionStrategy);
    }
}
