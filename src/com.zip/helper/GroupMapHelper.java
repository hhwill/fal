package com.gingkoo.imas.hsbc.helper;

import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import com.github.benmanes.caffeine.cache.LoadingCache;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import static com.gingkoo.root.facility.collection.CacheHelper.mediumCache;

@Service
public class GroupMapHelper {

    private final JdbcTemplate jdbcTemplate;
    private final LoadingCache<String, String> cache = mediumCache(this::loadMappings);

    public GroupMapHelper(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public String getMapping(String src) {
        String dest = cache.get(src);
        return StringUtils.isEmpty(dest) ? src : dest;
    }

    private String loadMappings(String src) {
        List<Map<String, Object>> destMaps = jdbcTemplate.queryForList("select DEST from MAP_GROUPID where SRC=? ",
                src);
        String dest;
        if (!destMaps.isEmpty()) {
            dest = (String) destMaps.get(0).get("DEST");
        } else {
            dest = src;
        }
        return dest.replace("-","_").replace(" ", "_");
    }

    public void refresh() {
        cache.invalidateAll();
    }
}
