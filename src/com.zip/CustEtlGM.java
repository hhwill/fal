package com.gingkoo.imas.hsbc.service;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;

import com.gingkoo.root.facility.spring.tx.TransactionHelper;
import static com.gingkoo.imas.hsbc.service.EtlConst.*;
import static com.gingkoo.imas.hsbc.service.EtlUtils.*;

@Component
public class CustEtlGM {
    private final Logger logger = LoggerFactory.getLogger(CustEtlGM.class);

    private final EtlInsertService insertService;

    private final JdbcTemplate jdbcTemplate;

    private final TransactionHelper transactionTemplate;

    private final DataSource dataSource;

    public CustEtlGM(EtlInsertService insertService, TransactionHelper transactionTemplate, DataSource dataSource) {
        this.insertService = insertService;
        this.transactionTemplate = transactionTemplate;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        this.dataSource = dataSource;
    }

    private void initData(String dir, String now, String group_id) throws Exception {
        String sql = "delete from imas_pm_TYCKJC where sjrq = '"+now+"' and group_id = '"+group_id+"'";
        execUpdSqlCommit(sql);
        sql = "delete from imas_pm_TYJDJC where sjrq = '"+now+"' and group_id = '"+group_id+"'";
        execUpdSqlCommit(sql);
        sql = "delete from imas_pm_MRFSJC where sjrq = '"+now+"' and group_id = '"+group_id+"'";
        execUpdSqlCommit(sql);
        Workbook wb = new XSSFWorkbook(new FileInputStream(dir));
        Sheet st = wb.getSheetAt(0);
        List<List<String>> tyckjc = new ArrayList<List<String>>();
        for (int i = 1; i <= st.getLastRowNum(); i++) {
            Row row = st.getRow(i);
            String sjrq = getCellValue(row.getCell(0));
            if (sjrq.length() < 2) {
                continue;
            }
            List<String> subtyckjc = new ArrayList<String>();
            subtyckjc.add(sjrq);
            //TODO nbjgh
            subtyckjc.add("");
            String khh = getCellValue(row.getCell(1));
            if (khh.contains("-")) {
               subtyckjc.add(formatKHH(khh));
            } else {
                subtyckjc.add("");
            }
            //TODO jrjglxdm
            subtyckjc.add("");
            subtyckjc.add(getCellValue(row.getCell(4)));
            subtyckjc.add(getCellValue(row.getCell(5)));
            subtyckjc.add(getCellValue(row.getCell(6)));
            subtyckjc.add(getCellValue(row.getCell(7)));
            subtyckjc.add(getCellValue(row.getCell(8)));
            subtyckjc.add(getCellValue(row.getCell(9)));
            subtyckjc.add(getCellValue(row.getCell(10)));
            tyckjc.add(subtyckjc);
        }
    }

    private void execUpdSqlCommit(String sql) {
        transactionTemplate.run(Propagation.REQUIRES_NEW, () -> {
            jdbcTemplate.update(sql);
        });
    }
}

