package com.gingkoo.imas.hsbc.service;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;

import com.gingkoo.root.facility.spring.tx.TransactionHelper;
import static com.gingkoo.imas.hsbc.service.EtlConst.*;
import static com.gingkoo.imas.hsbc.service.EtlUtils.*;

@Component
public class CustEtlGM {
    private final Logger logger = LoggerFactory.getLogger(CustEtlGM.class);

    private final EtlInsertService insertService;

    private final JdbcTemplate jdbcTemplate;

    private final TransactionHelper transactionTemplate;

    private final DataSource dataSource;

    public CustEtlGM(EtlInsertService insertService, TransactionHelper transactionTemplate, DataSource dataSource) {
        this.insertService = insertService;
        this.transactionTemplate = transactionTemplate;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        this.dataSource = dataSource;
    }

    private void initData(String dir, String now, String group_id) throws Exception {
        String sql = "delete from imas_pm_TYCKJC where sjrq = '"+now+"' and group_id = '"+group_id+"'";
        execUpdSqlCommit(sql);
        sql = "delete from imas_pm_TYJDJC where sjrq = '"+now+"' and group_id = '"+group_id+"'";
        execUpdSqlCommit(sql);
        sql = "delete from imas_pm_MRFSJC where sjrq = '"+now+"' and group_id = '"+group_id+"'";
        execUpdSqlCommit(sql);
        Workbook wb = new XSSFWorkbook(new FileInputStream(dir));
        Sheet st = wb.getSheetAt(0);
        List<List<String>> tyckjc = new ArrayList<List<String>>();
        for (int i = 1; i <= st.getLastRowNum(); i++) {
            Row row = st.getRow(i);
            String sjrq = getCellValue(row.getCell(0));
            if (sjrq.length() < 2) {
                continue;
            }
            List<String> subtyckjc = new ArrayList<String>();
            subtyckjc.add(sjrq);
            String khh = getCellValue(row.getCell(2));
            String dealing = getCellValue(row.getCell(14));
            String cbclass = getCellValue(row.getCell(18));
            String numberofdays = getCellValue(row.getCell(19));
            //TODO nbjgh
            if (dealing.equals("177") || dealing.equals("179") || dealing.equals("109") || dealing.equals("135")
                    || dealing.equals("213") || dealing.equals("224") || dealing.equals("274") || dealing.equals("255") ) {
                subtyckjc.add("CNHSBC001");
            } else {
                subtyckjc.add("CNHSBC900");
            }

            if (khh.contains("-")) {
               subtyckjc.add(formatKHH(khh));
            } else {
                subtyckjc.add("");
            }
            //jrjglxdm
            subtyckjc.add(getMap("X42", cbclass).trim());
            subtyckjc.add(getCellValue(row.getCell(4)));
            subtyckjc.add(getCellValue(row.getCell(5)));
            subtyckjc.add(getCellValue(row.getCell(6)));
            subtyckjc.add(getCellValue(row.getCell(7)));
            //存款期限类型s
            subtyckjc.add(getCellValue(row.getCell(8)));
            subtyckjc.add(getCellValue(row.getCell(9)));
            subtyckjc.add(getCellValue(row.getCell(10)));
            subtyckjc.add(getCellValue(row.getCell(11)));
            subtyckjc.add(getCellValue(row.getCell(12)));
            subtyckjc.add(getCellValue(row.getCell(13)));

            logger.info(">>><<<<" + subtyckjc.toString());
            tyckjc.add(subtyckjc);
        }
        insertService.insertData(SQL_TYCKJC, group_id, group_id, tyckjc);
        st = wb.getSheetAt(1);
        List<List<String>> tyjdjc = new ArrayList<List<String>>();
        for (int i = 1; i <= st.getLastRowNum(); i++) {
            Row row = st.getRow(i);
            String sjrq = getCellValue(row.getCell(0));
            if (sjrq.length() < 2) {
                continue;
            }
            List<String> subtyjdjc = new ArrayList<String>();
            subtyjdjc.add(sjrq);
            //TODO nbjgh
            subtyjdjc.add("");
            String khh = getCellValue(row.getCell(1));
            if (khh.contains("-")) {
                subtyjdjc.add(formatKHH(khh));
            } else {
                subtyjdjc.add("");
            }
            //TODO jrjglxdm
            subtyjdjc.add("");
            subtyjdjc.add(getCellValue(row.getCell(4)));
            subtyjdjc.add(getCellValue(row.getCell(5)));
            subtyjdjc.add(getCellValue(row.getCell(6)));
            subtyjdjc.add(getCellValue(row.getCell(7)));
            subtyjdjc.add(getCellValue(row.getCell(8)));
            subtyjdjc.add(getCellValue(row.getCell(9)));
            subtyjdjc.add(getCellValue(row.getCell(10)));
            subtyjdjc.add(getCellValue(row.getCell(11)));
            subtyjdjc.add(getCellValue(row.getCell(12)));
            subtyjdjc.add(getCellValue(row.getCell(13)));
            subtyjdjc.add(getCellValue(row.getCell(14)));
            subtyjdjc.add(getCellValue(row.getCell(15)));
            String dealing = getCellValue(row.getCell(16));
            String cbclass = getCellValue(row.getCell(17));
            String numberofdays = getCellValue(row.getCell(18));

            tyjdjc.add(subtyjdjc);
        }
        insertService.insertData(SQL_TYJDJC, group_id, group_id, tyjdjc);
        st = wb.getSheetAt(2);
        List<List<String>> mrfsjc = new ArrayList<List<String>>();
        for (int i = 1; i <= st.getLastRowNum(); i++) {
            Row row = st.getRow(i);
            String sjrq = getCellValue(row.getCell(0));
            if (sjrq.length() < 2) {
                continue;
            }
            List<String> submrfsjc = new ArrayList<String>();
            submrfsjc.add(sjrq);
            //TODO nbjgh
            submrfsjc.add("");
            String khh = getCellValue(row.getCell(1));
            if (khh.contains("-")) {
                submrfsjc.add(formatKHH(khh));
            } else {
                submrfsjc.add("");
            }
            //TODO jrjglxdm
            submrfsjc.add("");
            submrfsjc.add(getCellValue(row.getCell(4)));
            submrfsjc.add(getCellValue(row.getCell(5)));
            submrfsjc.add(getCellValue(row.getCell(6)));
            submrfsjc.add(getCellValue(row.getCell(7)));
            submrfsjc.add(getCellValue(row.getCell(8)));
            submrfsjc.add(getCellValue(row.getCell(9)));
            submrfsjc.add(getCellValue(row.getCell(10)));
            submrfsjc.add(getCellValue(row.getCell(11)));
            submrfsjc.add(getCellValue(row.getCell(12)));
            submrfsjc.add(getCellValue(row.getCell(13)));
            submrfsjc.add(getCellValue(row.getCell(14)));
            submrfsjc.add(getCellValue(row.getCell(15)));
            submrfsjc.add(getCellValue(row.getCell(16)));
            String dealing = getCellValue(row.getCell(17));
            String cbclass = getCellValue(row.getCell(18));
            String numberofdays = getCellValue(row.getCell(19));

            mrfsjc.add(submrfsjc);
        }
        insertService.insertData(SQL_MRFSJC, group_id, group_id, mrfsjc);
    }

    private void execUpdSqlCommit(String sql) {
        transactionTemplate.run(Propagation.REQUIRES_NEW, () -> {
            jdbcTemplate.update(sql);
        });
    }
}

