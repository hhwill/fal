package com.gingkoo.imas.hsbc.service;

import org.springframework.stereotype.Component;

@Component
public class CustEtlGM {

}

