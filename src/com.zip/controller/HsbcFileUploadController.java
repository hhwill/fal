package com.gingkoo.imas.hsbc.controller;


import java.io.File;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import com.google.common.base.Splitter;
import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gf4j2.framework.service.SysParamService;
import com.gingkoo.gpms.api.bean.DataIEResponse;
import com.gingkoo.gpms.importer.entity.GpBmIdUploadlog;
import com.gingkoo.gpms.importer.service.DataImportProcessService;
import com.gingkoo.gpms.util.FileUtil;
import com.gingkoo.imas.hsbc.service.HsbcFileImportService;
import com.gingkoo.root.facility.datetime.ImmutableDateFormat;
import com.gingkoo.root.facility.string.UuidHelper;
import com.gingkoo.root.facility.web.ServletHelper;

import static com.gingkoo.gpms.constant.ImportConstant.IMPORT_SOURCE_TYPE_ODS;

/**
 * 文件上传功能
 */
@Controller
@RequestMapping({"/api/hsbc"})
public class HsbcFileUploadController {
    public static final ImmutableDateFormat FILE_DATE_TIME = ImmutableDateFormat.of("yyyyMMddHHmmssSSS");
    public static final Splitter FILENAME_SPLITTER = Splitter.on('.');
    private static final Logger log = LoggerFactory.getLogger(HsbcFileUploadController.class);
    private final DataImportProcessService processService;
    private final HsbcFileImportService fileImportService;
    private final HttpServletRequest request;

    @Value("${application.home}")
    String filePath;

    public HsbcFileUploadController(DataImportProcessService processService, HsbcFileImportService fileImportService,
                                    HttpServletRequest request) {
        this.processService = processService;
        this.fileImportService = fileImportService;
        this.request = request;
    }


    @ResponseBody
    @RequestMapping(value = {"/hsbcFileUpload"}, method = {RequestMethod.POST})
    public DataIEResponse<?> fileUpload(@RequestParam("file") CommonsMultipartFile file) {
        GlobalInfo globalInfo = GlobalInfo.getCurrentInstanceWithoutException();
        if (globalInfo == null) {
            return DataIEResponse.error("文件上传失败！【无法获取上传用户信息】");
        } else {
            int fileSizeLimit = Integer.parseInt(SysParamService.getSysParamDef("GPMS", "IMP_DIC_FILE_SIZE", "102400000"));
            if (file.getSize() > (long) fileSizeLimit) {
                return DataIEResponse.error("文件上传失败！【文件大小超限制" + FileUtil.formatFileSize((long) fileSizeLimit) + "】");
            } else {
                String uploadFilePath = SysParamService.getSysParamDir(this.filePath, "GPMS|UPLOAD_PATH");
                File fileDir = new File(uploadFilePath);
                if (!fileDir.exists()) {
                    fileDir.mkdirs();
                }

                try {
                    Date date = new Date();
                    String fileName = file.getOriginalFilename();
                    InputStream inputStream = file.getInputStream();
                    Throwable throwable = null;

                    String md5Name;
                    try {
                        md5Name = DigestUtils.md5Hex(inputStream) + "." + fileName.substring(fileName.lastIndexOf(".") + 1);
                    } catch (Throwable throwable1) {
                        throwable = throwable1;
                        throw throwable1;
                    } finally {
                        if (inputStream != null) {
                            if (throwable != null) {
                                try {
                                    inputStream.close();
                                } catch (Throwable var24) {
                                    throwable.addSuppressed(var24);
                                }
                            } else {
                                inputStream.close();
                            }
                        }

                    }

                    String formatTime = FILE_DATE_TIME.format(new Date());
                    List<String> fileSplitter = FILENAME_SPLITTER.splitToList(fileName);
                    fileName = fileSplitter.get(0) + "_" + formatTime + "." + fileSplitter.get(1);
                    File dir = new File(uploadFilePath);
                    if (!dir.exists()) {
                        dir.mkdirs();
                    }

                    File targetFile = new File(dir, md5Name);
                    if (!targetFile.exists()) {
                        file.transferTo(targetFile);
                    }

                    String brno = globalInfo.getBrno();
                    String tlrno = globalInfo.getTlrno();
                    GpBmIdUploadlog uploadLog = new GpBmIdUploadlog();
                    String guid = UuidHelper.fastClean();
                    uploadLog.setUploadGuid(guid);
                    uploadLog.setStoreName(md5Name);
                    uploadLog.setFileName(fileName);
                    uploadLog.setTargetPath(targetFile.getPath());
                    uploadLog.setWorkDate(ImmutableDateFormat.SIMPLE_DATE.format(date));
                    uploadLog.setSndIp(ServletHelper.getRemoteAddr(this.request));
                    uploadLog.setRecIp(InetAddress.getLocalHost().getHostAddress());
                    uploadLog.setFiller1("未导入");
                    uploadLog.setUploadTime(ImmutableDateFormat.SIMPLE_DATE_TIME.format(date));
                    uploadLog.setFiller3(brno);
                    uploadLog.setUploadOrgId(brno);
                    uploadLog.setUploader(tlrno);
                    uploadLog.setUploadSource(IMPORT_SOURCE_TYPE_ODS);
                    this.processService.saveGpBmIdUploadlog(uploadLog);
                    return DataIEResponse.success("文件上传成功", uploadLog.getUploadGuid());
                } catch (Exception e) {
                    log.error("文件上传失败", e);
                    return DataIEResponse.error("文件上传失败！【" + e.getMessage() + "】");
                }
            }
        }
    }

    @ResponseBody
    @RequestMapping(value = {"/testFileImport"})
    public DataIEResponse<?> fileImport() {
        fileImportService.importFiles();
        return DataIEResponse.success("文件导入成功");
    }

}
