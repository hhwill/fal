package com.gingkoo.imas.hsbc.service;

import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import lombok.SneakyThrows;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.gingkoo.data.compute.api.ComputeUnit;
import com.gingkoo.data.compute.api.bean.Result;
import com.gingkoo.gpms.importer.CommonDataImporter;
import com.gingkoo.gpms.importer.job.bean.JobResult;
import com.gingkoo.gpms.platform.task.TaskManager;

@Component
public class HsbcAutoProcess implements ComputeUnit {

    private final Logger logger = LoggerFactory.getLogger(HsbcAutoProcess.class);

    private final HsbcFileImportService importService;
    private final JdbcTemplate jdbcTemplate;

    private final CustLoadFileService loadFileService;

    private final CustLoadFileProcessService fileProcessService;

    public HsbcAutoProcess(DataSource dataSource, HsbcFileImportService importService,
                           CustLoadFileService loadFileService, CustLoadFileProcessService fileProcessService){
        this.importService = importService;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        this.loadFileService = loadFileService;
        this.fileProcessService = fileProcessService;
    }

    @SneakyThrows
    @Override
    public Result call(Map<String, ?> parameters) {

        com.gingkoo.gpms.batch.entity.bean.JobResult jr = new com.gingkoo.gpms.batch.entity.bean.JobResult();
        jr.setErrCode("00");
        jr.setErrMsg("");
        logger.info("HsbcAutoProcess");

        //导数据
        try {
            importService.importFiles();
        }catch (Exception ex) {
            logger.info("import template failed", ex);
            return Result.of(Result.ERROR.getCode(), ex.getMessage());
        }
        try {
            loadFileService.run();
        } catch (Exception ex) {
            logger.info("import failed", ex);
            return Result.of(Result.ERROR.getCode(), ex.getMessage());
        }
        //满足条件，开始etl
        String now = jdbcTemplate.queryForObject("select workdate from ods_check", String.class);
        String errMsg = getCondition(0, now);
        if (!errMsg.equals("")) {
            jr.setErrCode("01");
            jr.setErrMsg(errMsg);
            return Result.of(Result.ERROR.getCode(), errMsg);
        }
        try {
            fileProcessService.initMap(now);
        } catch (Exception ex) {
            logger.info("initMap failed", ex);
            Result.of(Result.OK.getCode(), "success");
        }
        try {
            fileProcessService.process("GRKHXX", now, "OPS_BOS");
        } catch (Exception ex) {
            logger.info("GRKHXX failed", ex);
            Result.of(Result.OK.getCode(), "success");
        }
//        try {
//            fileProcessService.process("WCAS", now, "OPS_WCAS");
//        } catch (Exception ex) {
//            logger.info("WCAS failed", ex);
//            return JobResult.FAIL;
//        }
//        try {
//            fileProcessService.process("WPB", now, "WPB_CDO_team");
//        } catch (Exception ex) {
//            logger.info("WPB failed", ex);
//            return JobResult.FAIL;
//        }
//        try {
//            fileProcessService.process("WPB", now, "WPB_CDO_team");
//        } catch (Exception ex) {
//            logger.info("WPB failed", ex);
//            return JobResult.FAIL;
//        }
//        try {
//            fileProcessService.process("GTRF", now, "GTRF_Core_Trade");
//        } catch (Exception ex) {
//            logger.info("GTRF failed", ex);
//            return JobResult.FAIL;
//        }
        //都成功，调用"自动同步补录数据到后面的任务中
        return Result.of(Result.OK.getCode(), "success");
    }

    private String getCondition(int type, String workdate) {
        String result = "";

        String sql = "";
        if (type == 0) {
            sql = "select * from ods_check_template where odscheck = 1";
        } else {
            sql = "select * from ods_check_template where qccheck = 1";
        }
        List<Map<String, Object>> records = jdbcTemplate.queryForList(sql);
        String errMsg = "";
        for (Map<String, Object> record : records) {
            String tableName = record.get("TABLE_NAME").toString().toUpperCase();
            if (tableName.startsWith("IMAS_PM_")) {
                tableName = tableName.replace("IMAS_PM_", "IMAS_PM_"+workdate.substring(6,8) + "_");
            }
            sql = "select count(*) cnt from " + tableName + " where group_id = '" +
                    record.get("GROUP_ID").toString() + "' and "  +
                    record.get("WHERECLAUSE").toString().replace(":DATA_DATE", "'" + workdate + "'");
            int cnt = jdbcTemplate.queryForObject(sql, Integer.class);
            if (cnt == 0) {
                errMsg += record.get("ERRMSG").toString() + ";";
            }
        }
        return errMsg;
    }
}
