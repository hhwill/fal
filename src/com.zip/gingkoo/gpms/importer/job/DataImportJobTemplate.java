package com.gingkoo.gpms.importer.job;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.*;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.gingkoo.data.compute.api.bean.Result;
import com.gingkoo.gf4j2.framework.service.SysParamService;
import com.gingkoo.gf4j2.framework.service.base.BasFuncService;
import com.gingkoo.gpms.exporter.service.DataExportService;
import com.gingkoo.gpms.importer.entity.GpBmIdUploadlog;
import com.gingkoo.gpms.importer.entity.bean.ImportFieldConfig;
import com.gingkoo.gpms.importer.entity.bean.ImportFileConfig;
import com.gingkoo.gpms.importer.entity.bean.ImportMultiFileConfig;
import com.gingkoo.gpms.importer.excp.ImportFileJobException;
import com.gingkoo.gpms.importer.job.base.JobContext;
import com.gingkoo.gpms.importer.job.bean.Job;
import com.gingkoo.gpms.importer.job.bean.JobResult;
import com.gingkoo.gpms.importer.job.bean.JobStatus;
import com.gingkoo.gpms.importer.job.monitor.DataImportMonitor;
import com.gingkoo.gpms.importer.job.monitor.bean.DataImportProcess;
import com.gingkoo.gpms.importer.job.template.AbstractJobTemplate;
import com.gingkoo.gpms.importer.repository.HsbcUploadlogRepository;
import com.gingkoo.gpms.importer.service.DataImportProcessService;
import com.gingkoo.gpms.importer.service.DataImportService;
import com.gingkoo.gpms.util.DataComputeHelper;
import com.gingkoo.gpms.util.FileUtil;
import com.gingkoo.root.facility.datetime.ImmutableDateFormat;

import static java.lang.String.format;

import static com.gingkoo.gf4j2.framework.util.ExceptionUtil.throwCommonException;
import static com.gingkoo.gpms.importer.job.base.JobContext.TABLE_HEADER;

@Slf4j
@Component
public class DataImportJobTemplate extends AbstractJobTemplate {

    private static final String DATA_IMPORT_COMPUTE_JOB_PARAM = "__jobInfo__";

    final DataImportService dataImportService;

    final DataExportService dataExportService;

    final DataImportProcessService dataImportProcessService;

    final DataComputeHelper dataComputeHelper;

    final HsbcUploadlogRepository uploadlogRepository;

    @Value("${application.home}")
    String uploadPath;

    public DataImportJobTemplate(DataImportService dataImportService,
                                 DataExportService dataExportService,
                                 DataImportProcessService dataImportProcessService,
                                 DataComputeHelper dataComputeHelper, HsbcUploadlogRepository uploadlogRepository) {
        this.dataImportService = dataImportService;
        this.dataExportService = dataExportService;
        this.dataImportProcessService = dataImportProcessService;
        this.dataComputeHelper = dataComputeHelper;
        this.uploadlogRepository = uploadlogRepository;
    }

    @Override
    protected JobResult beforeImport(String jobId) {
        String sql = "UPDATE GP_BM_ID_UPLOADLOG SET FILLER1='导入执行中'  WHERE UPLOAD_GUID = :UPLOAD_GUID ";
        Map<String, Object> param = new HashMap<>();
        param.put("UPLOAD_GUID", jobId);
        dataImportService.executeUpdate(sql, param);
        return JobResult.SUCCESS;
    }

    /*
     * 加载配置并解析数据
     * */
    @Override
    protected JobResult beforeJob(Job job) {
        ImportMultiFileConfig multiFileConfig = job.getConfig();
        for (ImportFileConfig importFileConfig : multiFileConfig.getImportFileConfigs()) {
            callDataComputeJob("导入前任务", importFileConfig.getBeforeJobArgs(), job);
        }

        //初始化进度
        DataImportProcess dataImportProcess = job.getProcess();
        if (dataImportProcess.getStatus() != JobStatus.START) {
            dataImportProcess.toZero();
        }
        dataImportProcess.rsyncToDatabase();
        return JobResult.SUCCESS;
    }

    @Override
    protected JobResult afterJob(Job job, JobResult execResult) {
        DataImportProcess process = job.getProcess();
        try {
            File problemFile = null;
            if (!process.getProblemRecords().values().isEmpty()) {
                //问题文件生成
                problemFile = createProblemFile(job);
            }
            boolean problemFileExists = problemFile != null && problemFile.exists() && problemFile.length() > 0;
            JobResult jobResult;
            if (execResult == JobResult.SUCCESS) {
                process.setErrorMessage("导入完成" + (problemFileExists ? ",已生成错误文件，请下载确认" : ""));
                process.setStatus(JobStatus.DONE);
                jobResult = JobResult.SUCCESS;
            } else if (execResult == JobResult.FAIL) {
                process.setErrorMessage(execResult.getDesc() + (problemFileExists ? ",已生成错误文件，请下载确认" : ""));
                process.setStatus(JobStatus.BREAK);
                jobResult = JobResult.FAIL;
            } else if (execResult == JobResult.CANCEL) {
                process.setErrorMessage("导入取消" + (problemFileExists ? ",已生成错误文件" : ""));
                process.setStatus(JobStatus.CANCEL);
                jobResult = JobResult.CANCEL;
            } else {
                if (process.isTerminate()) {
                    process.setErrorMessage("导入取消" + (problemFileExists ? ",已生成错误文件" : ""));
                    process.setStatus(JobStatus.CANCEL);
                    jobResult = JobResult.CANCEL;
                } else if (process.getSumRow() == process.getProcessRow()) {
                    process.setErrorMessage("导入完成" + (problemFileExists ? ",已生成错误文件，请下载确认" : ""));
                    process.setStatus(JobStatus.DONE);
                    jobResult = JobResult.SUCCESS;
                } else {
                    process.setErrorMessage("导入失败，" + (problemFileExists ? ",已生成错误文件，请下载确认" : "数据已处理量与总量不符，请联系系统支持人员确认"));
                    process.setStatus(JobStatus.BREAK);
                    jobResult = JobResult.FAIL;
                }
            }

            ImportMultiFileConfig multiFileConfig = job.getConfig();
            for (ImportFileConfig importFileConfig : multiFileConfig.getImportFileConfigs()) {
                callDataComputeJob("导入后任务", importFileConfig.getAfterJobArgs(), job);
            }
            return jobResult;
        } finally {
            //更新结束时间保存进度至数据库
            process.setEndTime(new Date());
            process.rsyncToDatabase();
        }
    }

    @Override
    protected JobResult afterSuccessImport(String jobId) {
        GpBmIdUploadlog gpBmIdUploadlog = dataImportService.getGpBmIdUploadlogByGuid(jobId);
        String storeName = gpBmIdUploadlog.getStoreName();

        String targetFilePath = gpBmIdUploadlog.getTargetPath();
        // 导入完成后文件备份移走
        List<GpBmIdUploadlog> unImportFiles = uploadlogRepository.findByStoreNameAndFiller1(storeName, "未导入");
        if (unImportFiles.isEmpty()) {
            String path = uploadPath;
            String sourceDir = SysParamService.getSysParamDir(path, "GPMS|UPLOAD_PATH");
            if (StringUtils.isEmpty(sourceDir)) {
                sourceDir = uploadPath + File.separator + "upload";
            }
            String backupDir = SysParamService.getSysParamDir(path, "GPMS|BACKUP_PATH");
            if (StringUtils.isEmpty(backupDir)) {
                backupDir = uploadPath + File.separator + "backup";
            }
            File sourceFile = new File(sourceDir, storeName);
            if (storeName.endsWith(".zip")) {
                String zipPath = sourceFile.getPath();
                String savePath = zipPath.substring(0, zipPath.lastIndexOf(".")) + File.separator; //保存解压文件目录
                try {
                    FileUtil.deleteFolder(new File(savePath));
                } catch (Exception e) {
                    log.error("删除zip解压目录出错", e);
                    throw new ImportFileJobException("删除zip解压目录出错", e);
                }
            }

            String shortName = sourceFile.getAbsolutePath().substring(sourceFile.getParent().length() + 1);

            backupDir = (backupDir + File.separator +
                    ImmutableDateFormat.SIMPLE_DATE.format(new Date()) + File.separator);

            targetFilePath = backupDir + shortName + "." +
                    ImmutableDateFormat.SIMPLE_DATE_TIME.format(new Date());
            try {
                File backDir = new File(backupDir);
                Files.createDirectories(backDir.toPath());

                File targetFile = new File(targetFilePath);

                BasFuncService.moveFile(sourceFile, targetFile);
            } catch (IOException e) {
                log.error("备份上传文件出错", e);
            }
        }
        List<DataImportProcess> processList = DataImportMonitor.getInstance().getSubProcess(jobId);
        int totalRecord = processList.stream().map(DataImportProcess::getSumRow).reduce(0, Integer::sum);
        int errorRecord = processList.stream().map(DataImportProcess::getErrorRow).reduce(0, Integer::sum);
        String sql = "UPDATE GP_BM_ID_UPLOADLOG SET FILLER1='导入完成;总条数:" + totalRecord + ";更新失败:" + errorRecord
                + "',TARGET_PATH = :targetPath  WHERE UPLOAD_GUID = :UPLOAD_GUID ";
        Map<String, Object> param = new HashMap<>();
        param.put("UPLOAD_GUID", jobId);
        param.put("targetPath", targetFilePath);
        dataImportService.executeUpdate(sql, param);
        return JobResult.SUCCESS;
    }

    @Override
    protected JobResult afterFailImport(String jobId) {
        List<DataImportProcess> processList = DataImportMonitor.getInstance().getSubProcess(jobId);
        int totalRecord = processList.stream().map(DataImportProcess::getSumRow).reduce(0, Integer::sum);
        int errorRecord = processList.stream().map(DataImportProcess::getErrorRow).reduce(0, Integer::sum);
        String sql = "UPDATE GP_BM_ID_UPLOADLOG SET FILLER1='导入未完成;总条数:" + totalRecord + ";插入失败:" + errorRecord
                + "'  WHERE UPLOAD_GUID = :UPLOAD_GUID ";
        Map<String, Object> param = new HashMap<>();
        param.put("UPLOAD_GUID", jobId);
        dataImportService.executeUpdate(sql, param);
        return JobResult.FAIL;
    }

    //获取错误信息根据导出配置格式写入错误信息文件
    public File createProblemFile(Job job) {
        String path = uploadPath;
        String problemPath = SysParamService.getSysParamDir(path, "GPMS|PROBLEM_PATH");
        if (StringUtils.isEmpty(problemPath)) {
            problemPath = uploadPath + File.separator + "problem";
        }

        File problemDir = new File(problemPath);
        try {
            Files.createDirectories(problemDir.toPath());
        } catch (IOException e) {
            log.error("创建错误日志文件夹出错", e);
            throw new ImportFileJobException("创建错误日志文件夹出错");
        }

        File problemFile = new File(problemDir, job.getProcess().getGuid() + ".xlsx");

        try (Workbook wb = new XSSFWorkbook(); OutputStream out = new FileOutputStream(problemFile)) {
            List<ImportFileConfig> fileConfigs = job.getConfig().getImportFileConfigs()
                    .stream().sorted(Comparator.comparing(ImportFileConfig::getSheetNum)).collect(Collectors.toList());
            Map<String, List<Map<String, Object>>> problemRecordMap = job.getProcess().getProblemRecords();
            for (ImportFileConfig importFileConfig : fileConfigs) {
                //写入错误数据
                List<Map<String, Object>> records = problemRecordMap.get(importFileConfig.getTableName());
                if (records == null || records.isEmpty()) {
                    continue;
                }
                //读取源文件表头
                List<String> headerColumns = null;
                List<String> headerColumnNames = null;
                Map<String, List<String>> tableHeader = (Map<String, List<String>>) JobContext.getValue(TABLE_HEADER);
                if (tableHeader != null) {
                    List<String> headerList = tableHeader.get(importFileConfig.getTableName());
                    if (headerList != null && !headerList.isEmpty()) {
                        headerColumnNames = tableHeader.get(importFileConfig.getTableName());
                    }
                    if (headerColumnNames != null) {
                        List<ImportFieldConfig> fields = importFileConfig.getFieldConfigs();
                        headerColumns = headerColumnNames.stream().map(column -> {
                            for (ImportFieldConfig fieldConfig : fields) {
                                if (column.equals(fieldConfig.getColumnComments())) {
                                    return fieldConfig.getColumnName();
                                }
                            }
                            return column;
                        }).collect(Collectors.toList());
                    }
                }
                if (headerColumnNames == null) {
                    throw new ImportFileJobException("生成问题文件表头出错");
                }
                if (headerColumnNames.isEmpty()) {
                    headerColumns.add("ERROR_MESSAGE");
                    headerColumnNames = headerColumns;
                } else {
                    headerColumns.add("ERROR_MESSAGE");
                    headerColumnNames.add("错误信息");
                }
                int i = importFileConfig.getStartRow() > 1 ? importFileConfig.getStartRow() - 2 : 0;
                //写入表头
                String sheetName = StringUtils.isEmpty(importFileConfig.getTableComments()) ?
                        importFileConfig.getTableName() : importFileConfig.getTableComments();
                Sheet sheet = wb.createSheet(sheetName);
                Row header = sheet.createRow(i);
                i++;
                for (int j = 0; j < headerColumnNames.size(); j++) {
                    header.createCell(j).setCellValue(headerColumnNames.get(j));
                }

                for (Map<String, Object> record : records) {
                    Row row = sheet.createRow(i);
                    for (int j = 0; j < headerColumns.size(); j++) {
                        String columnName = headerColumns.get(j);
                        Object value = record.get(columnName);
                        row.createCell(j).setCellValue(Objects.toString(value, ""));
                    }
                    i++;
                }
            }
            wb.write(out);
        } catch (IOException e) {
            log.error("生成问题文件出错", e);
            throw new ImportFileJobException("生成问题文件出错", e);
        }
        return problemFile;
    }

    private void callDataComputeJob(String description, String argsStr, Job job) {
        if (StringUtils.isEmpty(argsStr)) {
            return;
        }
        Map<String, Object> parameters = new HashMap<>(JobContext.get());
        parameters.put(DATA_IMPORT_COMPUTE_JOB_PARAM, job);
        try {
            Result result = dataComputeHelper.callByExpression(description, argsStr, parameters);
            if (!result.isOk()) {
                String message = format("%s失败: %s-%s", description, result.getCode(), result.getMessage());
                log.error(message);
                throwCommonException(message);
            }
        } catch (Exception e) {
            log.error("{}处理异常", description, e);
            throw new ImportFileJobException(description + "处理异常[" + e.getMessage() + "]", e);
        }
    }


}
