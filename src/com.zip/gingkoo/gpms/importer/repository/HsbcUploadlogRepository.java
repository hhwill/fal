package com.gingkoo.gpms.importer.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gingkoo.gpms.importer.entity.GpBmIdUploadlog;
import com.gingkoo.root.facility.spring.data.jpa.JpaDslRepository;

@Repository
public interface HsbcUploadlogRepository extends JpaDslRepository<GpBmIdUploadlog, String> {
    List<GpBmIdUploadlog> findByStoreNameAndFiller1(String storeName, String filler1);
}
