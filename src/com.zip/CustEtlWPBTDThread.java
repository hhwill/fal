package com.gingkoo.imas.hsbc.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import static com.gingkoo.imas.hsbc.service.EtlUtils.*;

public class CustEtlWPBTDThread implements Callable<List<List<List<String>>>> {

    private final Logger logger = LoggerFactory.getLogger(CustEtlWPBTDThread.class);

    private final JdbcTemplate jdbcTemplate;

    private Integer pageSize;

    private Integer pageIndex;

    private String sql;

    private String rptDate;

    public CustEtlWPBTDThread(DataSource dataSource, String sql, int pageSize, int pageIndex,
                              String rptDate) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        this.pageSize = pageSize;
        this.pageIndex = pageIndex;
        this.sql = sql;
        this.rptDate = rptDate;
    }

    @Override
    public List<List<List<String>>> call() {
        List<List<List<String>>> result = new ArrayList<List<List<String>>>();
        List<List<String>> grckjc = new ArrayList<List<String>>();
        List<List<String>> grckye = new ArrayList<List<String>>();
        List<List<String>> grckfs = new ArrayList<List<String>>();
        String mysql = String.format(sql + " limit %d, %d" , pageIndex * pageSize, pageSize);
        List<Map<String, Object>> records = jdbcTemplate.queryForList(mysql);
        for (Map<String, Object> src : records) {
            String ZGCUCL = getString(src.get("ZGCUCL"));
            if (!ZGCUCL.equals("OPR") ||!ZGCUCL.equals("RCC") ||!ZGCUCL.equals("SJL")
                    ||!ZGCUCL.equals("SSL") ||!ZGCUCL.equals("STL") ||!ZGCUCL.equals("STS") ) {
                continue;
            }
            String TDAPTY = getString(src.get("TDAPTY"));
            String TDTERM = getString(src.get("TDTERM"));
            String type = "";
            if (TDAPTY.equals("TDI") || TDAPTY.equals("TD1") || TDAPTY.equals("TD2") || TDAPTY.equals("TD4") ||
                    TDAPTY.equals("TD9") ||TDAPTY.equals("TMD") ||TDAPTY.equals("TD5") ||TDAPTY.equals("CD4") ) {
                type = "DQCK";
            } else if (TDAPTY.equals("D01") || TDAPTY.equals("D02") || TDAPTY.equals("D03") || TDAPTY.equals("D04") ||
                    TDAPTY.equals("D41") ||TDAPTY.equals("D42") ||TDAPTY.equals("D43") ) {
                type = "JGXCK";
            }
            if (type.equals("")) {
                continue;
            }
            List<List<String>> ckxx = getCKXH(src);
            List<String> subgrckjc = new ArrayList<String>();
            List<String> subgrckye = new ArrayList<String>();
            List<String> subgrckfs = new ArrayList<String>();
            subgrckjc.add(rptDate);
            subgrckjc.add(formatCKZHBH(src.get("TDACB"),src.get("TDACS"),src.get("TDACX")));
            subgrckjc.add("01");
            subgrckjc.add(formatNBJGH(src.get("TDACB")));
            subgrckjc.add(getString(src.get("CUS")));
            subgrckjc.add(getMap("WPB_CKCPLB", src.get("TDAPTY")));
            subgrckjc.add(getString(src.get("TDSTDT")));
            subgrckjc.add(getString(src.get("TDDUDT")));
            if (type.equals("DQCK")) {
                if (TDTERM.equals("0000")) {
                    subgrckjc.add("19990101");
                } else if (TDTERM.equals("7D")) {
                    subgrckjc.add("19990107");
                } else {
                    subgrckjc.add("");
                }
            } else {
                subgrckjc.add("");
            }
            if (getString(src.get("TDSTUS")).equals("5")) {
                if (type.equals("DQCK")) {
                    subgrckjc.add(getMap("WPB_CLOSEDAC",
                            getString(src.get("TDACB")) + getString(src.get("TDACS")) +
                                    getString(src.get("TDACX") + getString(src.get("TDCYCD")))));
                } else {
                    subgrckjc.add(getString(src.get("TDDUDT")));
                }
            } else {
                subgrckjc.add("");
            }
            if (type.equals("DQCK")) {
                if (TDTERM.equals("7D")) {
                    subgrckjc.add("02");
                } else if (TDTERM.equals("1M")) {
                    subgrckjc.add("03");
                } else if (TDTERM.equals("3M")) {
                    subgrckjc.add("05");
                } else if (TDTERM.equals("6M")) {
                    subgrckjc.add("07");
                } else if (TDTERM.equals("12M")) {
                    subgrckjc.add("09");
                } else if (TDTERM.equals("24M")) {
                    subgrckjc.add("11");
                } else if (TDTERM.equals("36M")) {
                    subgrckjc.add("13");
                } else if (TDTERM.equals("60M")) {
                    subgrckjc.add("15");
                } else {
                    subgrckjc.add("");
                }
            } else {
                int days = differentDaysByMillisecond(src.get("TDDUDT"), src.get("TDSTUS"));
                if (TDTERM.equals("0000") && (TDAPTY.equals("D01") ||TDAPTY.equals("D02") ||TDAPTY.equals("D03")
                        ||TDAPTY.equals("D04"))) {
                    if (days < 31) {
                        subgrckjc.add("02");
                    } else if (days == 31) {
                        subgrckjc.add("03");
                    } else {
                        subgrckjc.add("04");
                    }
                    //TODO
                } else if (TDAPTY.equals("D41") && TDTERM.equals("30D")) {
                    subgrckjc.add("04");
                }
            }
            if (type.equals("DQCK")) {
                subgrckjc.add("TR07");
            } else {
                subgrckjc.add("");
            }
            if (type.equals("DQCK")) {
                subgrckjc.add("RF01");
            } else {
                subgrckjc.add("RF02");
            }
            //实际利率
            if (type.equals("DQCK")) {
                subgrckjc.add(getString(src.get("TDCNTR")));
            } else {
                subgrckjc.add("");
            }
            subgrckjc.add("");
            subgrckjc.add("");
            subgrckjc.add("");
            subgrckjc.add("");
            //开户渠道
            if (type.equals("DQCK")) {
                if (getString(src.get("TDMIN1")).contains("IB")) {
                    subgrckjc.add("02");
                } else {
                    subgrckjc.add("01");
                }
            } else {
                if (TDAPTY.equals("D41") || ((TDAPTY.equals("D42") || TDAPTY.equals("D43")) &&
                        getString(src.get("TDMIN3")).equals("")) ||
                        ((TDAPTY.equals("D01") || TDAPTY.equals("D02")||TDAPTY.equals("D03") || TDAPTY.equals("D04"))
                                && getString(src.get("TDCHID")).equals("OHB")) ) {
                    subgrckjc.add("01");
                } else if (((TDAPTY.equals("D01") || TDAPTY.equals("D02")||TDAPTY.equals("D03") || TDAPTY.equals("D04"))
                        && getString(src.get("TDCHID")).equals("OHI")) ||
                        ((TDAPTY.equals("D42") || TDAPTY.equals("D43")) && !(getString(src.get("TDMIN3")).equals("")))) {
                    subgrckjc.add("02");
                } else {
                    subgrckjc.add("01");
                }
            }
            subgrckjc.add("N");
            String ccy = getString(src.get("TDCYCD"));
            if (ccy.equals("CNY")) {
                subgrckjc.add("");
            } else {
                //usd >=300W then A else B
                if (ccy.equals("EUR") || ccy.equals("HKD") || ccy.equals("JPY")) {
                    String currate = getMap("RATE", ccy +"/USD");
                    if (!currate.equals("")) {
                        BigDecimal x = new BigDecimal(getString(src.get("LEDGER"))).multiply(new BigDecimal(currate));
                        if (x.compareTo(new BigDecimal("3000000")) > -1) {
                            subgrckjc.add("A");
                        } else {
                            subgrckjc.add("B");
                        }
                    } else {
                        subgrckjc.add("");
                    }
                } else {
                    subgrckjc.add("");
                }
            }
            grckjc.add(subgrckjc);

            subgrckye.add(rptDate);
            subgrckye.add(formatCKZHBH(src.get("TDACB"),src.get("TDACS"),src.get("TDACX")));
            subgrckye.add("01");
            subgrckye.add(formatNBJGH(src.get("TDACB")));
            subgrckye.add(getString(src.get("CUS")));
            subgrckye.add(getString(src.get("TDCYCD")));
            subgrckye.add(formatJPY(src.get("TDCYCD"), src.get("LEDGER")));
            grckye.add(subgrckye);

            subgrckfs.add(rptDate);
            subgrckfs.add(formatCKZHBH(src.get("TDACB"),src.get("TDACS"),src.get("TDACX")));
            subgrckfs.add("01");
            subgrckfs.add(formatNBJGH(src.get("TDACB")));
            subgrckfs.add(getString(src.get("CUS")));
            //TODO 交易流水号
            subgrckfs.add("");
            subgrckfs.add(getString(src.get("THCPDT")));
            subgrckfs.add("");
            if (type.equals("DQCK")) {
                subgrckfs.add(getString(src.get("TDCNTR")));
            } else {
                subgrckfs.add("");
            }
            subgrckfs.add(getString(src.get("TDCYCD")));
            subgrckfs.add(getString(src.get("TRANAMT")));
            //交易渠道
            if (type.equals("DQCK")) {
                if (getString(src.get("TDMIN1")).startsWith("HIB")) {
                    subgrckfs.add("04");
                } else {
                    subgrckfs.add("01");
                }
            } else {
                if (TDAPTY.equals("D41") || ((TDAPTY.equals("D42") || TDAPTY.equals("D43")) &&
                        getString(src.get("TDMIN3")).equals("")) ||
                        ((TDAPTY.equals("D01") || TDAPTY.equals("D02")||TDAPTY.equals("D03") || TDAPTY.equals("D04"))
                                && getString(src.get("TDCHID")).equals("OHB")) ) {
                    subgrckfs.add("01");
                } else if (((TDAPTY.equals("D01") || TDAPTY.equals("D02")||TDAPTY.equals("D03") || TDAPTY.equals("D04"))
                        && getString(src.get("TDCHID")).equals("OHI")) ||
                        ((TDAPTY.equals("D42") || TDAPTY.equals("D43")) && getString(src.get("TDMIN3")).equals("NET"))) {
                    subgrckfs.add("03");
                } else if (((TDAPTY.equals("D01") || TDAPTY.equals("D02")||TDAPTY.equals("D03") || TDAPTY.equals("D04"))
                        && getString(src.get("TDCHID")).equals("MOB")) ||
                        ((TDAPTY.equals("D42") || TDAPTY.equals("D43")) && getString(src.get("TDMIN3")).equals(
                                "Mobile"))) {
                    subgrckfs.add("04");
                } else {
                    subgrckfs.add("01");
                }
            }
            if (new BigDecimal(getString(src.get("TRANAMT"))).compareTo(new BigDecimal("0")) > 0) {
                subgrckfs.add("1");
            } else {
                subgrckfs.add("0");
            }
            if (ccy.equals("CNY")) {
                subgrckjc.add("");
            } else {
                //usd >=300W then A else B
                if (ccy.equals("EUR") || ccy.equals("HKD") || ccy.equals("JPY")) {
                    String currate = getMap("RATE", ccy +"/USD");
                    if (!currate.equals("")) {
                        BigDecimal x = new BigDecimal(getString(src.get("TRANAMT"))).multiply(new BigDecimal(currate));
                        if (x.compareTo(new BigDecimal("3000000")) > -1) {
                            subgrckjc.add("A");
                        } else {
                            subgrckjc.add("B");
                        }
                    } else {
                        subgrckjc.add("");
                    }
                } else {
                    subgrckjc.add("");
                }
            }
            grckfs.add(subgrckfs);
        }
        result.add(grckjc);
        result.add(grckye);
        result.add(grckfs);
        return result;
    }
}
