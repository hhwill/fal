package com.gingkoo.imas.hsbc.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import static com.gingkoo.imas.hsbc.service.EtlUtils.*;

public class CustEtlWPBTDThread implements Callable<List<List<List<String>>>> {

    private final Logger logger = LoggerFactory.getLogger(CustEtlWPBTDThread.class);

    private final JdbcTemplate jdbcTemplate;

    private Integer pageSize;

    private Integer pageIndex;

    private String sql;

    private String rptDate;

    public CustEtlWPBTDThread(DataSource dataSource, String sql, int pageSize, int pageIndex,
                              String rptDate) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        this.pageSize = pageSize;
        this.pageIndex = pageIndex;
        this.sql = sql;
        this.rptDate = rptDate;
    }

    @Override
    public List<List<List<String>>> call() {
        List<List<List<String>>> result = new ArrayList<List<List<String>>>();
        List<List<String>> grckjc = new ArrayList<List<String>>();
        List<List<String>> grckye = new ArrayList<List<String>>();
        String mysql = String.format(sql + " limit %d, %d" , pageIndex * pageSize, pageSize);
        List<Map<String, Object>> records = jdbcTemplate.queryForList(mysql);
        for (Map<String, Object> src : records) {
            List<List<String>> ckxx = getCKXH(src);
            List<String> subgrckjc = new ArrayList<String>();
            List<String> subgrckye = new ArrayList<String>();
            subgrckjc.add(rptDate);
            subgrckjc.add(formatCKZHBH(src.get("DFACB"),src.get("DFACS"),src.get("DFACX")));
            subgrckjc.add("01");
            subgrckjc.add(formatNBJGH(src.get("DFDCB")));
            subgrckjc.add(getString(src.get("CUS")));
            subgrckjc.add(getMap("WPB_CKCPLB", src.get("DFAPTY")));
            subgrckjc.add(getString(src.get("DFDTAO")));
            subgrckjc.add("");
            subgrckjc.add("");
            if (getString(src.get("TDSTUS")).equals("5")) {
                subgrckjc.add(getMap("WPB_CLOSEDAC",
                        getString(src.get("TDACB"))+getString(src.get("TDACS"))+
                                getString(src.get("TDACX")+getString(src.get("TDCYCD")))));
            } else {
                subgrckjc.add("");
            }
            subgrckjc.add("01");
            subgrckjc.add("TR07");
            subgrckjc.add("RF01");
            //实际利率
            subgrckjc.add(ckxx.get(0).get(0));
            subgrckjc.add("");
            subgrckjc.add("");
            subgrckjc.add("");
            subgrckjc.add("");
            //开户渠道
            subgrckjc.add("01");
            subgrckjc.add("N");
            String ccy = getString(src.get("DFCYCD"));
            if (ccy.equals("CNY")) {
                subgrckjc.add("");
            } else {
                //usd >=300W then A else B
                if (ccy.equals("EUR") || ccy.equals("HKD") || ccy.equals("JPY")) {
                    String currate = getMap("RATE", ccy +"/USD");
                    if (!currate.equals("")) {
                        BigDecimal x = new BigDecimal(getString(src.get("LEDGER"))).multiply(new BigDecimal(currate));
                        if (x.compareTo(new BigDecimal("3000000")) > -1) {
                            subgrckjc.add("A");
                        } else {
                            subgrckjc.add("B");
                        }
                    } else {
                        subgrckjc.add("");
                    }
                } else {
                    subgrckjc.add("");
                }
            }
            grckjc.add(subgrckjc);

            subgrckye.add(rptDate);
            subgrckye.add(formatCKZHBH(src.get("DFACB"),src.get("DFACS"),src.get("DFACX")));
            subgrckye.add("01");
            subgrckye.add(formatNBJGH(src.get("DFDCB")));
            subgrckye.add(getString(src.get("CUS")));
            subgrckye.add(getString(src.get("DFCYCD")));
            subgrckye.add(formatJPY(src.get("DFCYCD"), src.get("LEDGER")));
            grckye.add(subgrckye);

        }
        result.add(grckjc);
        result.add(grckye);
        return result;
    }
}
