package com.gingkoo.imas.hsbc.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import static com.gingkoo.imas.hsbc.service.EtlConst.*;
import static com.gingkoo.imas.hsbc.service.EtlUtils.*;

@Slf4j
@Component
public class CustEtlWPB {

    private final EtlInsertService insertService;

    private final JdbcTemplate jdbcTemplate;

    private final DataSource dataSource;

    private int threadSize;

    private int pageSize;

    public CustEtlWPB(EtlInsertService insertService, DataSource dataSource) {
        this.insertService = insertService;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        this.dataSource = dataSource;
        threadSize = 10;
        pageSize = 1000;
    }


    public void test1(String now, String group_id) {
        ExecutorService execservice = Executors.newFixedThreadPool(threadSize);
        String sql = "select * from corpddacp2 where data_date = '"+now+"' and group_id = '"+group_id+"'";
        CompletionService<List<List<List<String>>>> completionService = new ExecutorCompletionService<List<List<List<String>>>>(execservice);
        String querySql = "SELECT COUNT(1) FROM (" + sql + ")";
        Integer totalCount = jdbcTemplate.queryForObject(querySql, Integer.class);
        int times = totalCount / pageSize;
        if (totalCount % pageSize != 0) {
            times += 1;
        }
        int bindex = 0;
        List<Callable<List<List<List<String>>>>> tasks = new ArrayList<Callable<List<List<List<String>>>>>();
        for (int i = 0; i < times; i++) {
            Callable<List<List<List<String>>>> qfe = new CustEtlWPBDDThread(dataSource, sql,
                    pageSize, bindex, now);
            tasks.add(qfe);
            bindex++;
        }
        try {
            for (int i = 0; i < tasks.size(); i++) {
                completionService.submit(tasks.get(i));
            }
            for (int i = 0; i < tasks.size(); i++) {
                List<List<List<String>>> datas = completionService.take().get();

            }
        } catch (Exception ex) {
            log.error("ods2pm failed", ex);
        }
    }

    public void test() {
        List<List<String>> dwckjc = new ArrayList<List<String>>();
        List<String> r = new ArrayList<String>();
        r.add("20210531");
        r.add("20210531");
        r.add("01");
        r.add("20210531");
        r.add("20210531");
        r.add("D011");
        r.add("");
        r.add("20210531");
        r.add("");
        r.add("");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        dwckjc.add(r);
        insertService.insertData(SQL_DWCKJC, "a", "a", dwckjc);
    }
}
