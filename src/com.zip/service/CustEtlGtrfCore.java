package com.gingkoo.imas.hsbc.service;

import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;

import com.gingkoo.root.facility.spring.tx.TransactionHelper;

@Component
public class CustEtlGtrfCore {

    private final Logger logger = LoggerFactory.getLogger(CustEtlGRKHXX.class);

    private final EtlInsertService insertService;

    private final JdbcTemplate jdbcTemplate;

    private final TransactionHelper transactionTemplate;

    private CustEtlPJTXGtrfCore etlPJTXGtrfCore;
    private CustEtlTYJDGtrfCore etlTYJDGtrfCore;
    private CustEtlDWDKGtrfCore etlDWDKGtrfCore;
    private CustEtlDWDKSCSAIGtrfCore etlDWDKSCSAIGtrfCore;

    public CustEtlGtrfCore(CustEtlPJTXGtrfCore etlPJTXGtrfCore, CustEtlTYJDGtrfCore etlTYJDGtrfCore,
                           CustEtlDWDKGtrfCore etlDWDKGtrfCore,
                           CustEtlDWDKSCSAIGtrfCore etlDWDKSCSAIGtrfCore,EtlInsertService insertService, TransactionHelper transactionTemplate, DataSource dataSource) {
        this.etlPJTXGtrfCore = etlPJTXGtrfCore;
        this.etlTYJDGtrfCore = etlTYJDGtrfCore;
        this.etlDWDKGtrfCore = etlDWDKGtrfCore;
        this.etlDWDKSCSAIGtrfCore = etlDWDKSCSAIGtrfCore;
        this.insertService = insertService;
        this.transactionTemplate = transactionTemplate;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public boolean processFTY(String now, String group_id) throws Exception {
        logger.info(">>>Start GTRFCORE FTY " + now + " " + group_id);
        String day = now.substring(6,8);
        String sql = String.format("delete from imas_ODS_"+day+"_dwdkjc where sjrq = '%s' and group_id = '%s'", now,
                group_id);
        jdbcTemplate.update(sql);
        sql = String.format("delete from imas_ODS_"+day+"_dwdkye where sjrq = '%s' and group_id = '%s'", now,
                group_id);
        jdbcTemplate.update(sql);
        sql = String.format("delete from imas_ODS_"+day+"_dwdkfk where sjrq = '%s' and group_id = '%s'", now,
                group_id);
        jdbcTemplate.update(sql);

        etlDWDKGtrfCore.process(now, group_id);
        etlDWDKSCSAIGtrfCore.process(now, group_id);
        return true;
    }

    public boolean processAll(String now, String group_id) throws Exception {
        logger.info(">>>Start GTRFCORE " + now + " " + group_id);
        String day = now.substring(6,8);
        String sql = String.format("delete from imas_ods_"+day+"_tyjdjc where sjrq = '%s' and group_id = '%s'", now,
                group_id);
        jdbcTemplate.update(sql);
        sql = String.format("delete from imas_ods_"+day+"_tyjdye where sjrq = '%s' and group_id = '%s'", now,
                group_id);
        jdbcTemplate.update(sql);
        sql = String.format("delete from imas_ods_"+day+"_tyjdfs where sjrq = '%s' and group_id = '%s'", now,
                group_id);
        jdbcTemplate.update(sql);
        sql = String.format("delete from imas_ODS_"+day+"_pjtxjc where sjrq = '%s' and group_id = '%s'", now,
                group_id);
        jdbcTemplate.update(sql);
        sql = String.format("delete from imas_ODS_"+day+"_pjtxye where sjrq = '%s' and group_id = '%s'", now,
                group_id);
        jdbcTemplate.update(sql);
        sql = String.format("delete from imas_ODS_"+day+"_pjtxfs where sjrq = '%s' and group_id = '%s'", now,
                group_id);
        jdbcTemplate.update(sql);
        sql = String.format("delete from imas_ODS_"+day+"_dwdkjc where sjrq = '%s' and group_id = '%s'", now,
                group_id);
        jdbcTemplate.update(sql);
        sql = String.format("delete from imas_ODS_"+day+"_dwdkye where sjrq = '%s' and group_id = '%s'", now,
                group_id);
        jdbcTemplate.update(sql);
        sql = String.format("delete from imas_ODS_"+day+"_dwdkfk where sjrq = '%s' and group_id = '%s'", now,
                group_id);
        jdbcTemplate.update(sql);
        etlPJTXGtrfCore.process(now, group_id);
        etlDWDKGtrfCore.process(now, group_id);
        etlTYJDGtrfCore.process(now, group_id);
        etlDWDKSCSAIGtrfCore.process(now, group_id);
        return true;
    }

    private void execUpdSqlCommit(String sql) {
        transactionTemplate.run(Propagation.REQUIRES_NEW, () -> {
            jdbcTemplate.update(sql);
        });
    }
}
