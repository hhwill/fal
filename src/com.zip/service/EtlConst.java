package com.gingkoo.imas.hsbc.service;

public class EtlConst {

    public static String SQL_PJTXFS = "INSERT INTO `IMAS_ODS_%s_PJTXFS`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`NBJGH`,\n" +
            "`KHH`,\n" +
            "`YWBM`,\n" +
            "`JYLSH`,\n" +
            "`BZ`,\n" +
            "`JYRQ`,\n" +
            "`FSJE`,\n" +
            "`TXLL`,\n" +
            "`JYFX`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";
    public static String SQL_PJTXJC = "INSERT INTO `IMAS_ODS_%s_PJTXJC`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`NBJGH`,\n" +
            "`KHH`,\n" +
            "`JRJGLXDM`,\n" +
            "`YWBM`,\n" +
            "`PJRZYWLX`,\n" +
            "`QSRQ`,\n" +
            "`DQRQ`,\n" +
            "`PJRZQXLX`,\n" +
            "`TXLL`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";
    public static String SQL_PJTXYE = "INSERT INTO `IMAS_ODS_%s_PJTXYE`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`NBJGH`,\n" +
            "`KHH`,\n" +
            "`YWBM`,\n" +
            "`BZ`,\n" +
            "`YE`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";
    public static String SQL_TYJDFS = "INSERT INTO `IMAS_ODS_%s_TYJDFS`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`YWBM`,\n" +
            "`NBJGH`,\n" +
            "`KHH`,\n" +
            "`JYLSH`,\n" +
            "`JYRQ`,\n" +
            "`BZ`,\n" +
            "`SJLL`,\n" +
            "`JZLL`,\n" +
            "`FSJE`,\n" +
            "`JYFX`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?," +
            "?," +
            "?)";
    public static String SQL_TYJDJC = "INSERT INTO `IMAS_ODS_%s_TYJDJC`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`NBJGH`,\n" +
            "`KHH`,\n" +
            "`JRJGLXDM`,\n" +
            "`YWBM`,\n" +
            "`JDYWLX`,\n" +
            "`QSRQ`,\n" +
            "`DQRQ`,\n" +
            "`SJZZRQ`,\n" +
            "`TYJDQXLX`,\n" +
            "`LLLX`,\n" +
            "`SJLL`,\n" +
            "`JDDJJZLX`,\n" +
            "`JZLL`,\n" +
            "`JXFS`,\n" +
            "`LLFDPL`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?," +
            "?)";

    public static String SQL_TYJDJC_UPDATE = "update IMAS_ODS_%s_TYJDJC set RSV5 = ? where YWBM = ? and SJRQ = ?";

    public static String SQL_TYJDJC_GMO = "INSERT INTO `IMAS_ODS_%s_TYJDJC`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`NBJGH`,\n" +
            "`KHH`,\n" +
            "`JRJGLXDM`,\n" +
            "`YWBM`,\n" +
            "`JDYWLX`,\n" +
            "`QSRQ`,\n" +
            "`DQRQ`,\n" +
            "`SJZZRQ`,\n" +
            "`TYJDQXLX`,\n" +
            "`LLLX`,\n" +
            "`SJLL`,\n" +
            "`JDDJJZLX`,\n" +
            "`JZLL`,\n" +
            "`JXFS`,\n" +
            "`LLFDPL`,\n" +
            "`RSV5`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?," +
            "?," +
            "?)";

    public static String SQL_TYJDYE = "INSERT INTO `IMAS_ODS_%s_TYJDYE`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`YWBM`,\n" +
            "`NBJGH`,\n" +
            "`KHH`,\n" +
            "`BZ`,\n" +
            "`YE`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";
    public static String SQL_DWDKFK = "INSERT INTO `IMAS_ODS_%s_DWDKFK`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`DKJJBH`,\n" +
            "`KHH`,\n" +
            "`NBJGH`,\n" +
            "`JYLSH`,\n" +
            "`JYRQ`,\n" +
            "`BZ`,\n" +
            "`FSJE`,\n" +
            "`JZLL`,\n" +
            "`SJLL`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";
    public static String SQL_DWDKJC = "INSERT INTO `IMAS_ODS_%s_DWDKJC`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`DKHTBM`,\n" +
            "`DKJJBH`,\n" +
            "`DKCPLB`,\n" +
            "`KHH`,\n" +
            "`NBJGH`,\n" +
            "`DKFFRQ`,\n" +
            "`YSDQRQ`,\n" +
            "`SJZZRQ`,\n" +
            "`DKQXLX`,\n" +
            "`LLLX`,\n" +
            "`DJJZLX`,\n" +
            "`JZLL`,\n" +
            "`SJLL`,\n" +
            "`LLFDPL`,\n" +
            "`DKSJTX`,\n" +
            "`DKBLQD`,\n" +
            "`CZBL`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0'," +
            "?,?,?)";
    public static String SQL_DWDKYE = "INSERT INTO `IMAS_ODS_%s_DWDKYE`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`DKJJBH`,\n" +
            "`KHH`,\n" +
            "`NBJGH`,\n" +
            "`BZ`,\n" +
            "`DKYE`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";
    public static String SQL_GRKHXX = "INSERT INTO `IMAS_ODS_%s_GRKHXX`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`RSV5`,\n" +
            "`SJRQ`,\n" +
            "`KHH`,\n" +
            "`NBJGH`,\n" +
            "`CZDHZQHDM`,\n" +
            "`SXED`,\n" +
            "`YYED`,\n" +
            "`KHXL`,\n" +
            "`NHBZ`,\n" +
            "`GROUP_ID`,\n" +
            "`C_RSV1`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`\n" +
            ") VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";
    public static String SQL_DGKHXX = "INSERT INTO `IMAS_ODS_%s_DGKHXX`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`KHH`,\n" +
            "`NBJGH`,\n" +
            "`GMJJBMFL`,\n" +
            "`JRJGLXDM`,\n" +
            "`QYGM`,\n" +
            "`KGLX`,\n" +
            "`JNJWBZ`,\n" +
            "`JYSZDHZQHDM`,\n" +
            "`ZCDZ`,\n" +
            "`SXED`,\n" +
            "`YYED`,\n" +
            "`SSHY`,\n" +
            "`NCCSBZ`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";

    public static String SQL_DWCKJC = "INSERT INTO `IMAS_ODS_%s_DWCKJC`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`CKZHBM`,\n" +
            "`CKXH`,\n" +
            "`NBJGH`,\n" +
            "`KHH`,\n" +
            "`CKCPLB`,\n" +
            "`XYCKLX`,\n" +
            "`QSRQ`,\n" +
            "`DQRQ`,\n" +
            "`SJZZRQ`,\n" +
            "`CKQXLX`,\n" +
            "`DJJZLX`,\n" +
            "`LLLX`,\n" +
            "`SJLL`,\n" +
            "`JZLL`,\n" +
            "`LLFDPL`,\n" +
            "`BDSYL`,\n" +
            "`ZGSYL`,\n" +
            "`KHQD`,\n" +
            "`YDCKBZ`,\n" +
            "`DXEBZ`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00'," +
            "'A','2','0',?,?,?)";

    public static String SQL_DWCKYE = "INSERT INTO `IMAS_ODS_%s_DWCKYE`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`CKZHBM`,\n" +
            "`CKXH`,\n" +
            "`NBJGH`,\n" +
            "`KHH`,\n" +
            "`BZ`,\n" +
            "`CKYE`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";

    public static String SQL_TYCKJC = "INSERT INTO `IMAS_ODS_%s_TYCKJC`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`NBJGH`,\n" +
            "`KHH`,\n" +
            "`JRJGLXDM`,\n" +
            "`CKZHBM`,\n" +
            "`CFYWLX`,\n" +
            "`QSRQ`,\n" +
            "`DQRQ`,\n" +
            "`CKQXLX`,\n" +
            "`DJJZLX`,\n" +
            "`LLLX`,\n" +
            "`SJLL`,\n" +
            "`JZLL`,\n" +
            "`LLFDPL`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";

    public static String SQL_TYCKJC_UPDATE = "update IMAS_ODS_%s_TYCKJC set RSV5 = ? where CKZHBM = ? and SJRQ = ?";
    public static String SQL_TYCKJC_GMO = "INSERT INTO `IMAS_ODS_%s_TYCKJC`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`NBJGH`,\n" +
            "`KHH`,\n" +
            "`JRJGLXDM`,\n" +
            "`CKZHBM`,\n" +
            "`CFYWLX`,\n" +
            "`QSRQ`,\n" +
            "`DQRQ`,\n" +
            "`CKQXLX`,\n" +
            "`DJJZLX`,\n" +
            "`LLLX`,\n" +
            "`SJLL`,\n" +
            "`JZLL`,\n" +
            "`LLFDPL`,\n" +
            "`RSV5`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";

    public static String SQL_TYCKYE = "INSERT INTO `IMAS_ODS_%s_TYCKYE`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`CKZHBM`,\n" +
            "`NBJGH`,\n" +
            "`KHH`,\n" +
            "`BZ`,\n" +
            "`YE`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";

    public static String SQL_TYCKFS = "INSERT INTO `IMAS_ODS_%s_TYCKFS`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`CKZHBM`,\n" +
            "`NBJGH`,\n" +
            "`KHH`,\n" +
            "`JYLSH`,\n" +
            "`JYRQ`,\n" +
            "`BZ`,\n" +
            "`SJLL`,\n" +
            "`JZLL`,\n" +
            "`FSJE`,\n" +
            "`JYFX`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";

    public static String SQL_DWCKFS = "INSERT INTO `IMAS_ODS_%s_DWCKFS`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`CKZHBM`,\n" +
            "`CKXH`,\n" +
            "`NBJGH`,\n" +
            "`KHH`,\n" +
            "`JYLSH`,\n" +
            "`JYRQ`,\n" +
            "`SJLL`,\n" +
            "`JZLL`,\n" +
            "`BZ`,\n" +
            "`FSJE`,\n" +
            "`JYQD`,\n" +
            "`JYFX`,\n" +
            "`DXEBZ`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";

    public static String SQL_GRCKJC = "INSERT INTO `IMAS_ODS_%s_GRCKJC`\n" +
            "            (`DATA_ID`,\n" +
            "            `DATA_RPT_DATE`,\n" +
            "            `ORG_ID`,\n" +
            "            `RSV1`,\n" +
            "            `SJRQ`,\n" +
            "            `CKZHBM`,\n" +
            "            `CKXH`,\n" +
            "            `NBJGH`,\n" +
            "            `KHH`,\n" +
            "            `CKCPLB`,\n" +
            "            `QSRQ`,\n" +
            "            `DQRQ`,\n" +
            "            `SJZZRQ`,\n" +
            "            `CKQXLX`,\n" +
            "            `DJJZLX`,\n" +
            "            `LLLX`,\n" +
            "            `SJLL`,\n" +
            "            `JZLL`,\n" +
            "            `LLFDPL`,\n" +
            "            `BDSYL`,\n" +
            "            `ZGSYL`,\n" +
            "            `KHQD`,\n" +
            "            `YDCKBZ`,\n" +
            "            `DXEBZ`,\n" +
            "            `GROUP_ID`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A'," +
            "'2','0',?,?,?)";

    public static String SQL_GRCKYE = "INSERT INTO `IMAS_ODS_%s_GRCKYE`\n" +
            "            (`DATA_ID`,\n" +
            "            `DATA_RPT_DATE`,\n" +
            "            `ORG_ID`,\n" +
            "            `RSV1`,\n" +
            "            `SJRQ`,\n" +
            "            `CKZHBM`,\n" +
            "            `CKXH`,\n" +
            "            `NBJGH`,\n" +
            "            `KHH`,\n" +
            "            `BZ`,\n" +
            "            `CKYE`,\n"+
            "            `GROUP_ID`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";

    public static String SQL_GRCKFS = "INSERT INTO `IMAS_ODS_%s_GRCKFS`\n" +
            "            (`DATA_ID`,\n" +
            "            `DATA_RPT_DATE`,\n" +
            "            `ORG_ID`,\n" +
            "            `RSV1`,\n" +
            "            `SJRQ`,\n" +
            "            `CKZHBM`,\n" +
            "            `CKXH`,\n" +
            "            `NBJGH`,\n" +
            "            `KHH`,\n" +
            "            `JYLSH`,\n" +
            "            `JYRQ`,\n" +
            "            `JZLL`,\n" +
            "            `SJLL`,\n" +
            "            `BZ`,\n" +
            "            `FSJE`,\n" +
            "            `JYQD`,\n" +
            "            `JYFX`,\n" +
            "            `DXEBZ`,\n" +
            "            `GROUP_ID`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";

    public static String SQL_MRFSJC = "INSERT INTO `IMAS_ODS_%s_MRFSJC`\n" +
            "            (`DATA_ID`,\n" +
            "            `DATA_RPT_DATE`,\n" +
            "            `ORG_ID`,\n" +
            "            `GROUP_ID`,\n" +
            "            `SJRQ`,\n" +
            "            `NBJGH`,\n" +
            "            `KHH`,\n" +
            "            `JRJGLXDM`,\n" +
            "            `YWBM`,\n" +
            "            `HGYWLX`,\n" +
            "            `BDWLX`,\n" +
            "            `QSRQ`,\n" +
            "            `DQRQ`,\n" +
            "            `SJZZRQ`,\n" +
            "            `HGQXLX`,\n" +
            "            `JDDJJZLX`,\n" +
            "            `LLLX`,\n" +
            "            `SJLL`,\n" +
            "            `JZLL`,\n" +
            "            `JXFS`,\n" +
            "            `LLFDPL`,\n"+
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";

    public static String SQL_MRFSJC_UPDATE = "update IMAS_ODS_%s_MRFSJC set RSV5 = ? where YWBM = ? and SJRQ = ?";

    public static String SQL_MRFSJC_GMO = "INSERT INTO `IMAS_ODS_%s_MRFSJC`\n" +
            "            (`DATA_ID`,\n" +
            "            `DATA_RPT_DATE`,\n" +
            "            `ORG_ID`,\n" +
            "            `GROUP_ID`,\n" +
            "            `SJRQ`,\n" +
            "            `NBJGH`,\n" +
            "            `KHH`,\n" +
            "            `JRJGLXDM`,\n" +
            "            `YWBM`,\n" +
            "            `HGYWLX`,\n" +
            "            `BDWLX`,\n" +
            "            `QSRQ`,\n" +
            "            `DQRQ`,\n" +
            "            `SJZZRQ`,\n" +
            "            `HGQXLX`,\n" +
            "            `JDDJJZLX`,\n" +
            "            `LLLX`,\n" +
            "            `SJLL`,\n" +
            "            `JZLL`,\n" +
            "            `JXFS`,\n" +
            "            `LLFDPL`,\n"+
            "            `RSV5`,\n"+
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0'," +
            "?,?,?)";

    public static String SQL_MRFSYE = "INSERT INTO `IMAS_ODS_%s_MRFSYE`\n" +
            "(`DATA_ID`,\n" +
            "`DATA_RPT_DATE`,\n" +
            "`ORG_ID`,\n" +
            "`GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "`YWBM`,\n" +
            "`NBJGH`,\n" +
            "`KHH`,\n" +
            "`BZ`,\n" +
            "`YE`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";

    public static String SQL_MRFSFS = "INSERT INTO `IMAS_ODS_%s_MRFSFS`\n" +
            "            (`DATA_ID`,\n" +
            "            `DATA_RPT_DATE`,\n" +
            "            `ORG_ID`,\n" +
            "            `GROUP_ID`,\n" +
            "`SJRQ`,\n" +
            "            `YWBM`,\n" +
            "            `NBJGH`,\n" +
            "            `KHH`,\n" +
            "            `JYLSH`,\n" +
            "            `BZ`,\n" +
            "            `JYRQ`,\n" +
            "            `FSJE`,\n" +
            "            `SJLL`,\n" +
            "            `JZLL`,\n" +
            "            `JYFX`,\n" +
            "`CHECK_FLAG`,\n" +
            "`NEXT_ACTION`,\n" +
            "`DATA_RPT_FLAG`,\n" +
            "`DATA_STATUS`,\n" +
            "`DATA_FLAG`,\n" +
            "`DATA_SOURCE`,\n" +
            "`DATA_VERSION`,\n" +
            "`DATA_CRT_USER`,\n" +
            "`DATA_CRT_DATE`,\n" +
            "`DATA_CRT_TIME`) VALUES (?,?,'HSBC',?,?,?,?,?,?,?,?,?,?,?,?,'N','00','A','00','A','2','0',?,?,?)";
}
