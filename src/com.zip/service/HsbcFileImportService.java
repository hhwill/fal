package com.gingkoo.imas.hsbc.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import javax.sql.DataSource;

import com.google.common.base.Splitter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.gingkoo.gf4j2.framework.entity.global.GlobalInfo;
import com.gingkoo.gpms.importer.CommonDataImporter;
import com.gingkoo.gpms.importer.job.bean.JobResult;
import com.gingkoo.imas.hsbc.helper.GroupMapHelper;

import static com.gingkoo.gpms.constant.ImportConstant.IMPORT_SOURCE_TYPE_ODS;

@Component
public class HsbcFileImportService {

    private static final Splitter UNDERLINE_SPLITTER = Splitter.on('_');
    private final Logger log = LoggerFactory.getLogger(HsbcFileImportService.class);
    private final JdbcTemplate jdbcTemplate;
    // 注入文件导入
    private final CommonDataImporter commonDataImporter;

    private final GroupMapHelper groupMapHelper;

    // 注入方法
    public HsbcFileImportService(CommonDataImporter commonDataImporter, DataSource dataSource, GroupMapHelper groupMapHelper) {
        this.commonDataImporter = commonDataImporter;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        this.groupMapHelper = groupMapHelper;
    }

    // 查看要导入的文件
    public void importFiles() {
        // 从日志中读取要导入的文件
        String sql = "SELECT A.*,C.REPORT_CODE FROM GP_BM_ID_UPLOADLOG A " +
                "INNER JOIN  GP_BM_ID_FILEDATA B ON A.FILE_NAME LIKE  CONCAT('%',SUBSTRING_INDEX(B.FILE_NAME,'.',1)," +
                "'%') LEFT JOIN IMAS_BM_RPT_CFG C ON C.TABLE_NAME = B.TABLE_NAME " +
                " WHERE A.FILLER1='未导入' AND B.FILE_OWNER=? ORDER BY UPLOAD_TIME ASC";
        log.debug("即将处理sql:{}", sql);

        List<Map<String, Object>> uploadlogs = jdbcTemplate.queryForList(sql, IMPORT_SOURCE_TYPE_ODS);

        uploadlogs.stream()
                .filter(distinctByKey(o -> o.get("STORE_NAME")))//STORE_NAME去重
                .filter(uploadlog -> {
                    //文件名校验
                    String uploadGuid = uploadlog.get("UPLOAD_GUID") == null ? "" : (String) uploadlog.get("UPLOAD_GUID");
                    String fileName = uploadlog.get("FILE_NAME") == null ? "" : (String) uploadlog.get("FILE_NAME");
                    List<String> fileNameSp = UNDERLINE_SPLITTER.splitToList(fileName);
                    if (fileNameSp.size() < 3) {
                        log.error("文件名不合法[{}]", fileName);
                        String filler1 = uploadlog.get("FILLER1") == null ? "" : uploadlog.get("FILLER1").toString();
                        jdbcTemplate.execute("update GP_BM_ID_UPLOADLOG set FILLER1 = '" + filler1 + "' where UPLOAD_GUID = '" + uploadGuid + "'");
                        log.debug("执行sql sql:{}", sql);
                    }
                    return fileNameSp.size() > 3;
                }).forEach(uploadlog -> {
            String uploadGuid = uploadlog.get("UPLOAD_GUID") == null ? "" : (String) uploadlog.get("UPLOAD_GUID");
            String fileName = uploadlog.get("FILE_NAME") == null ? "" : (String) uploadlog.get("FILE_NAME");

            List<String> fileNameSp = UNDERLINE_SPLITTER.splitToList(fileName);
            String groupId = fileNameSp.get(1);
            String dataRptDate = fileNameSp.get(2);

            groupId = groupMapHelper.getMapping(groupId);

            String reportCode = uploadlog.get("REPORT_CODE") == null ? "" : (String) uploadlog.get("REPORT_CODE");
            String uploader = uploadlog.get("UPLOADER") == null ? "" : (String) uploadlog.get("UPLOADER");
            String uploadOrgId = uploadlog.get("UPLOAD_ORG_ID") == null ? "" : (String) uploadlog.get("UPLOAD_ORG_ID");

            try {
                GlobalInfo globalInfo = new GlobalInfo();
                globalInfo.setTlrno(uploader);
                globalInfo.setBrno(groupId);
                globalInfo.setOrgId(uploadOrgId);

                Map<String, Object> param = new HashMap<>();
                param.put("jobId", uploadGuid);
                param.put("globalInfo", globalInfo);
                param.put("departId", groupId);
                param.put("dataRptDate", dataRptDate);
                param.put("dataOrgId", uploadOrgId);
                param.put("dataGroupId", groupId);
                param.put("reportCode", reportCode);
                // 任务同步进行
                JobResult jobResult = this.commonDataImporter.importer(param);
                log.info("任务：{}执行结束,执行结果：{}", uploadGuid, jobResult.getDesc());
            } catch (Exception e) {
                log.error("文件{}处理失败", fileName, e);
            }
            log.debug("文件{}处理完成", fileName);
        });
    }

    private <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
        Map<Object, Boolean> seen = new ConcurrentHashMap<>();
        return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }
}