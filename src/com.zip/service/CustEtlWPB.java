package com.gingkoo.imas.hsbc.service;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.*;

import javax.sql.DataSource;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;

import com.gingkoo.root.facility.spring.tx.TransactionHelper;

import static com.gingkoo.imas.hsbc.service.EtlConst.*;
import static com.gingkoo.imas.hsbc.service.EtlUtils.*;

@Component
public class CustEtlWPB {

    private final Logger logger = LoggerFactory.getLogger(CustEtlWPB.class);

    public static final Map<String, String> WPB_TEAM_DEF =
            Collections.unmodifiableMap(new HashMap<String, String>() {
                private static final long serialVersionUID = 1L;

                {
                    put("DD", "WPB_DD_team");
                    put("TD", "WPB_TD_team");
                    put("DCI", "WPB_DCI_team");
                    put("EYI", "WPB_EYI_team");
                    put("CPI", "WPB_CPI_team");
                }
            });

    private final EtlInsertService insertService;

    private final JdbcTemplate jdbcTemplate;

    private final TransactionHelper transactionTemplate;

    private final DataSource dataSource;

    private int threadSize;

    private int pageSize;

    public CustEtlWPB(EtlInsertService insertService, TransactionHelper transactionTemplate, DataSource dataSource) {
        this.insertService = insertService;
        this.transactionTemplate = transactionTemplate;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        this.dataSource = dataSource;
        threadSize = 10;
        pageSize = 10000;
    }

    private boolean processdd(String now, String group_id, Map<String,Integer> ids) {
        ExecutorService execservice = Executors.newFixedThreadPool(threadSize);
        String sql = "select * from ods_wpb_dd where data_date = '"+now+"' and group_id = '"+group_id+"' and ZGCUCL " +
                "in ('OPR','RCC','SJL','SSL','STL','STS') ";
        if (now.equals("20210627")) {
            sql += " and dfstus <> '5' ";
        }
        CompletionService<List<List<List<String>>>> completionService = new ExecutorCompletionService<List<List<List<String>>>>(execservice);
        String querySql = "SELECT COUNT(1) FROM (" + sql + ") a";
        Integer totalCount = jdbcTemplate.queryForObject(querySql, Integer.class);
        int times = totalCount / pageSize;
        if (totalCount % pageSize != 0) {
            times += 1;
        }
        int bindex = 0;
        List<Callable<List<List<List<String>>>>> tasks = new ArrayList<Callable<List<List<List<String>>>>>();
        for (int i = 0; i < times; i++) {
            Callable<List<List<List<String>>>> qfe = new CustEtlWPBDDThread(dataSource, sql,
                    pageSize, bindex, now);
            tasks.add(qfe);
            bindex++;
        }
        try {
            for (int i = 0; i < tasks.size(); i++) {
                completionService.submit(tasks.get(i));
            }
            for (int i = 0; i < tasks.size(); i++) {
                List<List<List<String>>> datas = completionService.take().get();
                List<List<String>> jcs = datas.get(0);
                List<List<String>> yes = datas.get(1);
                for (int k = jcs.size()-1; k  > 0; k--) {
                    String key = jcs.get(k).get(1) + "|" + jcs.get(k).get(2);
                    if (!ids.containsKey(key)) {
                        ids.put(key, 0);
                    } else {
                        jcs.remove(jcs.get(k));
                        yes.remove(yes.get(k));
                    }
                }
                insertService.insertData(SQL_GRCKJC, group_id, group_id, jcs);
                insertService.insertData(SQL_GRCKYE, group_id, group_id, yes);
            }
        } catch (Exception ex) {
            logger.error("ods2pm failed", ex);
        }
        return true;
    }

    private boolean processtdCPI(String now, String group_id) {
        ExecutorService execservice = Executors.newFixedThreadPool(threadSize);
        String sql = "select * from ods_wpb_td where data_date = '"+now+"' and group_id = '"+group_id+"' and " +
                "TDAPTY in ('D42','D43') and ZGCUCL" +
                " in ('OPR','RCC','SJL','SSL','STL','STS')";
        CompletionService<List<List<List<String>>>> completionService = new ExecutorCompletionService<List<List<List<String>>>>(execservice);
        String querySql = "SELECT COUNT(1) FROM (" + sql + ") a";
        Integer totalCount = jdbcTemplate.queryForObject(querySql, Integer.class);
        int times = totalCount / pageSize;
        if (totalCount % pageSize != 0) {
            times += 1;
        }
        int bindex = 0;
        List<Callable<List<List<List<String>>>>> tasks = new ArrayList<Callable<List<List<List<String>>>>>();
        for (int i = 0; i < times; i++) {
            Callable<List<List<List<String>>>> qfe = new CustEtlWPBTDThread(dataSource, sql,
                    pageSize, bindex, now);
            tasks.add(qfe);
            bindex++;
        }
        try {
            for (int i = 0; i < tasks.size(); i++) {
                completionService.submit(tasks.get(i));
            }
            for (int i = 0; i < tasks.size(); i++) {
                List<List<List<String>>> datas = completionService.take().get();
                insertService.insertData(SQL_GRCKJC, group_id, group_id, datas.get(0));
                insertService.insertData(SQL_GRCKYE, group_id, group_id, datas.get(1));
                insertService.insertData(SQL_GRCKFS, group_id, group_id, datas.get(2));
            }
        } catch (Exception ex) {
            logger.error("ods2pm failed", ex);
        }
        return true;
    }

    private boolean processtd(String now, String group_id, Map<String,Integer> ids) {
        ExecutorService execservice = Executors.newFixedThreadPool(threadSize);
        String sql = "select * from ods_wpb_td where data_date = '"+now+"' and group_id = '"+group_id+"' and ZGCUCL " +
                "in ('OPR','RCC','SJL','SSL','STL','STS') ";
        if (now.equals("20210627")) {
            sql += " and tdstus<>'5' ";
        }
        CompletionService<List<List<List<String>>>> completionService = new ExecutorCompletionService<List<List<List<String>>>>(execservice);
        String querySql = "SELECT COUNT(1) FROM (" + sql + ") a";
        Integer totalCount = jdbcTemplate.queryForObject(querySql, Integer.class);
        int times = totalCount / pageSize;
        if (totalCount % pageSize != 0) {
            times += 1;
        }
        int bindex = 0;
        List<Callable<List<List<List<String>>>>> tasks = new ArrayList<Callable<List<List<List<String>>>>>();
        for (int i = 0; i < times; i++) {
            Callable<List<List<List<String>>>> qfe = new CustEtlWPBTDThread(dataSource, sql,
                    pageSize, bindex, now);
            tasks.add(qfe);
            bindex++;
        }
        try {
            for (int i = 0; i < tasks.size(); i++) {
                completionService.submit(tasks.get(i));
            }
            for (int i = 0; i < tasks.size(); i++) {
                List<List<List<String>>> datas = completionService.take().get();
                List<List<String>> jcs = datas.get(0);
                List<List<String>> yes = datas.get(1);
                for (int k = jcs.size()-1; k  > 0; k--) {
                    String key = jcs.get(k).get(1) + "|" + jcs.get(k).get(2);
                    if (!ids.containsKey(key)) {
                        ids.put(key, 0);
                    } else {
                        jcs.remove(jcs.get(k));
                        yes.remove(yes.get(k));
                    }
                }
                insertService.insertData(SQL_GRCKJC, group_id, group_id, jcs);
                insertService.insertData(SQL_GRCKYE, group_id, group_id, yes);
                insertService.insertData(SQL_GRCKFS, group_id, group_id, datas.get(2));
            }
        } catch (Exception ex) {
            logger.error("ods2pm failed", ex);
        }
        return true;
    }

    private boolean processtdfs(String now) {
        String group_id = CustEtlWPB.WPB_TEAM_DEF.get("CPI");
        String sql = String.format("select * from ods_wpb_td where tdapty in ('D42','D43') and tdstdt" +
                        " > data_date and" +
                        " tdstdt = '%s'",
                now);
        List<Map<String, Object>> lst = jdbcTemplate.queryForList(sql);
        List<List<String>> grckfs = new ArrayList<List<String>>();
        for (Map<String, Object> src : lst) {
            String TDAPTY = getString(src.get("TDAPTY"));

            String type = "JGXCK";

            List<String> subgrckfs = new ArrayList<String>();
            subgrckfs.add(now);
            subgrckfs.add(formatCKZHBH(src.get("TDACB"), src.get("TDACS"), src.get("TDACX")));
            subgrckfs.add("01");
            subgrckfs.add(formatNBJGH(src.get("TDACB")));
            subgrckfs.add(getString(src.get("CUS")));
            //交易流水号
            subgrckfs.add(formatCKZHBH(src.get("THCPDT"), src.get("THCPWS"), src.get("THDLNO")));
            subgrckfs.add(getString(src.get("THCPDT")));
            subgrckfs.add("");
            //实际利率
            if (type.equals("DQCK")) {
                subgrckfs.add(getString(src.get("TDCNTR")));
            } else {
                String SJLL = "";
                if (TDAPTY.equals("D41")) {
                    SJLL = getString(src.get("EMCIRS"));
                }else if (TDAPTY.equals("D42") || TDAPTY.equals("D43")) {
                    SJLL = getMap("WPB_BDSYL", src.get("TDTRNR"));
                    if (SJLL.startsWith("-")) {
                        SJLL = "";
                    }
                }
                subgrckfs.add(SJLL);
            }
            subgrckfs.add(getString(src.get("TDCYCD")));
            String TRANAMT = getString(src.get("TRANAMT"));
            if (TRANAMT.startsWith("-")) {
                TRANAMT = TRANAMT.substring(1);
            }
            subgrckfs.add(TRANAMT);
            //交易渠道
            String JYQD = "";
            if (type.equals("DQCK")) {
                if (getString(src.get("TDMIN1")).startsWith("HIB")) {
                    JYQD = "04";
                } else {
                    JYQD = "01";
                }
            } else {
                if (TDAPTY.equals("D41") || ((TDAPTY.equals("D42") || TDAPTY.equals("D43")) &&
                        getString(src.get("TDMIN3")).equals("")) ||
                        ((TDAPTY.equals("D01") || TDAPTY.equals("D02") || TDAPTY.equals("D03") || TDAPTY.equals("D04"))
                                && getString(src.get("TDCHID")).equals("OHB"))) {
                    JYQD = "01";
                } else if (((TDAPTY.equals("D01") || TDAPTY.equals("D02") || TDAPTY.equals("D03") || TDAPTY.equals("D04"))
                        && getString(src.get("TDCHID")).equals("OHI")) ||
                        ((TDAPTY.equals("D42") || TDAPTY.equals("D43")) && getString(src.get("TDMIN3")).equals("NET"))) {
                    JYQD = "03";
                } else if (((TDAPTY.equals("D01") || TDAPTY.equals("D02") || TDAPTY.equals("D03") || TDAPTY.equals("D04"))
                        && getString(src.get("TDCHID")).equals("MOB")) ||
                        ((TDAPTY.equals("D42") || TDAPTY.equals("D43")) && getString(src.get("TDMIN3")).equals(
                                "Mobile"))) {
                    JYQD = "04";
                }
            }
            subgrckfs.add(JYQD);
            //交易方向
            String JYFX = "";
            if (new BigDecimal(getString(src.get("TRANAMT"))).compareTo(new BigDecimal("0")) > 0) {
                JYFX = "1";
            } else {
                JYFX = "0";
            }
            subgrckfs.add(JYFX);
            if (JYFX.equals("1")) {
                subgrckfs.add(getDXEBZ(src.get("TDCYCD"), src.get("TRANAMT")));
            } else {
                subgrckfs.add("");
            }
            subgrckfs.add(group_id);
            grckfs.add(subgrckfs);
        }
        try {
            insertService.insertData(SQL_GRCKFS, group_id, group_id, grckfs);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return true;
    }

    private boolean processddfs(String now, String group_id) {
        String sql = "select max(data_date) from ods_wpb_dd where data_date < '" + now + "'";
        String previous = jdbcTemplate.queryForObject(sql, String.class);
        sql = String.format("select a.*, b.ledger as OLDLEDGER from ( select * from ods_wpb_dd where data_date"
                        + " = '%s') a inner join (select * from ods_wpb_dd where data_date = '%s') b "
                        + " on a.dfacb=b.dfacb and a.dfacs=b.dfacs and a.dfacx = b.dfacx and a.ledger <> b.ledger and" +
                        " a.ZGCUCL in ('OPR','RCC','SJL','SSL','STL','STS') "
                        + " union "
                        + " select a.*, 0 as OLDLEDGER from (select * from ods_wpb_dd where data_date"
                        + " = '%s' and ZGCUCL in ('OPR','RCC','SJL','SSL','STL','STS')) a where not exists (select * " +
                        "from (select dfacb,dfacs,dfacx from ods_wpb_dd "
                        + " where data_date = '%s') b where and a.dfacb=b.dfacb and a.dfacs=b.dfacs and" +
                        " a.dfacx = b.dfacx)",
                now, previous, now, previous);
        List<Map<String, Object>> lst = jdbcTemplate.queryForList(sql);
        List<List<String>> grckfs = new ArrayList<List<String>>();
        for (Map<String, Object> src : lst) {
            List<List<String>> ckxx = getCKXH(src);
            List<String> subgrckfs = new ArrayList<String>();

            subgrckfs.add(now);
            String ckzhbm = formatCKZHBH(src.get("DFACB"),src.get("DFACS"),src.get("DFACX"));
            if (!getMap("WPB_CLOSE", ckzhbm).equals("")) {
                continue;
            }
            subgrckfs.add(ckzhbm);
            subgrckfs.add("01");
            subgrckfs.add(formatNBJGH(src.get("DFACB")));
            subgrckfs.add(getString(src.get("CUS")));
            //TODO 交易流水号
            String DPDLNO = getString(src.get("DPDLNO"));
            while (DPDLNO.length() < 5) {
                DPDLNO = "0" + DPDLNO;
            }
            subgrckfs.add(now+formatCKZHBH(src.get("DFACB"),src.get("DFACS"),src.get("DFACX")).substring(6)+DPDLNO);
            subgrckfs.add(getString(src.get("DPCPDT")));
            subgrckfs.add("");
            //实际利率
            subgrckfs.add(ckxx.get(0).get(0));
            String ccy = getString(src.get("DFCYCD"));
            subgrckfs.add(ccy);
            String TRANAMT = new BigDecimal(getString(src.get("LEDGER"))).subtract(new BigDecimal(getString(src.get(
                    "OLDLEDGER")))).toString();
            String ABSTRANAMT = TRANAMT;
            if (ABSTRANAMT.startsWith("-")) {
                ABSTRANAMT = ABSTRANAMT.substring(1);
            }
            subgrckfs.add(ABSTRANAMT);
            //交易渠道
            subgrckfs.add("01");

            String JYFX = "";
            int compare = new BigDecimal(TRANAMT).compareTo(new BigDecimal("0"));
            if (compare > 0) {
                JYFX = "1";
            } else if (compare < 0) {
                JYFX = "0";
            } else {
                continue;
            }
            subgrckfs.add(JYFX);

            if (JYFX.equals("1")) {
                subgrckfs.add(getDXEBZ(ccy, src.get("LEDGER")));
            } else {
                subgrckfs.add("");
            }
            subgrckfs.add(WPB_TEAM_DEF.get("DD"));
            grckfs.add(subgrckfs);
        }
        try {
            insertService.insertData(SQL_GRCKFS, group_id, group_id, grckfs);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return true;
    }

    public boolean processCPI(String now, String group_id) {
        logger.info(">>>开始WPB DCI" + now + " " + group_id);
        String day = now.substring(6,8);

        processtdCPI(now, group_id);
        //TODO 第一天不对比历史的发生
        if (!now.equals("20210627")) {
            processddfs(now, group_id);
        }
        processtdfs(now);
        //processgrkhxx(now, "OPS_BOS");
        return true;
    }

    public boolean process(String now, String group_id) {

        logger.info(">>>开始WPB" + now + " " + group_id);
        String day = now.substring(6,8);
        String sql = String.format("delete from imas_ODS_"+day+"_grckjc where sjrq = '%s' and group_id = '%s'", now,
                group_id);
        jdbcTemplate.execute(sql);
        sql = String.format("delete from imas_ODS_"+day+"_grckye where sjrq = '%s' and group_id = '%s'", now, group_id);
        jdbcTemplate.execute(sql);
        sql = String.format("delete from imas_ODS_"+day+"_grckfs where sjrq = '%s' and group_id = '%s'", now, group_id);
        jdbcTemplate.execute(sql);

        Map<String,Integer> ids = new HashMap<String, Integer>();
        processdd(now, group_id, ids);
        processtd(now, group_id, ids);
        //TODO 第一天不对比历史的发生
        if (Integer.parseInt(now) > 20210627) {
            processddfs(now, group_id);
        }
        processtdfs(now);
        //processgrkhxx(now, "OPS_BOS");
        return true;
    }

    public void processgrkhxx(String now, String group_id) {
        logger.info(">>>>processgrkhxx_khh");
        String day = now.substring(6,8);
        String sql = String.format("select distinct khh from ( select khh from imas_ODS_%s_grckjc where sjrq = '%s' " +
                "union select khh from imas_ODS_%s_grckye where sjrq = '%s' union select khh from imas_ODS_%s_grckfs " +
                "where sjrq = '%s') a where khh not in (select khh from imas_ODS_%s_grkhxx where sjrq = '%s')",day,
                now,day,now,day,now,day,now);
        logger.info(">>>>processgrkhxx_khh:" + sql);
        List<Map<String, Object>> records = jdbcTemplate.queryForList(sql);
        logger.info(">>>>processgrkhxx_khh:" + records.size());
        if (records.size() > 0) {
            /*
            "`SJRQ`,\n" +
            "`KHH`,\n" +
            "`NBJGH`,\n" +
            "`CZDHZQHDM`,\n" +
            "`SXED`,\n" +
            "`YYED`,\n" +
            "`KHXL`,\n" +
            "`NHBZ`,\n" +
            "`GROUP_ID`,\n" +
             */
            List<List<String>> base = new ArrayList<List<String>>();
            for (Map<String, Object> record : records) {
                List<String> lst = new ArrayList<String>();
                lst.add(now);
                lst.add(getString(record.get("KHH")));
                lst.add("CNHSBC001");
                lst.add("");
                lst.add("");
                lst.add("");
                lst.add("");
                lst.add("");
                lst.add(group_id);
                lst.add("NOCOMMENT");
                base.add(lst);
            }
            insertService.insertData(SQL_GRKHXX, group_id, group_id, base);
        }
    }

    public void test() {
        List<List<String>> dwckjc = new ArrayList<List<String>>();
        List<String> r = new ArrayList<String>();
        r.add("20210531");
        r.add("20210531");
        r.add("01");
        r.add("20210531");
        r.add("20210531");
        r.add("D011");
        r.add("");
        r.add("20210531");
        r.add("");
        r.add("");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        r.add("1");
        dwckjc.add(r);
        insertService.insertData(SQL_DWCKJC, "a", "a", dwckjc);
    }
}
