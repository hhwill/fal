package com.gingkoo.imas.hsbc.service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;

import com.gingkoo.data.compute.api.ComputeUnit;
import com.gingkoo.data.compute.api.bean.Result;
import com.gingkoo.imas.core.task.ReportTaskManager;
import com.gingkoo.root.annotation.Nullable;
import com.gingkoo.root.facility.spring.tx.TransactionHelper;

@Component
public class HsbcCheckFile implements ComputeUnit {

    private final Logger logger = LoggerFactory.getLogger(HsbcCheckFile.class);

    private final TransactionHelper transactionTemplate;

    private final HsbcFileImportService importService;
    private final JdbcTemplate jdbcTemplate;

    private final CustLoadFileService loadFileService;

    private final CustLoadFileProcessService fileProcessService;

    private final ReportTaskManager reportTaskManager;

    public HsbcCheckFile(DataSource dataSource, HsbcFileImportService importService,
                         CustLoadFileService loadFileService, CustLoadFileProcessService fileProcessService,
                         TransactionHelper transactionTemplate, ReportTaskManager reportTaskManager){
        this.importService = importService;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        this.loadFileService = loadFileService;
        this.fileProcessService = fileProcessService;
        this.reportTaskManager = reportTaskManager;
        this.transactionTemplate = transactionTemplate;
    }

    public Result call(Map<String, ?> parameters) {
        String dataRptDate = Objects.toString(parameters.get("dataRptDate"), (String)null);
        String type = Objects.toString(parameters.get("type"), "0");
        return this.execute(dataRptDate, type);
    }

    public Result execute(@Nullable String dataRptDate, @Nullable String type) {

        com.gingkoo.gpms.batch.entity.bean.JobResult jr = new com.gingkoo.gpms.batch.entity.bean.JobResult();
        jr.setErrCode("00");
        jr.setErrMsg("");
        logger.info("HsbcCheckFile");

        String now = dataRptDate;
        if (now == null) {
            Map<String, Object> check = jdbcTemplate.queryForMap("select * from ods_check");
            now = check.get("WORKDATE").toString();
        }
        String fileResult = getFileStatus(now, Integer.valueOf(type));
        if (!fileResult.equals("")) {
            return Result.of(Result.ERROR.getCode(), fileResult + " 未上传");
        }

        return Result.of(Result.OK.getCode(), now + "文件检查正常");
    }

    private String getCondition(int type, String workdate) {
        String result = "";

        String sql = "";
        if (type == 0) {
            sql = "select * from ods_check_template where odscheck = 1";
        } else {
            sql = "select * from ods_check_template where qccheck = 1";
        }
        List<Map<String, Object>> records = jdbcTemplate.queryForList(sql);
        String errMsg = "";
        for (Map<String, Object> record : records) {
            String tableName = record.get("TABLE_NAME").toString().toUpperCase();
            if (tableName.startsWith("IMAS_PM_")) {
                tableName = tableName.replace("IMAS_PM_", "IMAS_PM_"+workdate.substring(6,8) + "_");
            }
            sql = "select count(*) cnt from " + tableName + " where group_id = '" +
                    record.get("GROUP_ID").toString() + "' and "  +
                    record.get("WHERECLAUSE").toString().replace(":DATA_DATE", "'" + workdate + "'");
            int cnt = jdbcTemplate.queryForObject(sql, Integer.class);
            if (cnt == 0) {
                errMsg += record.get("ERRMSG").toString() + ";";
            }
        }
        return errMsg;
    }


    private void execUpdSqlCommit(String sql) {
        transactionTemplate.run(Propagation.REQUIRES_NEW, () -> {
            jdbcTemplate.update(sql);
        });
    }

    //0 - exist 1 - process success
    public String getFileStatus(String now, int checktype) {
        String result = "";
        String result0 = "";
        String result1 = "";
        List<Map<String, Object>> checks = jdbcTemplate.queryForList("select * from ods_check_template where " +
                "odscheck='9' order by group_id");
        List<Map<String, Object>> files = jdbcTemplate.queryForList("select * from gp_bm_id_uploadlog where " +
                "file_name like '%"+now+"%'");
        for (Map<String, Object> check : checks) {
            String filename = check.get("WHERECLAUSE").toString();
            String errmsg = check.get("ERRMSG").toString();
            String groupid = check.get("GROUP_ID").toString();
            boolean find = false;
            boolean success = false;
            for (Map<String, Object> file : files) {
                String file_name = file.get("FILE_NAME").toString();
                String filler2 = file.get("FILLER2").toString();
                if (file_name.startsWith(filename)) {
                    find = true;
                    if(filler2.startsWith("未导入") || filler2.startsWith("导入未完成")) {

                    } else {
                        success = true;
                    }
                }
            }
            if (!success) {
                result1 += String.format(errmsg, now) + "\n";
            }
            if (!find) {
                result0 += String.format(errmsg, now) + "\n";
            }
        }
        if(checktype == 0) {
            return result0;
        }
        if (checktype == 1) {
            return result1;
        }
        return result;
    }

}
