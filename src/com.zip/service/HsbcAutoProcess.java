package com.gingkoo.imas.hsbc.service;

import java.text.SimpleDateFormat;
import java.util.*;
import javax.sql.DataSource;

import com.google.common.collect.ImmutableMap;
import lombok.SneakyThrows;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.access.method.P;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;

import com.gingkoo.data.compute.api.ComputeUnit;
import com.gingkoo.data.compute.api.bean.Result;
import com.gingkoo.gpms.importer.CommonDataImporter;
import com.gingkoo.gpms.importer.job.bean.JobResult;
import com.gingkoo.gpms.platform.task.TaskManager;
import com.gingkoo.imas.core.task.ReportTaskManager;
import com.gingkoo.imas.core.task.enumeration.TaskType;
import com.gingkoo.root.annotation.Nullable;
import com.gingkoo.root.facility.spring.tx.TransactionHelper;

@Component
public class HsbcAutoProcess implements ComputeUnit {

    private final Logger logger = LoggerFactory.getLogger(HsbcAutoProcess.class);

    private final TransactionHelper transactionTemplate;

    private final HsbcFileImportService importService;
    private final JdbcTemplate jdbcTemplate;

    private final CustLoadFileService loadFileService;

    private final CustLoadFileProcessService fileProcessService;

    private final ReportTaskManager reportTaskManager;

    public HsbcAutoProcess(DataSource dataSource, HsbcFileImportService importService,
                           CustLoadFileService loadFileService, CustLoadFileProcessService fileProcessService,
                           TransactionHelper transactionTemplate,ReportTaskManager reportTaskManager){
        this.importService = importService;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        this.loadFileService = loadFileService;
        this.fileProcessService = fileProcessService;
        this.reportTaskManager = reportTaskManager;
        this.transactionTemplate = transactionTemplate;
    }

    public Result call(Map<String, ?> parameters) {
        String dataRptDate = Objects.toString(parameters.get("dataRptDate"), (String)null);
        return this.execute(dataRptDate);
    }

    public Result execute(@Nullable String dataRptDate) {

        com.gingkoo.gpms.batch.entity.bean.JobResult jr = new com.gingkoo.gpms.batch.entity.bean.JobResult();
        jr.setErrCode("00");
        jr.setErrMsg("");
        logger.info("HsbcAutoProcess");

        String now = dataRptDate;
        if (now == null) {
            Map<String, Object> check = jdbcTemplate.queryForMap("select * from ods_check");
            now = check.get("WORKDATE").toString();
        }
        //TODO 如果没下发任务则下发任务
        /*
        Map<String, Object> params = ImmutableMap.of("taskIds", Collections.emptyList());
        try {
            reportTaskManager.distributeTask(now, TaskType.FILE_TASK, params);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        try {
            reportTaskManager.distributeTask(now, TaskType.ETL_TASK, params);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        try {
            reportTaskManager.distributeTask(now, TaskType.FILE_TASK, params);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        */
        //TODO 从一张配置表检查所有文件是否已上传    --并且导入成功并且没有错误
        String fileResult = getFileStatus(now, 0);
//        if (!fileResult.equals("")) {
//            return Result.of(Result.ERROR.getCode(), fileResult + " 未上传");
//        }

        //导数据 - 标准模板
        try {
            importService.importFiles();
        }catch (Exception ex) {
            logger.info("import template failed", ex);
            return Result.of(Result.ERROR.getCode(), "import template failed " + ex.getMessage());
        }
        //导数据 - rawdata
        try {
            loadFileService.run();
        } catch (Exception ex) {
            logger.info("import rawdata failed", ex);
            return Result.of(Result.ERROR.getCode(), "import rawdata failed " + ex.getMessage());
        }

        fileResult = getFileStatus(now, 1);

//        if (!fileResult.equals("")) {
//            return Result.of(Result.ERROR.getCode(), fileResult + " 未成功导入");
//        }

        //满足条件，开始etl
        /*
        Map<String, Object> check = jdbcTemplate.queryForMap("select * from ods_check");
        String now = check.get("WORKDATE").toString();
        int status = (Integer)check.get("STATUS");
        if (status == 1) {
            return Result.of(Result.OK.getCode(), now + "自动处理已完成");
        }
        */
        String errMsg = getCondition(0, now);
        if (!errMsg.equals("")) {
            jr.setErrCode("01");
            jr.setErrMsg(errMsg);
            return Result.of(Result.ERROR.getCode(), errMsg);
        }
//        try {
//            fileProcessService.initMap(now);
//        } catch (Exception ex) {
//            logger.info("initMap failed", ex);
//            Result.of(Result.OK.getCode(), "success");
//        }
        String sql = "select * from ods_ctl where need_ods = '1' and work_date <'"+now+"' order by order_no";
        List<Map<String, Object>> tasks = jdbcTemplate.queryForList(sql);
        for (Map<String, Object> task : tasks) {
            String service = task.get("ODS_SERVICE").toString();
            try {
                int holiday = isHoliday(now);  //1-isholiday 0-isnot holiday
                String HOLIDAY_STATUS = task.get("HOLIDAY_STATUS").toString();  //0-holiday not execute 1- only holiday
                // execute 2- must execute
                boolean execute = false;
                if (HOLIDAY_STATUS.equals("2")) {
                    execute = true;
                } else if (holiday == 1 && HOLIDAY_STATUS.equals("1")) {
                    execute = true;
                } else if (holiday == 0 && HOLIDAY_STATUS.equals("0")) {
                    execute = true;
                }
                if (execute) {
                    fileProcessService.process(service, now, task.get("GROUP_ID").toString());
                    sql = "update ods_ctl set work_date = '" + now + "' where data_id = '" + task.get("DATA_ID").toString() + "'";
                    execUpdSqlCommit(sql);
                }
            } catch (Exception ex) {
                logger.info("ETL Service " +service+" Failed", ex);
                return Result.of(Result.ERROR.getCode(), "ODS Process ["+now+"]["+service+"]Failed" + ex.getMessage());
            }
        }
        errMsg = getCondition(1, now);
        /*
        if (!errMsg.equals("")) {
            jr.setErrCode("02");
            jr.setErrMsg(errMsg);
            return Result.of(Result.ERROR.getCode(), errMsg);
        }
        */
        jdbcTemplate.update("update ods_check set status = 1");

        //同步数据
        sql = "update IMAS_BM_ETL_TASK set data_status='02' where data_rpt_date = '"+now+"'";
        jdbcTemplate.update(sql);

        return Result.of(Result.OK.getCode(), now + "自动处理已完成");
    }

    private String getCondition(int type, String workdate) {
        String result = "";

        String sql = "";
        if (type == 0) {
            sql = "select * from ods_check_template where odscheck = 1";
        } else {
            sql = "select * from ods_check_template where qccheck = 1";
        }
        List<Map<String, Object>> records = jdbcTemplate.queryForList(sql);
        String errMsg = "";
        for (Map<String, Object> record : records) {
            String tableName = record.get("TABLE_NAME").toString().toUpperCase();
            if (tableName.startsWith("IMAS_PM_")) {
                tableName = tableName.replace("IMAS_PM_", "IMAS_PM_"+workdate.substring(6,8) + "_");
            }
            sql = "select count(*) cnt from " + tableName + " where group_id = '" +
                    record.get("GROUP_ID").toString() + "' and "  +
                    record.get("WHERECLAUSE").toString().replace(":DATA_DATE", "'" + workdate + "'");
            int cnt = jdbcTemplate.queryForObject(sql, Integer.class);
            if (cnt == 0) {
                errMsg += record.get("ERRMSG").toString() + ";";
            }
        }
        return errMsg;
    }


    private void execUpdSqlCommit(String sql) {
        transactionTemplate.run(Propagation.REQUIRES_NEW, () -> {
            jdbcTemplate.update(sql);
        });
    }

    //0 - exist 1 - process success
    public String getFileStatus(String now, int checktype) {
        String result = "";
        String result0 = "";
        String result1 = "";
        List<Map<String, Object>> checks = jdbcTemplate.queryForList("select * from ods_check_template where " +
                "odscheck='9' order by group_id");
        List<Map<String, Object>> files = jdbcTemplate.queryForList("select * from gp_bm_id_uploadlog where " +
                "file_name like '%"+now+"%'");
        for (Map<String, Object> check : checks) {
            String filename = check.get("WHERECLAUSE").toString();
            String errmsg = check.get("ERRMSG").toString();
            String groupid = check.get("GROUP_ID").toString();
            boolean find = false;
            boolean success = false;
            for (Map<String, Object> file : files) {
                String file_name = file.get("FILE_NAME").toString();
                String filler2 = file.get("FILLER2").toString();
                if (file_name.startsWith(filename)) {
                    find = true;
                    if(filler2.startsWith("未导入") || filler2.startsWith("导入未完成")) {

                    } else {
                        success = true;
                    }
                }
            }
            if (!success) {
                result1 += String.format(errmsg, now) + "\n";
            }
            if (!find) {
                result0 += String.format(errmsg, now) + "\n";
            }
        }
        if(checktype == 0) {
            return result0;
        }
        if (checktype == 1) {
            return result1;
        }
        return result;
    }

    public int isHoliday(String date) throws Exception {
        Calendar ca = Calendar.getInstance();
        Date dd = new SimpleDateFormat("yyyyMMdd").parse(date);
        ca.setTime(dd);
        int dayOfYear = ca.get(Calendar.DAY_OF_YEAR);
        String HOLIDAY_DEF =
                jdbcTemplate.queryForObject("select holiday_def from GP_BM_HOLIDAY where year = '"+date.substring(0,4)+
                        "'", String.class);
        String value = HOLIDAY_DEF.substring(dayOfYear-1, dayOfYear);
        if (value.equals("0"))
            return 1;
        else
            return 0;
    }

}
