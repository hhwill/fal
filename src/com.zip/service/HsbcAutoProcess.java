package com.gingkoo.imas.hsbc.service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import com.google.common.collect.ImmutableMap;
import lombok.SneakyThrows;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.gingkoo.data.compute.api.ComputeUnit;
import com.gingkoo.data.compute.api.bean.Result;
import com.gingkoo.gpms.importer.CommonDataImporter;
import com.gingkoo.gpms.importer.job.bean.JobResult;
import com.gingkoo.gpms.platform.task.TaskManager;
import com.gingkoo.imas.core.task.ReportTaskManager;
import com.gingkoo.imas.core.task.enumeration.TaskType;

@Component
public class HsbcAutoProcess implements ComputeUnit {

    private final Logger logger = LoggerFactory.getLogger(HsbcAutoProcess.class);

    private final HsbcFileImportService importService;
    private final JdbcTemplate jdbcTemplate;

    private final CustLoadFileService loadFileService;

    private final CustLoadFileProcessService fileProcessService;

    private final ReportTaskManager reportTaskManager;

    public HsbcAutoProcess(DataSource dataSource, HsbcFileImportService importService,
                           CustLoadFileService loadFileService, CustLoadFileProcessService fileProcessService, ReportTaskManager reportTaskManager){
        this.importService = importService;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        this.loadFileService = loadFileService;
        this.fileProcessService = fileProcessService;
        this.reportTaskManager = reportTaskManager;
    }

    @SneakyThrows
    @Override
    public Result call(Map<String, ?> parameters) {

        com.gingkoo.gpms.batch.entity.bean.JobResult jr = new com.gingkoo.gpms.batch.entity.bean.JobResult();
        jr.setErrCode("00");
        jr.setErrMsg("");
        logger.info("HsbcAutoProcess");

        String now = "";
        if (parameters.containsKey("dataRptDate")) {
            now = (String)parameters.get("dataRptDate");
        } else {
            Map<String, Object> check = jdbcTemplate.queryForMap("select * from ods_check");
            now = check.get("WORKDATE").toString();
        }
        //TODO 如果没下发任务则下发任务
        Map<String, Object> params = ImmutableMap.of("taskIds", Collections.emptyList());
        reportTaskManager.distributeTask(now, TaskType.FILE_TASK, params);
        reportTaskManager.distributeTask(now, TaskType.ETL_TASK, params);
        reportTaskManager.distributeTask(now, TaskType.FILE_TASK, params);

        //TODO 从一张配置表检查所有文件是否已上传并且导入成功并且没有错误

        //导数据 - 标准模板
        try {
            importService.importFiles();
        }catch (Exception ex) {
            logger.info("import template failed", ex);
            return Result.of(Result.ERROR.getCode(), "import template failed " + ex.getMessage());
        }
        //导数据 - rawdata
        try {
            loadFileService.run();
        } catch (Exception ex) {
            logger.info("import rawdata failed", ex);
            return Result.of(Result.ERROR.getCode(), "import rawdata failed " + ex.getMessage());
        }
        //满足条件，开始etl
        /*
        Map<String, Object> check = jdbcTemplate.queryForMap("select * from ods_check");
        String now = check.get("WORKDATE").toString();
        int status = (Integer)check.get("STATUS");
        if (status == 1) {
            return Result.of(Result.OK.getCode(), now + "自动处理已完成");
        }
        */
        String errMsg = getCondition(0, now);
        if (!errMsg.equals("")) {
            jr.setErrCode("01");
            jr.setErrMsg(errMsg);
            return Result.of(Result.ERROR.getCode(), errMsg);
        }
        try {
            fileProcessService.initMap(now);
        } catch (Exception ex) {
            logger.info("initMap failed", ex);
            Result.of(Result.OK.getCode(), "success");
        }
        String sql = "select * from ods_ctl where need_ods = '1' and work_date <'"+now+"' order by order_no";
        List<Map<String, Object>> tasks = jdbcTemplate.queryForList(sql);
        for (Map<String, Object> task : tasks) {
            String service = task.get("ODS_SERVICE").toString();
            try {
                fileProcessService.process(service, now, task.get("GROUP_ID").toString());
                jdbcTemplate.update("update ods_ctl set work_date = '"+now+"' where data_id = '"+task.get("DATA_ID").toString()+"'");
            } catch (Exception ex) {
                logger.info("ETL Service " +service+" Failed", ex);
            }
        }
        errMsg = getCondition(1, now);
        if (!errMsg.equals("")) {
            jr.setErrCode("02");
            jr.setErrMsg(errMsg);
            return Result.of(Result.ERROR.getCode(), errMsg);
        }
        jdbcTemplate.update("update ods_check set status = 1");

        //同步数据
        sql = "update IMAS_BM_ETL_TASK set data_status='02' where data_rpt_date = '"+now+"'";
        jdbcTemplate.update(sql);

        return Result.of(Result.OK.getCode(), now + "自动处理已完成");
    }

    private String getCondition(int type, String workdate) {
        String result = "";

        String sql = "";
        if (type == 0) {
            sql = "select * from ods_check_template where odscheck = 1";
        } else {
            sql = "select * from ods_check_template where qccheck = 1";
        }
        List<Map<String, Object>> records = jdbcTemplate.queryForList(sql);
        String errMsg = "";
        for (Map<String, Object> record : records) {
            String tableName = record.get("TABLE_NAME").toString().toUpperCase();
            if (tableName.startsWith("IMAS_PM_")) {
                tableName = tableName.replace("IMAS_PM_", "IMAS_PM_"+workdate.substring(6,8) + "_");
            }
            sql = "select count(*) cnt from " + tableName + " where group_id = '" +
                    record.get("GROUP_ID").toString() + "' and "  +
                    record.get("WHERECLAUSE").toString().replace(":DATA_DATE", "'" + workdate + "'");
            int cnt = jdbcTemplate.queryForObject(sql, Integer.class);
            if (cnt == 0) {
                errMsg += record.get("ERRMSG").toString() + ";";
            }
        }
        return errMsg;
    }
}
