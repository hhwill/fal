package com.gingkoo.imas.hsbc.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import com.gingkoo.root.facility.spring.tx.TransactionHelper;

import static com.gingkoo.imas.hsbc.service.EtlConst.SQL_DGKHXX;
import static com.gingkoo.imas.hsbc.service.EtlConst.SQL_DGKHXX_UPDATE;
import static com.gingkoo.imas.hsbc.service.EtlConst.SQL_TYJDJC_GMO;
import static com.gingkoo.imas.hsbc.service.EtlConst.SQL_TYJDJC_UPDATE;
import static com.gingkoo.imas.hsbc.service.EtlUtils.formatGM_NBJGH;
import static com.gingkoo.imas.hsbc.service.EtlUtils.formatNBJGH;
import static com.gingkoo.imas.hsbc.service.EtlUtils.getMap;
import static com.gingkoo.imas.hsbc.service.EtlUtils.getString;

public class CustEtlDGKHXX {

    private final Logger logger = LoggerFactory.getLogger(CustEtlDGKHXX.class);

    private final EtlInsertService insertService;

    private final JdbcTemplate jdbcTemplate;

    public CustEtlDGKHXX(EtlInsertService insertService, DataSource dataSource) {
        this.insertService = insertService;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public boolean process(String now, String group_id) throws Exception {
        logger.info(">>>Start DGKHXX " + now + " " + group_id);
        String day = now.substring(6,8);
        String sql = String.format("update ods_dgkhxx a inner join ( select khh, sum(fsje) tfsje from "
                        + "(select khh,fsje from imas_ods_%s_dwdkfk where sjrq='%s' and group_id = 'OPS_CDT'" +
                        "union select khh,fsje from imas_ods_%s_tyjdfs where sjrq='%s' and group_id = 'OPS_CDT'" +
                        "union select jkrkhh,fjse from imas_ods_%s_wtdkfk where sjrq='%s' and group_id = 'OPS_CDT')" +
                        " b) c on a.客户号=c.khh set 已用额度 = c.tfsje where a.data_date = '%s' and group_id='OPS_CDT'",
                day,now,day,now,day,now,now);
        jdbcTemplate.update(sql);
        mergeDgkhxx(now, group_id);
        return true;
    }

    public void mergeDgkhxx(String now, String group_id) {
        String day = now.substring(6,8);
        String sql = String.format("select * from imas_ods_%s_dgkhxx where sjrq = '%s'", day, now);
        List<Map<String, Object>> orecords = jdbcTemplate.queryForList(sql);
        sql = String.format("select * from ods_dgkhxx where data_date = '" + now + "'");
        List<Map<String, Object>> records = jdbcTemplate.queryForList(sql);
        Map<String, Map<String, Object>> lst = new HashMap<String, Map<String, Object>>();
        for (Map<String, Object> orecord : orecords) {
            String khh = getString(orecord.get("KHH"));
            lst.put(khh, orecord);
        }
        List<List<String>> updates = new ArrayList<List<String>>();
        List<List<String>> adds = new ArrayList<List<String>>();
        for (Map<String, Object> record : records) {
            String khh = getString(record.get("客户号"));
            if (lst.containsKey(khh)) {
                List<String> update = new ArrayList<String>();
                update.add(getString(record.get("授信额度")));
                String yyed = getString(record.get("已用额度"));
                try {
                    Double d = Double.parseDouble(yyed);
                } catch (Exception ex) {
                    yyed = "0";
                }
                update.add(yyed);
                update.add(khh);
                update.add(now);
                updates.add(update);
            } else {
                List<String> update = new ArrayList<String>();
                update.add(now);
                update.add(khh);
                String nbjgh = formatNBJGH(record.get("内部机构号"));
                update.add(nbjgh);
                update.add(getString(record.get("国民经济部门分类")));
                update.add(getString(record.get("金融机构类型代码")));
                update.add(getString(record.get("企业规模")));
                update.add(getString(record.get("控股类型")));
                update.add(getString(record.get("境内境外标志")));
                String dqdm = getString(record.get("经营所在地行政区划代码"));
                if (dqdm.equals("")) {
                    dqdm = getMap("DGHKXX_DQDM", nbjgh);
                }
                update.add(dqdm);
                String zcdz = getString(record.get("注册地址"));
                if (zcdz.equals("")) {
                    zcdz = getMap("DGHKXX_ADDRESS", nbjgh);
                }
                update.add(zcdz);
                update.add(getString(record.get("授信额度")));
                String yyed = getString(record.get("已用额度"));
                try {
                    Double d = Double.parseDouble(yyed);
                } catch (Exception ex) {
                    yyed = "0";
                }
                update.add(yyed);
                update.add(getString(record.get("所属行业")));
                update.add(getString(record.get("农村城市标志")));
                adds.add(update);
            }
        }
        insertService.insertData(SQL_DGKHXX, group_id, group_id, adds);
        insertService.updateData(SQL_DGKHXX_UPDATE, now, updates);
    }
}
