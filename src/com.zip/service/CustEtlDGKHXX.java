package com.gingkoo.imas.hsbc.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.gingkoo.root.facility.spring.tx.TransactionHelper;

import static com.gingkoo.imas.hsbc.service.EtlConst.*;
import static com.gingkoo.imas.hsbc.service.EtlUtils.formatGM_NBJGH;
import static com.gingkoo.imas.hsbc.service.EtlUtils.formatNBJGH;
import static com.gingkoo.imas.hsbc.service.EtlUtils.getMap;
import static com.gingkoo.imas.hsbc.service.EtlUtils.getString;

@Component
public class CustEtlDGKHXX {

    private final Logger logger = LoggerFactory.getLogger(CustEtlDGKHXX.class);

    private final EtlInsertService insertService;

    private final JdbcTemplate jdbcTemplate;

    public CustEtlDGKHXX(EtlInsertService insertService, DataSource dataSource) {
        this.insertService = insertService;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public boolean process(String now, String group_id) {
        logger.info(">>>Start DGKHXX " + now + " " + group_id);
        String day = now.substring(6,8);
        try {
            mergeDgkhxx(now, group_id);
            processYYED(now, group_id);


            String sql = String.format("update imas_ods_%s_dgkhxx set sxed = 0 where sxed is null and sjrq = '%s'", day,
                    now);
            jdbcTemplate.update(sql);
            sql = String.format("update imas_ods_%s_dgkhxx set yyed = 0 where yyed is null and sjrq = '%s'", day,
                    now);
            jdbcTemplate.update(sql);
            sql = String.format("update imas_ods_%s_dgkhxx set NCCSBZ = 'N' where NCCSBZ is null and sjrq = '%s'", day,
                    now);
            jdbcTemplate.update(sql);
        } catch (Exception ex) {
            logger.error("merge dgkhxx failed", ex);
        }
        return true;
    }

    private BigDecimal converCNY(BigDecimal amt, String bz) {
        BigDecimal result = amt;
        if (!bz.equals("CNY")) {
            String XESTOR = getMap("RATE", bz + "/CNY");
            if (XESTOR.equals("")) {
                XESTOR = "1";
            }
            try {
                result = result.multiply(new BigDecimal(XESTOR));
            } catch (Exception ex) {

            }
        }
        return result;
    }

    public void processYYED(String now, String group_id) {
        String day = now.substring(6,8);
        String sql = String.format("select * from imas_ods_%s_dwdkye where sjrq = '%s'", day, now);
        List<Map<String, Object>> records = jdbcTemplate.queryForList(sql);
        Map<String, BigDecimal> total = new HashMap<String, BigDecimal>();
        for (Map<String, Object> record : records) {
            String khh = record.get("KHH").toString();
            String bz = record.get("BZ").toString();
            BigDecimal amt = (BigDecimal)record.get("DKYE");
            amt = converCNY(amt, bz);
            if (total.containsKey(khh)) {
                BigDecimal org = total.get(khh);
                org = org.add(amt);
                total.put(khh, org);
            } else {
                total.put(khh, amt);
            }
        }
        sql = String.format("select * from imas_ods_%s_tyjdye where sjrq = '%s'", day, now);
        records = jdbcTemplate.queryForList(sql);
        for (Map<String, Object> record : records) {
            String khh = record.get("KHH").toString();
            String bz = record.get("BZ").toString();
            BigDecimal amt = (BigDecimal)record.get("YE");
            amt = converCNY(amt, bz);
            if (total.containsKey(khh)) {
                BigDecimal org = total.get(khh);
                org = org.add(amt);
                total.put(khh, org);
            } else {
                total.put(khh, amt);
            }
        }
        List<List<String>> updates = new ArrayList<List<String>>();
        for (String khh : total.keySet()) {
            List<String> update = new ArrayList<String>();
            update.add(total.get(khh).toString());
            update.add(khh);
            update.add(now);
            updates.add(update);

        }
        logger.info(">>>><<<<updates");
        logger.info(updates.toString());
        insertService.updateData(SQL_DGKHXX_YYED_UPDATE, now, updates);
    }

    public void mergeDgkhxx(String now, String group_id) {
        String day = now.substring(6,8);
        String sql = String.format("select * from imas_ods_%s_dgkhxx where sjrq = '%s'", day, now);
        List<Map<String, Object>> orecords = jdbcTemplate.queryForList(sql);
        sql = String.format("select * from ods_dgkhxx where data_date = '" + now + "'");
        List<Map<String, Object>> records = jdbcTemplate.queryForList(sql);
        Map<String, Map<String, Object>> lst = new HashMap<String, Map<String, Object>>();
        for (Map<String, Object> orecord : orecords) {
            String khh = getString(orecord.get("KHH"));
            lst.put(khh, orecord);
        }
        List<List<String>> updates = new ArrayList<List<String>>();
        List<List<String>> adds = new ArrayList<List<String>>();
        for (Map<String, Object> record : records) {
            String khh = getString(record.get("客户号"));
            if (lst.containsKey(khh)) {
                List<String> update = new ArrayList<String>();
                update.add(getString(record.get("授信额度")));
                String yyed = getString(record.get("已用额度"));
                try {
                    Double d = Double.parseDouble(yyed);
                } catch (Exception ex) {
                    yyed = "0";
                }
                update.add(yyed);
                update.add(khh);
                update.add(now);
                updates.add(update);
            } else {
                List<String> update = new ArrayList<String>();
                update.add(now);
                update.add(khh);
                String nbjgh = formatNBJGH(record.get("内部机构号"));
                update.add(nbjgh);
                update.add(getString(record.get("国民经济部门分类")));
                update.add(getString(record.get("金融机构类型代码")));
                update.add(getString(record.get("企业规模")));
                update.add(getString(record.get("控股类型")));
                update.add(getString(record.get("境内境外标志")));
                String dqdm = getString(record.get("经营所在地行政区划代码"));
                if (dqdm.equals("")) {
                    dqdm = getMap("DGHKXX_DQDM", nbjgh);
                }
                update.add(dqdm);
                String zcdz = getString(record.get("注册地址"));
                if (zcdz.equals("")) {
                    zcdz = getMap("DGHKXX_ADDRESS", nbjgh);
                }
                update.add(zcdz);
                update.add(getString(record.get("授信额度")));
//                String yyed = getString(record.get("已用额度"));
//                try {
//                    Double d = Double.parseDouble(yyed);
//                } catch (Exception ex) {
//                    yyed = "0";
//                }
//                update.add(yyed);
                update.add(getString(record.get("所属行业")));
                update.add(getString(record.get("农村城市标志")));
                adds.add(update);
            }
        }
        insertService.insertData(SQL_DGKHXX, group_id, group_id, adds);
        insertService.updateData(SQL_DGKHXX_UPDATE, now, updates);
    }
}
