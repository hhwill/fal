package com.gingkoo.imas.hsbc.service;

import java.sql.*;
import java.util.*;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.gingkoo.root.facility.spring.tx.TransactionHelper;

import static com.gingkoo.imas.hsbc.service.EtlUtils.getString;

@Component
public class CustLoadFileProcessService {

    private final Logger logger = LoggerFactory.getLogger(CustLoadFileProcessService.class);

    private final JdbcTemplate jdbcTemplate;

    private CustEtlGtrfCore etlGtrfCore;
    private CustEtlGRKHXX etlGRKHXX;
    private CustEtlWCAS etlWCAS;
    private CustEtlWPB etlWPB;
    private CustEtlDGKHXX etlDGKHXX;

    public CustLoadFileProcessService(CustEtlGtrfCore etlGtrfCore,
                                      CustEtlGRKHXX etlGRKHXX,CustEtlWCAS etlWCAS,CustEtlWPB etlWPB,
                                      CustEtlDGKHXX etlDGKHXX,
                                      TransactionHelper transactionTemplate,
                                      DataSource dataSource) {
        this.etlGtrfCore = etlGtrfCore;
        this.etlGRKHXX = etlGRKHXX;
        this.etlWCAS = etlWCAS;
        this.etlWPB = etlWPB;
        this.etlDGKHXX = etlDGKHXX;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public List<Map<String, String>> handle(List<Map<String,Object>> records) throws SQLException {
        List<Map<String, String>> result = new ArrayList<Map<String, String>>();

        for (Map<String, Object> record : records) {
            Map<String, String> newrecord = new HashMap<String, String>();
            for (String key : record.keySet()) {
                Object o = record.get(key);
                if (o == null) {
                    newrecord.put(key, "");
                } else {
                    newrecord.put(key, o.toString());
                }
            }
            result.add(newrecord);
        }
        return result;
    }

    public void initMap(String now) throws Exception {
        EtlUtils.map.clear();
        String previous = "20210627";
        try {
            previous = jdbcTemplate.queryForObject("select max(data_date) from map_nbjgh where data_date < '" + now +
                    "'", String.class);
        } catch (Exception ex) {
            previous = "20210627";
        }
        if (EtlUtils.map.size() == 0) {
            String sql = "select * from map_info";
            List<Map<String, String>> lst = handle(jdbcTemplate.queryForList(sql));
            for (Map<String, String> record : lst) {
                Map<String, String> srecord = new HashMap<String, String>();
                if (EtlUtils.map.containsKey(record.get("TYPE_NO"))) {
                    srecord = EtlUtils.map.get(record.get("TYPE_NO"));
                }
                srecord.put(record.get("SRC"), record.get("DEST"));
                EtlUtils.map.put(record.get("TYPE_NO"), srecord);
            }
            sql = "select NBJGH, DQDM from imas_ODS_"+previous.substring(6,8)+"_jgfzxx where sjrq = '"+previous+"'";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> dqdm = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                dqdm.put(record.get("NBJGH"), record.get("DQDM"));
            }
            EtlUtils.map.put("XDQDM", dqdm);
            sql = "select DATA_NO from gp_bm_data_dic where data_type_no = 'C_REGION_CODE'";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> dqqhdm = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                dqqhdm.put(record.get("DATA_NO"), record.get("DATA_NO"));
            }
            EtlUtils.map.put("DQQHDM", dqqhdm);
            sql = "select SRC,DEST from map_nbjgh where data_date = '"+now+"'";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> nbjgh = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                nbjgh.put(record.get("SRC"), record.get("DEST"));
            }
            EtlUtils.map.put("NBJGH", nbjgh);
            sql = "select * from MAP_WCAS_RATE_TYPE";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> rateTypeDD = new HashMap<String, String>();
            Map<String, String> rateTypeTD = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                rateTypeDD.put(record.get("ID1")+"_"+record.get("ID2")+"_"+record.get("ID3"),
                        record.get("DJJZLX")+"|"+record.get("LVLX")+"|"+record.get("JZLV")+"|"+record.get("LVFDPL"));
                rateTypeTD.put(record.get("ID1"),
                        record.get("DJJZLX")+"|"+record.get("LVLX")+"|"+record.get("JZLV")+"|"+record.get("LVFDPL"));
            }
            EtlUtils.map.put("WCAS_RATETYPE_DD", rateTypeDD);
            EtlUtils.map.put("WCAS_RATETYPE_TD", rateTypeTD);
            sql = "select * from MAP_WCAS_RATE_TYPE_SD";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> rateTypeSD = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                rateTypeSD.put(record.get("CPLX"),
                        record.get("DJJZLX")+"|"+record.get("LLLX")+"|"+getString(record.get("JZLV"))+"|"+record.get(
                                "LLFDPL"));
            }
            logger.info(">>><<<");
            logger.info(rateTypeSD.toString());
            EtlUtils.map.put("WCAS_RATETYPE_SD", rateTypeSD);
            sql = "select * from MAP_WCAS_RATE where data_date ='"+now+"'";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> rate = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                rate.put(record.get("PAIR"), record.get("XESTOR"));
            }
            EtlUtils.map.put("RATE", rate);
            logger.info(">>>><<<<");
            logger.info(rate.toString());
            sql = "select ZIACB,ZIACS,ZIACX, ZIDTAS from ODS_WCAS_CLOSEDAC where data_date = '"+now+"'";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> closedac = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                closedac.put(record.get("ZIACB")+"_"+record.get("ZIACS")+"_"+record.get("ZIACX"), record.get("ZIDTAS"));
            }
            EtlUtils.map.put("WCAS_CLOSEDAC", closedac);
            sql = "select ZIACB,ZIACS,ZIACX, ZICYCD,ZIDTAS from ODS_WPB_CLOSE where data_date = '"+now+"'";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> closedacp = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                closedacp.put(record.get("ZIACB")+record.get("ZIACS")+record.get("ZIACX")+record.get("ZICYCD"), record.get("ZIDTAS"));
            }
            EtlUtils.map.put("WPB_CLOSEDAC", closedacp);
            sql = "select CKZHBM from ods_wpb_close20210627";
            List<Map<String, Object>> result = jdbcTemplate.queryForList(sql);
            Map<String, String> wpbclose = new HashMap<String, String>();
            for (Map<String, Object> record : result) {
                wpbclose.put(getString(record.get("CKZHBM")),getString(record.get("CKZHBM")));
            }
            EtlUtils.map.put("WPB_CLOSE", wpbclose);
            sql = "select NBJGH,ADDRESS,DQDM from imas_ODS_"+previous.substring(6,8)+"_JGFZXX where sjrq ='"+previous+
                    "'";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> addresss = new HashMap<String, String>();
            Map<String, String> dqdms = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                addresss.put(record.get("NBJGH"), record.get("ADDRESS"));
                dqdms.put(record.get("NBJGH"), record.get("DQDM"));
            }
            EtlUtils.map.put("DGHKXX_ADDRESS", addresss);
            EtlUtils.map.put("DGHKXX_DQDM", dqdms);
        }
    }

    public boolean process(String type, String now, String group_id) throws Exception {
        initMap(now);
        if(type.equals("TEST")) {
            etlWCAS.test();
            return true;
        }
        if (type.equals("GRKHXX")) {
            return etlGRKHXX.processAll(now, group_id);
        }
        if (type.equals("DGKHXX")) {
            return etlDGKHXX.process(now, group_id);
        }
        if (type.equals("WPB")) {
            return etlWPB.process(now, group_id);
        }
        if (type.equals("WPBCPI")) {
            return etlWPB.processCPI(now, group_id);
        }
        if (type.equals("WCAS")) {
            return etlWCAS.process(now, group_id);
        }
        if (type.equals("GTRF")) {
            return etlGtrfCore.processAll(now, group_id);
        }
        if (type.equals("FXRATE_WPB")) {
            return etlWPB.processFXRate(now);
        }

        if (type.equals("MRFSFS") || type.equals("MRFSJC") || type.equals("TYCKJC") ||
                type.equals("TYCKFS") || type.equals("TYJDJC") || type.equals("TYJDFS") ) {
            jdbcTemplate.execute("call SP_ODS_GMO('"+type+"','"+now+"')");
            return true;
        }

        String sql = "select * from " + type + " where data_date = '" + now + "' and group_id = '" + group_id + "'";
        List<Map<String, Object>> lst = jdbcTemplate.queryForList(sql);
        if (type.equals("ODS_WCAS_CORPCUSLVL")) {
            etlWCAS.processWCAS_DGHKXX(now, lst, null, group_id);
        }
        return true;
    }
}
