package com.gingkoo.imas.hsbc.service;

import java.sql.*;
import java.util.*;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.gingkoo.root.facility.spring.tx.TransactionHelper;

import static com.gingkoo.imas.hsbc.service.EtlUtils.getString;

@Component
public class CustLoadFileProcessService {

    private final Logger logger = LoggerFactory.getLogger(CustLoadFileProcessService.class);

    private final JdbcTemplate jdbcTemplate;

    private CustEtlPJTXGtrfCore etlPJTXGtrfCore;
    private CustEtlTYJDGtrfCore etlTYJDGtrfCore;
    private CustEtlDWDKGtrfCore etlDWDKGtrfCore;
    private CustEtlDWDKSCSAIGtrfCore etlDWDKSCSAIGtrfCore;
    private CustEtlGRKHXX etlGRKHXX;
    private CustEtlWCAS etlWCAS;
    private CustEtlWPB etlWPB;

    public CustLoadFileProcessService(CustEtlPJTXGtrfCore etlPJTXGtrfCore, CustEtlTYJDGtrfCore etlTYJDGtrfCore,
                                      CustEtlDWDKGtrfCore etlDWDKGtrfCore,
                                      CustEtlDWDKSCSAIGtrfCore etlDWDKSCSAIGtrfCore,
                                      CustEtlGRKHXX etlGRKHXX,CustEtlWCAS etlWCAS,CustEtlWPB etlWPB,
                                      TransactionHelper transactionTemplate,
                                      DataSource dataSource) {
        this.etlPJTXGtrfCore = etlPJTXGtrfCore;
        this.etlTYJDGtrfCore = etlTYJDGtrfCore;
        this.etlDWDKGtrfCore = etlDWDKGtrfCore;
        this.etlDWDKSCSAIGtrfCore = etlDWDKSCSAIGtrfCore;
        this.etlGRKHXX = etlGRKHXX;
        this.etlWCAS = etlWCAS;
        this.etlWPB = etlWPB;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public List<Map<String, String>> handle(List<Map<String,Object>> records) throws SQLException {
        List<Map<String, String>> result = new ArrayList<Map<String, String>>();

        for (Map<String, Object> record : records) {
            Map<String, String> newrecord = new HashMap<String, String>();
            for (String key : record.keySet()) {
                Object o = record.get(key);
                if (o == null) {
                    newrecord.put(key, "");
                } else {
                    newrecord.put(key, o.toString());
                }
            }
            result.add(newrecord);
        }
        return result;
    }

    public void initMap(String now) throws Exception {
        EtlUtils.map.clear();
        if (EtlUtils.map.size() == 0) {
            String sql = "select * from map_info";
            List<Map<String, String>> lst = handle(jdbcTemplate.queryForList(sql));
            for (Map<String, String> record : lst) {
                Map<String, String> srecord = new HashMap<String, String>();
                if (EtlUtils.map.containsKey(record.get("TYPE_NO"))) {
                    srecord = EtlUtils.map.get(record.get("TYPE_NO"));
                }
                srecord.put(record.get("SRC"), record.get("DEST"));
                EtlUtils.map.put(record.get("TYPE_NO"), srecord);
            }
            sql = "select NBJGH, DQDM from imas_pm_"+now.substring(6,8)+"_jgfzxx where sjrq = '"+now+"'";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> dqdm = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                dqdm.put(record.get("NBJGH"), record.get("DQDM"));
            }
            EtlUtils.map.put("XDQDM", dqdm);
            sql = "select DATA_NO from gp_bm_data_dic where data_type_no = 'C_REGION_CODE'";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> dqqhdm = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                dqqhdm.put(record.get("DATA_NO"), record.get("DATA_NO"));
            }
            EtlUtils.map.put("DQQHDM", dqqhdm);
            sql = "select SRC,DEST from map_nbjgh where data_date = '"+now+"'";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> nbjgh = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                nbjgh.put(record.get("SRC"), record.get("DEST"));
            }
            EtlUtils.map.put("NBJGH", nbjgh);
            sql = "select * from MAP_WCAS_RATE_TYPE";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> rateTypeDD = new HashMap<String, String>();
            Map<String, String> rateTypeTD = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                rateTypeDD.put(record.get("ID1")+"_"+record.get("ID2")+"_"+record.get("ID3"),
                        record.get("DJJZLX")+"|"+record.get("LVLX")+"|"+record.get("JZLV")+"|"+record.get("LVFDPL"));
                rateTypeTD.put(record.get("ID1"),
                        record.get("DJJZLX")+"|"+record.get("LVLX")+"|"+record.get("JZLV")+"|"+record.get("LVFDPL"));
            }
            EtlUtils.map.put("WCAS_RATETYPE_DD", rateTypeDD);
            EtlUtils.map.put("WCAS_RATETYPE_TD", rateTypeTD);
            sql = "select * from MAP_WCAS_RATE_TYPE_SD";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> rateTypeSD = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                rateTypeSD.put(record.get("CPLX"),
                        record.get("DJJZLX")+"|"+record.get("LLLX")+"|"+getString(record.get("JZLV"))+"|"+record.get(
                                "LLFDPL"));
            }
            logger.info(">>><<<");
            logger.info(rateTypeSD.toString());
            EtlUtils.map.put("WCAS_RATETYPE_SD", rateTypeSD);
            sql = "select * from MAP_WCAS_RATE where data_date ='"+now+"'";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> rate = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                rate.put(record.get("PAIR"), record.get("XESTOR"));
            }
            EtlUtils.map.put("RATE", rate);
            sql = "select ZIACB,ZIACS,ZIACX, ZIDTAS from ODS_WCAS_CLOSEDAC where data_date = '"+now+"'";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> closedac = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                closedac.put(record.get("ZIACB")+record.get("ZIACS")+record.get("ZIACX"), record.get("ZIDTAS"));
            }
            EtlUtils.map.put("WCAS_CLOSEDAC", closedac);
            sql = "select ZIACB,ZIACS,ZIACX, ZICYCD,ZIDTAS from ODS_WCAS_CLOSEDACP where data_date = '"+now+"'";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> closedacp = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                closedacp.put(record.get("ZIACB")+record.get("ZIACS")+record.get("ZIACX")+record.get("ZICYCD"), record.get("ZIDTAS"));
            }
            EtlUtils.map.put("WPB_CLOSEDAC", closedacp);
            sql = "select NBJGH,ADDRESS from imas_pm_"+now.substring(6,8)+"_JGFZXX where sjrq ='"+now+"'";
            lst = handle(jdbcTemplate.queryForList(sql));
            Map<String, String> addresss = new HashMap<String, String>();
            for (Map<String, String> record : lst) {
                addresss.put(record.get("NBJGH"), record.get("ADDRESS"));
            }
            EtlUtils.map.put("DGHKXX_ADDRESS", addresss);

        }
    }

    public boolean process(String type, String now, String group_id) throws Exception {
        initMap(now);
        if(type.equals("TEST")) {
            etlWCAS.test();
            return true;
        }
        if (type.equals("GRKHXX")) {
            return etlGRKHXX.processAll(now, group_id);
        }
        if (type.equals("WPB")) {
            return etlWPB.process(now, group_id);
        }
        if (type.equals("WCAS")) {
            return etlWCAS.process(now, group_id);
        }

        String sql = "select * from " + type + " where data_date = '" + now + "' and group_id = '" + group_id + "'";
        List<Map<String, Object>> lst = jdbcTemplate.queryForList(sql);
        sql = "select max(data_date) from " + type + " where data_date < '" + now + "'";
        String previous = "20210624";
        try {
            previous = jdbcTemplate.queryForObject(sql, String.class);
        } catch (Exception ex) {

        }
        sql = "select * from " + type + " where data_date = '" + previous + "' and group_id = '" + group_id + "'";
        List<Map<String, Object>> lst1 = new ArrayList<Map<String, Object>>();
        if (type.contains("GTRF")) {
            lst1 = jdbcTemplate.queryForList(sql);
        }
        if (type.equals("ODS_GTRF_PJTX")) {
            etlPJTXGtrfCore.processPJTX(now, lst, lst1, group_id);
        } else if (type.equals("ODS_GTRF_TYJD")) {
            etlTYJDGtrfCore.processTYJD(now, lst, lst1, group_id);
        } else if (type.equals("ODS_GTRF_FTYDWDK")) {
            etlDWDKGtrfCore.processFTYDWDK(now, lst, lst1, group_id);
        } else if (type.equals("ODS_GTRF_FTYSCSAI")) {
            etlDWDKSCSAIGtrfCore.processFTYSCSAI(now, lst, lst1, group_id);
        } else if (type.equals("ODS_BOSC_GRKHXX")) {
            etlGRKHXX.processGRKHXXBASE(now, lst, group_id);
        } else if (type.equals("ODS_GRHXXX")) {
            etlGRKHXX.processGRKHXX(now, lst, group_id);
        }else if (type.equals("ODS_WCAS_CORPCUSLVL")) {
            etlWCAS.processWCAS_DGHKXX(now, lst, lst1, group_id);
        }
        return true;
    }
}
