package com.gingkoo.imas.hsbc.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import static com.gingkoo.imas.hsbc.service.EtlUtils.*;
import static com.gingkoo.imas.hsbc.service.EtlConst.*;

@Component
public class CustEtlPJTXGtrfCore {

    private final EtlInsertService insertService;

    public CustEtlPJTXGtrfCore(EtlInsertService insertService) {
        this.insertService = insertService;
    }

    private List<String> addBase(String now, Map<String, Object> src) {
        List<String> result = new ArrayList<String>();
        result.add(now);
        result.add(formatNBJGH(getString(src.get("ACCOUNTNO")).substring(0,3)));
        result.add(formatKHH(src.get("CUS")));
        String product = getString(src.get("BILLREF"));
        if (product.length() > 3) {
            product = product.substring(0,3);
        }
        String BBSTBR = getString(src.get("BBSTBR"));
        String jrjglxdm = "";
        String rzywlx = "";
        if (product.equals("BAT")) {
            rzywlx = "B01";
            jrjglxdm = "C11";
        } else if (product.equals("BBS")) {
            rzywlx = "B01";
            if (BBSTBR.equals("BACP")) {
                rzywlx = "C02";
            } else if (BBSTBR.equals("BKCS")) {
                rzywlx = "C03";
            } else if (BBSTBR.equals("PSCN")) {
                rzywlx = "C03";
            }
        } else if (product.equals("FAT")) {
            if (BBSTBR.startsWith("1")) {
                rzywlx = "B01";
            } else if (BBSTBR.startsWith("2")) {
                rzywlx = "B02";
            }
            jrjglxdm = "C11";
        } else {
            jrjglxdm = getMap("X1", product);
        }
        result.add(rzywlx);
        result.add(getString(src.get("BILLREF")));

        result.add(jrjglxdm);
        result.add(getString(src.get("BBDTAV")));
        result.add(getString(src.get("BBDUDT")));

        int daydiff = differentDaysByMillisecond(src.get("BBDUDT"),src.get("BBINSD"));
        if (daydiff <= 90) {
            result.add("01");
        } else if (daydiff <= 180) {
            result.add("02");
        } else { //if (daydiff <= 365){
            result.add("03");
        }
        result.add(getString(src.get("BBDRSP")));
        return result;
    }

    private List<String> addBalance(String now, Map<String, Object> src) {
        List<String> result = new ArrayList<String>();
        result.add(now);
        result.add(formatNBJGH(getString(src.get("ACCOUNTNO")).substring(0,3)));
        result.add(formatKHH(src.get("CUS")));
        result.add(getString(src.get("BILLREF")));
        result.add(getString(src.get("BBPRCY")));
        result.add(getString(src.get("ADVOS")));
        return result;
    }

    private List<String> addOccur(String now, Map<String, Object> src) {
        List<String> result = new ArrayList<String>();
        result.add(now);
        result.add(formatNBJGH(getString(src.get("ACCOUNTNO")).substring(0,3)));
        result.add(formatKHH(src.get("CUS")));
        result.add(getString(src.get("BILLREF")));
        result.add(getString(src.get("BILLREF"))+getString(src.get("交易方向")));
        result.add(getString(src.get("BBPRCY")));
        result.add(now);
        result.add(getString(src.get("BILLAMT")));
        result.add(getString(src.get("BBDRSP")));
        result.add(getString(src.get("交易方向")));
        return result;
    }

    public void processPJTX(String now, List<Map<String, Object>> lstNow, List<Map<String, Object>> lstPrevious,
                            String groupId) throws Exception {
        List<List<String>> base = new ArrayList<List<String>>();
        List<List<String>> balance = new ArrayList<List<String>>();
        List<List<String>> occur = new ArrayList<List<String>>();
        for (Map<String, Object> record : lstNow) {
            String billref = getString(record.get("BILLREF"));
            if (billref == null || !(billref.startsWith("BBE") || billref.startsWith("XBG") || billref.startsWith("FAO") || billref.startsWith("FAW") || billref.startsWith("FAT") || billref.startsWith("BAT") || billref.startsWith("BDP") || billref.startsWith("DPF") || billref.startsWith("BBS"))) {
                continue;
            }
            boolean find = false;
            boolean matchOccur = false;
            boolean matchBase = false;
            String advos = getString(record.get("ADVOS"));
            if (advos != null && !advos.equals("0")) {
                matchBase = true;
            }
            for (Map<String, Object> orecord : lstPrevious) {
                String obillref = getString(orecord.get("BILLREF"));
                if (obillref == null || !(obillref.startsWith("BBE") || obillref.startsWith("XBG") || obillref.startsWith("FAO") || obillref.startsWith("FAW") || obillref.startsWith("FAT") || obillref.startsWith("BAT") || obillref.startsWith("BDP") || obillref.startsWith("DPF") || obillref.startsWith("BBS"))) {
                    continue;
                }
                if (obillref.equals(billref)) {
                    find = true;
                    String badvos = getString(orecord.get("ADVOS"));
                    if (badvos == null || badvos.equals("0")) {
                        break;
                    }
                    if (!advos.equals(badvos)) {
                        matchOccur = true;
                        matchBase = true;
                        break;
                    }
                }
            }
            if (!find) {
                matchOccur = true;
                record.put("交易方向", "1");
                base.add(addBase(now, record));
                balance.add(addBalance(now, record));
            }
            if (matchBase) {
                if (advos.equals("0")) {
                    record.put("交易方向", "0");
                } else {
                    record.put("交易方向", "1");
                }
                base.add(addBase(now, record));
                balance.add(addBalance(now, record));
            }
            if (matchOccur) {
                occur.add(addOccur(now, record));
            }
        }
        insertService.insertData(SQL_PJTXFS, groupId, groupId, occur);
        insertService.insertData(SQL_PJTXYE, groupId, groupId, balance);
        insertService.insertData(SQL_PJTXJC, groupId, groupId, base);
    }
}
