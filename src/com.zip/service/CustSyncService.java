package com.gingkoo.imas.hsbc.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.gingkoo.imas.core.batch.ImasBatchBasicValidateService;
import com.gingkoo.imas.job.EtlDataSyncJobService;
import com.gingkoo.root.facility.spring.tx.TransactionHelper;

@Component
public class CustSyncService {

    private EtlDataSyncJobService etlDataSyncJobService;

    private final JdbcTemplate jdbcTemplate;

    public CustSyncService(DataSource dataSource,
                           EtlDataSyncJobService etlDataSyncJobService) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        this.etlDataSyncJobService = etlDataSyncJobService;
    }

    public void execute(String rptDate) {
        List<String> lst = new ArrayList<String>();
        try {
            List<Map<String, Object>> records = jdbcTemplate.queryForList("select GUID from gp_bm_id_filedata where " +
                    "length(guid)=6");
            for (Map<String, Object> record : records) {
                Map<String, String> param = new HashMap<String,String>();
                param.put("dataRptDate",rptDate);
                param.put("tableName",record.get("GUID").toString());
                try {
                    etlDataSyncJobService.execute(param);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

        } catch (Exception exx) {
            exx.printStackTrace();
        }
    }
}
