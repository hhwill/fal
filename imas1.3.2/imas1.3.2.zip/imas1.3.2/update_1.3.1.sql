delete from GP_QC_RULE where DATA_ID = 'IRR-FP84-2';
insert into GP_QC_RULE (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, INQ_ORG_ID, INQ_GROUP_ID, RULE_DESC, RULE_MESSAGE, RULE_TYPE, RULE_SOURCE, FIELD, FIELD_NAME, TRIMMABLE, NULLABLE, TYPE_ID, ENCODING, MIN_LENGTH, MAX_LENGTH, MIN_VALUE, MAX_VALUE, MAX_PRECISION, MIN_SCALE, MAX_SCALE, ENUMERATION, PATTERN, IN_ENTITY, IN_FIELD, EXISTS_SQL, DATA_HASH, SCRIPT, BEAN, CHECK_FLAG, CHECK_DESC, CHECK_ERR_TYPE, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_OP, DATA_SOURCE, DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE, DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE, DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, FILTER_SCRIPT) values ('IRR-FP84-2', null, null, null, null, 'IMAS', 'DGKHXX', '信贷客户必填授信额度', '信贷客户必填授信额度', '关联非空校验', '人民银行', 'SXED', '授信额度', null, 'Y', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'sqlExists("select 1 from DUAL where not exists(select 1 from IMAS_PM_#{__month}TYJDJC where SJRQ=:SJRQ and KHH=:KHH and JDYWLX in (''A01'', ''B01'')) or :SXED is not null")', null, null, null, null, null, null, null, null, null, null, null, null, 'auto_generator', null, null, null, null, null, null, null, null, 'IRR-FP84-2', 'Q', null, null, null, null);


delete from GP_BM_DATA_DIC where DATA_TYPE_NO = '201106' and DATA_NO = '11';
INSERT INTO GP_BM_DATA_DIC (DATA_ID, DATA_DATE, CORP_ID, ORG_ID, GROUP_ID, DATA_TYPE_NO, DATA_NO, DATA_TYPE_NAME,
                            DATA_NO_LEN, DATA_NAME, LIMIT_FLAG, HIGH_LIMIT, LOW_LIMIT, EFFECT_DATE, EXPIRE_DATE,
                            MISCFLGS, NEXT_ACTION, DATA_STATUS, DATA_FLAG, DATA_SOURCE, CHECK_FLAG, CHECK_DESC,
                            CHECK_ERR_TYPE, DATA_VERSION, DATA_REJ_DESC, DATA_DEL_DESC, DATA_CRT_USER, DATA_CRT_DATE,
                            DATA_CRT_TIME, DATA_CHG_USER, DATA_CHG_DATE, DATA_CHG_TIME, DATA_APV_USER, DATA_APV_DATE,
                            DATA_APV_TIME, RSV1, RSV2, RSV3, RSV4, RSV5, REMARKS)
VALUES ('987cfc06b67441c9b974f108aa7691cf', '20201119', 'IMAS', null, 'IMAS', '201106', '11', '数据状态', '2', '数据等待校验', 'n',
        null, null, null, null, null, '02', '04', '0', '3', 'N', null, 'n', 1, null, null, 'admin', '20201119',
        '20201119014611', 'admin', '20201119', '20201119014611', null, null, null, null, null, null, null, null, null);